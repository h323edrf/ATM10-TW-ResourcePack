---
navigation:
  parent: appliede-index.md
  title: 轉化終端
  icon: transmutation_terminal
  position: 20
categories:
  - appliede
item_ids:
  - appliede:transmutation_terminal
  - appliede:wireless_transmutation_terminal
---

# 轉化終端

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assemblies/transmutation_terminal.snbt" />
</GameScene>

到目前為止，我們已經瞭解了ME網路如何透過自動合成設施和AppliedE的各種[轉化裝置](transmutation_devices.md)將EMC轉化為物品。但有一個問題仍未解決：玩家自己怎麼在ME系統中直接操控EMC呢？

這個問題的答案是**ME轉化終端**：一臺擁有ProjectE<ItemLink id="projecte:transmutation_table" />大多數功能的，整合至相連ME網路中的終端。

首先，*你*可以在此終端內直接使用網路中的EMC轉化出已習得的物品，而不需在常規的物品儲存容器中預先放有它們。你也可以在此終端內清空和裝載卡萊恩能量之星等能夠儲存EMC的物品。

![可轉化的物品](diagrams/transmutable_item.png)
![卡萊恩能量之星裝載](diagrams/klein_star_filling.png)

終端的介面中有一個以火焰標識的槽位。和轉化桌中的火焰槽位一樣，物品可在此轉化為EMC進入終端。介面上還有兩個按鈕，它們的功能就要強大許多。

![終端UI](diagrams/terminal_ui.png)

左側的箭頭按鈕能切換Shift左擊的功能：物品如何進入終端。如果箭頭指向上方的基礎終端網格，則Shift左擊的物品會以普通物品的形式進入終端；如果箭頭指向左側的轉化槽，則Shift左擊的物品組會以EMC的形式進入網路的統一EMC儲存空間，操作者也會同時習得相應物品的知識。

最後，按下以奇點標識的按鈕後，操作者會習得終端內所有未習得的物品。不過，這麼做也有其代價：儲存空間中必須存在至少一個待習得的物品，且該物品會立即轉化為EMC。根據物品對應EMC值的不同，隨之而來的可能是相當龐大的能量消耗，操作前需要三思。按鈕也會提醒你，透過它習得所有物品前要多加思慮。

![是否確認？](diagrams/are_you_sure.png)

## 配方

<RecipeFor id="appliede:transmutation_terminal" />

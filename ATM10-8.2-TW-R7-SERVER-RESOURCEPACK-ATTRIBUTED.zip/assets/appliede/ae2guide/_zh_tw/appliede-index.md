---
navigation:
  title: "附屬：AppliedE"
  position: 150
---

# AppliedE

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assemblies/appliede.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

[*應用能源 2*](https://github.com/AppliedEnergistics/Applied-Energistics-2)與[*ProjectE*](https://www.curseforge.com/minecraft/mc-mods/projecte)的附屬模組，帶來了更契合兩者的聯動功能。和傳統的聯動模組不同，AppliedE會將ProjectE的*EMC*轉換成可顯示的獨立資源。這種資源可由ME網路顯示和操控，也可透過AE2的自動合成設施轉換成物品。此外，模組還提供了全新的裝置，鍊金術士的力量因而觸手可及。

在正式開始之前，你需要先合成一個<ItemLink id="emc_module" />，然後放置到ME網路中。如此，ME網路便能掌握你的鍊金術知識和專用儲存中的EMC。而這種“掌握”背後的基石，正是自動合成系統，以及AppliedE中一系列專精此道的[轉化裝置](transmutation_devices.md)。

---
navigation:
  parent: appliede-index.md
  title: 轉化模組
  icon: emc_module
  position: 0
categories:
  - appliede
item_ids:
  - appliede:emc_module
---

# 轉化模組

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assemblies/transmutation_module.snbt" />
</GameScene>

**ME轉化模組**是ME網路在EMC操控和鍊金術領域中的第一步。置於ME網路*任意一處*時，放置此模組的鍊金術士的所有知識和能量便會對網路開放。該鍊金術士的EMC會作為獨立的資源進入網路，同時ME網路也能夠透過自動合成及類似系統直接轉化這些EMC。可轉化物品會自動生成相應的合成樣板，所需材料則為對應量的EMC。

![EMC儲存](diagrams/emc_storage.png)

網路中可存在任意多個玩家放置的任意多個模組；但每位鍊金術士僅會有一個模組實際貢獻EMC，也只有該模組能訪問“可合成”的已習得物品。當網路中存在多個模組時，各個模組貢獻的EMC值會送入同一個儲存空間，且任意時刻僅會有一個模組實際進行此操作。存入和取出的EMC會在所有提供EMC的玩家間均分。

模組同時具有防ME網路溢位保險。實現方式是*層級*體系：網路中的EMC會按照一個極大的單位（10^12）分為多個層級。各層級的顯示顏色與EMC的基礎單位不同，用以區分。高層級可以“分解”為低層級，以便執行消耗大量EMC的轉化操作。

![EMC層級](diagrams/emc_tiers.png)

需要注意，除去開啟上述功能之外，此模組還會持續消耗25 AE/t，開支較大。具體的消耗可能會因配置的變化而改變。

## 配方

<RecipeFor id="appliede:emc_module" />

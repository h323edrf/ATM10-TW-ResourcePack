---
navigation:
  parent: appliede-index.md
  title: 轉化裝置
  icon: emc_interface
  position: 10
categories:
  - appliede
item_ids:
  - appliede:emc_interface
  - appliede:cable_emc_interface
  - appliede:emc_export_bus
  - appliede:emc_import_bus
  - appliede:learning_card
---

# 轉化裝置

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assemblies/transmutation_devices.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

對應AE2既存的<ItemLink id="ae2:interface" />、<ItemLink id="ae2:export_bus" />、<ItemLink id="ae2:import_bus" />等，AppliedE新增了類似的各式裝置。它們的功能和AE2的裝置幾乎完全一致，也仍然對普通的物品有效。關鍵的不同之處，則在於每次操作時，物品都會轉化成EMC，或是從EMC轉化回物品。

雖然這些裝置可以設定為過濾任意物品，但相應的功能仍只對玩家在網路中<ItemLink id="appliede:emc_module">轉化模組</ItemLink>處習得的物品生效。對於<ItemLink id="appliede:emc_interface" />來說，只有玩家已習得且網路已知曉的物品，才可進入其內部的儲存空間，而後才會轉化為EMC並送至相應的儲存位置。<ItemLink id="appliede:emc_import_bus" />同樣不會抽取未習得的物品。

## 鍊金精通卡

<ItemImage id="learning_card" scale="4" />

然而，要是所有物品都必須預先習得才可在ME網路中轉化成EMC，單是繁瑣的操作就能逼退興趣。為解決這一問題，可向<ItemLink id="appliede:emc_interface" />或<ItemLink id="appliede:emc_import_bus" />裝入<ItemLink id="appliede:learning_card" />；此後這些裝置便會在送入存在EMC值的物品時自動習得它們。

不過有一點需要注意，只有相應裝置的所有者（介面、輸入匯流排、或將物品送入介面的網路裝置的放置者）才能習得這些物品。

## 配方

<RecipeFor id="appliede:emc_interface" />
<RecipeFor id="appliede:emc_export_bus" />
<RecipeFor id="appliede:emc_import_bus" />
<RecipeFor id="appliede:learning_card" />

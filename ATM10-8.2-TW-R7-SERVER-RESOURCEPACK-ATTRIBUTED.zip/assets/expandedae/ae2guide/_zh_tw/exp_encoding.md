---
navigation:
  parent: expandedae-index.md
  title: 擴充套件編碼終端
  icon: exp_encoding_terminal
  position: 7
categories:
  - expandedae
item_ids:
- expandedae:exp_encoding_terminal
- expandedae:wireless_exp_encoding_terminal
---

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_encoding.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 擴充套件樣板編碼終端是對原版編碼終端的升級，新增了以下功能：
 - 編碼樣板時按住Shift鍵點選，可將樣板直接移入玩家物品欄
 - 終端內建的倍率按鈕 

![pattern_mult_screen.png](assets/pattern_mult_screen.png)

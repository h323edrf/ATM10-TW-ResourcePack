---
navigation:
  parent: expandedae-index.md
  title: 擴充套件樣板供應器
  icon: exp_pattern_provider
  position: 0
categories:
  - expandedae
item_ids:
  - expandedae:exp_pattern_provider
  - expandedae:exp_pattern_provider_part
---

# 擴充套件樣板供應器

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_pp.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

### 擴充套件樣板供應器是一種體積更大的樣板供應器，同時提供整塊方塊與部件兩種形態，
### 最多可容納72個樣板。  
![exp_pp_screen.png](assets/exp_pp_screen.png)

## 所有合成配方

<Row>
  <RecipesFor id="exp_pattern_provider" />
  <RecipesFor id="exp_pattern_provider_part" />
</Row>

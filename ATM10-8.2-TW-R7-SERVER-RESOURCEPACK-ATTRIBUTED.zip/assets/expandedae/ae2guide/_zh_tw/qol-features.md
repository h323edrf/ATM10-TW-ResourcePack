---
navigation:
  parent: expandedae-index.md
  title: 生活質量（QoL）功能
  icon: expandedae:exp_pattern_provider
  position: 10
categories:
  - expandedae
---

# 本模組新增了以下全部生活質量（QoL）功能
## 樣板供應器的樣板倍率：為樣板供應器新增一個按鈕，可將其中包含的全部樣板整體倍增或整體縮減 
__倍率效果可以疊加！__

![modify_patterns.png](assets/modify_patterns.png)
## 額外的阻塞模式：為所有樣板供應器新增兩種額外的阻塞模式
### 預設：這是AE2原本自帶的阻塞模式。當連線的儲存中不含該樣板供應器內任何一項樣板輸入物品時，會推送該樣板；若儲存中含有並非樣板輸入的其他物品，該阻塞模式會忽略這一點，依舊推送樣板。 
    
![blocking_1.png](assets/blocking/blocking_1.png)

### 完全：只要連線的儲存中存有任何物品，該阻塞模式就不會推送樣板。 
    
![blocking_2.png](assets/blocking/blocking_2.png)

### 智慧：只要目標儲存中僅存放該樣板自身的輸入物品，樣板供應器就仍可以推送這一相同的樣板 

![blocking_3.png](assets/blocking/blocking_3.png)

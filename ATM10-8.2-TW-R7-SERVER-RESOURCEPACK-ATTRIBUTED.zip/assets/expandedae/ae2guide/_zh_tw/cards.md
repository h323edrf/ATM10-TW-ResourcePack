---
navigation:
  parent: expandedae-index.md
  title: 升級卡
  icon: auto_complete_card
  position: 5
categories:
  - expandedae
item_ids:
- expandedae:auto_complete_card
- expandedae:pattern_refiller_card
---

## 目前，本模組僅新增了以下兩種升級卡
- 自動完成卡：該卡片是樣板供應器的升級元件，樣板一經推送便會自動取消對應的合成任務。_注意：搭配合成樣板使用時會出現異常，請務必謹慎_ 
<ItemImage id="auto_complete_card" />
- 樣板填充卡：該卡片是 <ItemLink id="wireless_exp_encoding_terminal" /> 
與 <ItemLink id="ae2wtlib:wireless_universal_terminal" /> 的升級元件，可自動為擴充套件編碼終端中的空白樣板欄位補充樣板 

_注意：該卡片僅會在每次點選編碼按鈕時嘗試補充樣板，這是資源佔用最低的實現方式_
<ItemImage id="pattern_refiller_card" />

---
navigation:
  title: "附加元件：AE2擴充套件"
  position: 150
---

# AppliedE

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/expandedae.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

本模組是 [*應用能源 2*](https://github.com/AppliedEnergistics/Applied-Energistics-2) 的一款附加內容，在原模組基礎上進一步擴充套件了功能，並補齊了您可能會懷念的舊版應用能源 2生活質量（QoL）特性。

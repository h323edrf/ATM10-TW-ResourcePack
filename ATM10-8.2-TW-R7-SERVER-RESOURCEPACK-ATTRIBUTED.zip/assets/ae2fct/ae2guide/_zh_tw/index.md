---
navigation:
  title: "AE2流體合成終端"
  position: 80
---

# AE2流體合成終端



## 物品
- <ItemImage id="ae2fct:terminal_fluid_interact_card"/>[終端流體互動卡](terminal_fluid_interact_card.md)
---
navigation:
  title: 終端流體互動卡
  icon: terminal_fluid_interact_card
  parent: index.md
  position: 001
categories:
  - ae2fct
item_ids:
  - terminal_fluid_interact_card
---
# 終端流體互動卡
<ItemImage id="ae2fct:terminal_fluid_interact_card" scale={3}/>


<ItemLink id="ae2fct:terminal_fluid_interact_card" />能讓你直接與流體互動，無需藉助鐵桶。換言之，原本需要流體桶的配方，安裝此卡後不用鐵桶就可以在<ItemLink id="ae2:crafting_terminal"/>處合成。試試看不用鐵桶合成蛋糕吧！


## 配方
<RecipesFor id="ae2fct:terminal_fluid_interact_card" />



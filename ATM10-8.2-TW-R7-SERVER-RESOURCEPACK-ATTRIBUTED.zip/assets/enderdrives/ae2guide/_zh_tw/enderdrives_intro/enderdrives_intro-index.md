---
navigation:
  title: 末影驅動器簡介
  position: 60
---

# 末影驅動器！

末影驅動器專注於一種不同的物品儲存方式。這些驅動器會根據為每個驅動器設定的頻率進行連線。所有具有相同頻率和隱私設定的驅動器都會共享相同內容，無論是誰製作的都一樣。無論是在你的 AE2 系統中、另一個維度中，還是其他玩家的系統中，其內容都會進行全域性同步。

要檢視所提供方塊和物品的完整列表，請參閱以下指南頁面：

## 末影驅動器

<CategoryIndex category="enderdrives"></CategoryIndex>

## 磁帶驅動器

<CategoryIndex category="tapedrives"></CategoryIndex>

發現問題了？缺少某項功能？
請在此反饋：
[EnderDrives GitHub](https://github.com/STS15/enderdrives)
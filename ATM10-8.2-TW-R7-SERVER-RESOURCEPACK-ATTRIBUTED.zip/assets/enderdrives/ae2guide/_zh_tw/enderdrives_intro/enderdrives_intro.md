---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: 末影物品儲存元件
  icon: enderdrives:ender_disk_1k
categories:
- enderdrives
item_ids:
- enderdrives:ender_disk_1k
- enderdrives:ender_disk_4k
- enderdrives:ender_disk_16k
- enderdrives:ender_disk_64k
- enderdrives:ender_disk_256k
- enderdrives:ender_disk_creative
- enderdrives:ender_fluid_disk_1k
- enderdrives:ender_fluid_disk_4k
- enderdrives:ender_fluid_disk_16k
- enderdrives:ender_fluid_disk_64k
- enderdrives:ender_fluid_disk_256k
- enderdrives:ender_fluid_disk_creative
---

# 末影驅動器

末影驅動器是強大的驅動器，允許透過頻率在各個 ME 系統、維度，甚至不同玩家之間實現全域性同步儲存。

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_256k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_256k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_creative" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_creative" />
  </Column>
</Row>

---

## 工作原理
每個末影驅動器都配置有頻率、範圍和模式。
- **頻率**：具有相同頻率的驅動器共享同一個容器。
- **範圍**：決定誰可以訪問該驅動器（全域性、私有或隊伍）。
- **模式**：控制物品流動方式（雙向、輸入、輸出）。

所有具有相同頻率和作用域的驅動器都會訪問**同一個虛擬容器**，無論它們位於何處。

---

## 型別上限
不同於傳統的 AE2 驅動器，末影驅動器的限制僅基於型別數。由於物品在後端的儲存方式，其唯一的硬性限制就是型別數量。也就是說，每種型別你實際上最多可以儲存 2^63 - 1，也就是 9,223,372,036,854,775,807 個物品。不過要注意，驅動器在該頻率下儲存的物品越多，耗電也會越高！

每個伺服器開始產生壓力的型別數量都不同。你可以使用 autobenchmark 命令來測試你的伺服器。為了得到準確結果，你需要開啟一個終端，並在所選頻率下放置一個作用域設為 Private 的驅動器。測試會一直進行，直到 TPS 降到 18 以下。這可能需要幾分鐘。

我個人的平均值大約是 275,000 種。275,000/255 ≈ 1078。這意味著我得把 107.8 個 ME 驅動器裝滿 256k 末影驅動器和已分類物品之後，才會開始看到效能問題。我也見過更高或更低的建議最大型別數。這個上限由同一世界中所有使用這些驅動器的玩家共享。

---

## 磁碟驅動器模式
每個磁碟驅動器都可以設定為以下三種**傳輸模式**之一：

- ![PEGui1](../pic/transport_bidirectional_alt.png) **雙向** _（預設）_
  標準的 ME 驅動器行為。可自由插入和提取物品。


- ![PEGui1](../pic/transport_input_alt.png) **僅輸入**
  物品可以插入，但無法取出。適用於緩衝或同步輸入。


- ![PEGui1](../pic/transport_output_alt.png) **僅輸出**
  物品可以被提取，但不能插入。非常適合作為輸出緩衝區或只讀訪問。

---

## 範圍與隱私

每個驅動器還有一個**作用域**，用於控制誰可以訪問其中的容器：
-  **全域性** _（預設）_
   公開！任何使用相同頻率的玩家都可以訪問這個共享容器。


-  **私有**
  與你的 UUID 繫結。只有你可以建立用於訪問該頻率的驅動器。你的 ME 系統中的其他使用者仍然可以訪問這個儲存


-  **隊伍**
  與你的 FTB隊伍 共享。所有成員都可以建立能夠訪問同一頻率的驅動器。

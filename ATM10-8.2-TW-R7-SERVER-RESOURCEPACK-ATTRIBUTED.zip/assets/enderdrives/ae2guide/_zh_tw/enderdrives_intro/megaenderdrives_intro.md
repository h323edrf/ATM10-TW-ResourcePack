---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: MEGA末影物品儲存元件
  icon: megaenderdrives:item_storage_cell_256m
categories:
  - megaenderdrives
item_ids:
  - megaenderdrives:item_storage_cell_1m
  - megaenderdrives:item_storage_cell_4m
  - megaenderdrives:item_storage_cell_16m
  - megaenderdrives:item_storage_cell_64m
  - megaenderdrives:item_storage_cell_256m
---

# 末影驅動器

末影驅動器功能強大，能用於構建全域性同步的儲存系統；這種系統能跨越ME網路和維度的界限，甚至還能透過頻率供給多名玩家使用。

<Row gap="10">
  <Column>
    <ItemImage id="megaenderdrives:item_storage_cell_1m" />
  </Column>
  <Column>
    <ItemLink id="megaenderdrives:item_storage_cell_1m" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="megaenderdrives:item_storage_cell_4m" />
  </Column>
  <Column>
    <ItemLink id="megaenderdrives:item_storage_cell_4m" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="megaenderdrives:item_storage_cell_16m" />
  </Column>
  <Column>
    <ItemLink id="megaenderdrives:item_storage_cell_16m" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="megaenderdrives:item_storage_cell_64m" />
  </Column>
  <Column>
    <ItemLink id="megaenderdrives:item_storage_cell_64m" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="megaenderdrives:item_storage_cell_256m" />
  </Column>
  <Column>
    <ItemLink id="megaenderdrives:item_storage_cell_256m" />
  </Column>
</Row>

---

## 工作原理
每一個末影驅動器都有三項配置：頻率、開放範圍、模式。
- **頻率**：頻率相同的驅動器使用同一個儲存空間。
- **開放範圍**：決定可訪問該驅動器的使用者（公開、私人、團隊）。
- **模式**：決定物品轉移的方向（雙向、僅輸入、僅輸出）。

所有頻率和開放範圍相同的驅動器對應的是**同一個虛擬儲存空間**，無論它們身處何處都是如此。

---

## 型別限制

末影驅動器與傳統的AE2元件不同，它們僅在型別上存在限制。受後端物品儲存方式的特性影響，唯一的硬性限制就是型別的數量。單個型別下甚至可儲存多達2^63 - 1個，也即9,223,372,036,854,775,807個物品。但務必當心，某頻率中的物品越多，能量消耗就越大！

每個伺服器能夠穩定承載的型別總數是不同的，超過某個閾值時效能會開始下降。可以使用“autobenchmark”（自動基準測試）命令測試你的伺服器端。測試時，需開啟終端介面，並透過它訪問處於選定頻率和“私人”開放範圍的驅動器，如此才能得到準確結果。基準測試會持續執行到TPS降至18以下，過程可能持續數分鐘。

我個人測試得到的平均值約為275,000個型別。275,000/255 ≈ 1078。也就是說，若向ME驅動器放入物品各異的256k末影驅動器，應當在插滿超過107.8個ME驅動器時才會出現效能問題。我遇到過更高和更低的推薦最大型別數。這一上限對同一世界中使用末影驅動器的所有使用者都成立。

---

## 驅動器模式
每個驅動器可設定為三種**傳輸模式**之一：

- ![PEGui1](../pic/transport_bidirectional_alt.png) **雙向**_（預設）_  
  標準ME元件行為；可自由存入和取出


- ![PEGui1](../pic/transport_input_alt.png) **僅輸入**  
  可以存入物品，但無法取出；適合用作同步輸入的緩衝


- ![PEGui1](../pic/transport_output_alt.png) **僅輸出**  
  可以取出物品，但無法存入；適合用作輸出緩衝和只讀訪問

---

## 開放範圍與隱私

每個驅動器也均有**開放範圍**設定，用於控制什麼使用者可訪問儲存空間：
- **全域性**_（預設）_  
  公開訪問！所有使用同頻率的玩家都可訪問此共享儲存空間


- **私人**  
  與你的UUID繫結，只有你能製造可訪問該頻率的驅動器；使用你的ME系統的其他使用者也可訪問


- **團隊**  
  與你所處的FTB團隊共享，團隊的所有成員均能製造可訪問該頻率的驅動器
---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: 磁帶盤物品儲存元件
  icon: enderdrives:tape_disk
categories:
- tapedrives
item_ids:
- enderdrives:tape_disk
---

# 磁帶盤驅動器

磁帶機是與 AE2 相容的強大儲存元，專門用於處理 **NBT 較重的物品**，
例如工具、護甲、附魔裝備，或任何擁有獨特標籤、通常會迅速佔滿傳統 ME 驅動器型別空間的物品。

與典型的 AE2 驅動器不同，磁帶盤已用位元組數會根據所存物品實際的 **NBT 大小** 動態變化——讓你能更細緻地控制系統。磁帶機**不會**告知 AE2 它是任何符合其過濾器物品的首選儲存位置，請使用 ME 驅動器優先順序。

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:tape_disk" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:tape_disk" />
  </Column>
</Row>

---

## 工作原理

每個磁帶盤只允許儲存帶有非標準 NBT 的物品、盔甲、工具或不可堆疊物品。

---

## 位元組與型別限制

磁帶盤同時具有 **型別上限** 和 **位元組用量上限**：

- **型別上限** – 可儲存的唯一物品種類數上限（例如附魔書、自定義護甲）。
- **位元組上限** – 基於每件物品的 **NBT 資料大小**。帶有大量標籤的物品（如 Apotheosis 裝備）由於 NBT 數量較多，會佔用更多空間。

磁帶盤專門設計為**偏向儲存 NBT 資料較重的物品**，非常適合存放裝備或一次性物品，而不會佔用傳統儲存驅動器的空間。

---


## 何時使用磁帶盤

在以下情況下，請使用磁帶盤而不是傳統磁碟：

- 你正在儲存**不可堆疊物品**，例如護甲、工具或裝備。
- 你需要為**NBT 很重的模組物品**騰出空間。
- 你想讓特殊物品不要進入普通的 ME 驅動器。

當普通驅動器因佔用巨型驅動器的型別限制空間而捉襟見肘時，磁帶機就能大顯身手。

---

## IO埠傳輸

磁帶盤透過 IO埠 向其傳入或從其傳出資料時會自動限速。這是因為它可能會處理 NBT 很重的物品，
以避免一次性全部傾倒出來導致遊戲卡死。

---

## 可以儲存什麼？

磁帶盤專門用於存放**NBT 資料較重**、**不可堆疊**或**自定義過的**物品——並不適合一般的大宗儲存。

---

### 可接受物品

| 物品                                | 示例                                  |
|-------------------------------------|------------------------------------------|
| <ItemImage id="minecraft:diamond_chestplate" /> | 帶附魔的 **鑽石胸甲** |
| <ItemImage id="minecraft:enchanted_book" />     | 帶附魔的 **附魔書**   |
| <ItemImage id="minecraft:splash_potion" />      | 帶效果的 **藥水**                 |
| <ItemImage id="minecraft:netherite_pickaxe" />  | 有耐久的 **工具**                |

---

### 不接受

| 物品                              | 原因                         |
|-----------------------------------|--------------------------------|
| <ItemImage id="minecraft:cobblestone" /> | 無 NBT，可堆疊              |
| <ItemImage id="minecraft:wheat" />       | 無 NBT，可堆疊  |
| <ItemImage id="minecraft:oak_log" />     | 無 NBT，可堆疊             |
| <ItemImage id="minecraft:apple" />       | 無 NBT，可堆疊    |
| <ItemImage id="minecraft:iron_ingot" />  | 無 NBT，可堆疊    |

---
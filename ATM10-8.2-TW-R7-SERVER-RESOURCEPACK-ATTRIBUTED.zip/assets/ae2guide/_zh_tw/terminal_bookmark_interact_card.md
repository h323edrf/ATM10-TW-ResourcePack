---
navigation:
  title: 終端書籤互動卡
  icon: terminal_bookmark_interact_card
  parent: index.md
  position: 001
categories:
  - ae2tb
item_ids:
  - terminal_bookmark_interact_card
---
# 終端書籤互動卡
<ItemImage id="ae2tb:terminal_bookmark_interact_card" scale={3}/>


<ItemLink id="ae2tb:terminal_bookmark_interact_card"/>可讓AE2終端直接與JEI、EMI、REI中的書籤物品互動。

安裝此卡後，書籤項便不再是普通的引用了⸺它們變成了整合於ME網路的快捷連結。

## 配方
<RecipesFor id="ae2tb:terminal_bookmark_interact_card" />



---
navigation:
  title: "AE2 Tangible Bookmarks"
  position: 80
---

# AE2 Tangible Bookmarks

AE2 Tangible Bookmarks能將物品管理器模組（JEI/EMI/REI）的書籤和AE2的終端連線起來。

使用AE2終端時，點選JEI、EMI、REI中的書籤/收藏物品，即可直接向網路請求它們，無需再在終端搜尋欄內輸入對應名稱。

## 物品
- <ItemImage id="ae2tb:terminal_bookmark_interact_card"/>[終端書籤互動卡](terminal_bookmark_interact_card.md)

## 配置：

- 預設鍵位可在按鍵設定選單和模組的終端配置欄內檢視。
- EMI鍵位可在EMI的配置中檢視。

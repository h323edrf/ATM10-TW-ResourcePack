---
navigation:
  parent: appflux/appflux-index.md
  title: 終端互動
categories:
- flux tricks
---

# 終端互動

終端會將已儲存的能量顯示為這些*綠色流體*。

![FE_GUI](../pic/fe_terminal.png)

這些並不是真正的流體，因此你不能用桶來裝它。

你可以使用能量容器，例如電池、電動工具，向其中充入/抽出能量。

![FE_GUI2](../pic/fe_terminal2.png)
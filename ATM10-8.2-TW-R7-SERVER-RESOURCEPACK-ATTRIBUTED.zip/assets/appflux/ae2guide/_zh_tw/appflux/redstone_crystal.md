---
navigation:
  parent: appflux/appflux-index.md
  title: 紅石晶體
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# 紅石晶體

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*"砰啊！！"*

紅石是儲存能量的不錯介質，但它們過於鬆散，無法放入儲存元中。

與福魯伊克斯水晶和螢石結合後，紅石塊會結晶為紅石水晶。它們能夠儲存大量
能量，同時只佔用很小的空間。
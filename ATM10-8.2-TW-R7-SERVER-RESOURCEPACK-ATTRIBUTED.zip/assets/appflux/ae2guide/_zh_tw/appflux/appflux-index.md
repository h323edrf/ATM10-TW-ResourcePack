---
navigation:
  title: 應用通量
  position: 70
---

# 將能量儲存在儲存元裡！

Appflux 允許你使用 AE 來管理電力系統。

## 通量單元
<CategoryIndex category="flux cells"></CategoryIndex>

## 材料
<CategoryIndex category="flux materials"></CategoryIndex>

## 通量訪問點
<CategoryIndex category="flux accessor"></CategoryIndex>

## 技巧
<CategoryIndex category="flux tricks"></CategoryIndex>
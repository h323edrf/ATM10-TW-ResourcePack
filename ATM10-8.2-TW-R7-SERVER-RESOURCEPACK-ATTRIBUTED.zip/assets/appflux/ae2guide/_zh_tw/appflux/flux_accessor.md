---
navigation:
  parent: appflux/appflux-index.md
  title: 通量訪問點
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# 通量訪問點

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

通量訪問點可以輸入/輸出儲存在你的 ME 網路中的能量。預設情況下，它們沒有 I/O 限制，這可以在 
Appflux 配置中更改。

它們有快速模式和普通模式。在快速模式下，它每刻都會輸出能量，如果大量使用可能會導致卡頓。
在普通模式下，它會根據目標的儲能情況輸出能量，因此不會造成卡頓問題。

* 注意：這裡提到的“能量”是儲存在你的[FE儲存元件](./flux_cells.md)中的 FE，而不是[能量單元](ae2:items-blocks-machines/energy_cells.md)中的能量。
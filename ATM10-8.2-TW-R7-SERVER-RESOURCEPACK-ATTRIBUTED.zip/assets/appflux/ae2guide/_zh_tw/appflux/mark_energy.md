---
navigation:
  parent: appflux/appflux-index.md
  title: 標記FE
categories:
- flux tricks
---

# 如何在配置槽位中標記 FE

你可能想用 <ItemLink id="ae2:export_bus"/> 輸出能量，而你需要在它的配置槽位中標記 FE。

右鍵點選帶有能量容器的槽位以標記為 FE。

![FE_MARK](../pic/fe_mark.png)
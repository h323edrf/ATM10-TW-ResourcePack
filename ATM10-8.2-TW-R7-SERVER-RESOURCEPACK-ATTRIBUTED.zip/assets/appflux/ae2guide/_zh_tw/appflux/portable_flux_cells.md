---
navigation:
  parent: appflux/appflux-index.md
  title: 行動式紅石通量單元
  icon: appflux:fe_1k_portable_cell
categories:
- flux cells
item_ids:
- appflux:fe_1k_portable_cell
- appflux:fe_4k_portable_cell
- appflux:fe_16k_portable_cell
- appflux:fe_64k_portable_cell
- appflux:fe_256k_portable_cell
- appflux:fe_1m_portable_cell
- appflux:fe_4m_portable_cell
- appflux:fe_16m_portable_cell
- appflux:fe_64m_portable_cell
- appflux:fe_256m_portable_cell
---

# 行動式通量單元

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_portable_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_portable_cell" scale="4" />
  </Row>
</Column>

行動式 FE 單元的容量只有普通[FE 單元](./flux_cells.md)的四分之一。

不過，你可以在行動式 FE 儲存元中安裝 <ItemLink id="appflux:induction_card"/>，它們會自動為你物品欄中的物品充能。
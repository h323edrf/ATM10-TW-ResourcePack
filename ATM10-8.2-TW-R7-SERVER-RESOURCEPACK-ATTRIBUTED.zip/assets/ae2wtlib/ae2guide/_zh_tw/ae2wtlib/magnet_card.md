---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 磁引卡
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# 磁引卡

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

<ItemLink id="ae2wtlib:magnet_card" /> 是 <ItemLink id="ae2:wireless_crafting_terminal" /> 的一種[升級卡](ae2:items-blocks-machines/upgrade_cards.md)。
它會為 <ItemLink id="ae2:wireless_crafting_terminal" /> 新增一個可在 GUI 中切換或設定過濾的磁鐵功能。
另外也有一個按鍵繫結可用於開關它。

<ItemLink id="ae2wtlib:magnet_card" /> 有兩個作用：

1. 在更大的範圍內拾取物品（可配置，預設 16）
2. 將拾取到的物品放入 ME 系統，而不是你的物品欄

兩者都可以分別切換，也可以分別過濾（拾取過濾器和插入過濾器）。
任一過濾器都可以設為黑名單或白名單模式。

## 配方

<RecipeFor id="ae2wtlib:magnet_card" />
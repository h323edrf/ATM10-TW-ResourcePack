---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 無線合成終端
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
- ae2:wireless_crafting_terminal
---

# 無線合成終端

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> 是 <ItemLink id="ae2:crafting_terminal" /> 的[無線](wireless_terminals.md)版本。
AE2WTLib 增加了來自 ME 網路的自動[補貨](restock.md)功能，並允許“選取方塊”直接從 ME 網路中提取物品。   
搭配 <ItemLink id="ae2wtlib:magnet_card" /> 時，它還可充當磁鐵。

它可以與其他[無線終端](wireless_terminals.md)合併為一個 <ItemLink id="ae2wtlib:wireless_universal_terminal" />

AE2WTLib 強化了 Minecraft 的 `Pick Block` 功能：當你的物品欄裡找不到對應物品時，
它會直接從網路中提取。
（如果你當前槽位剛好滿了，它也會嘗試存放物品）

## 介面

參見[終端](ae2:items-blocks-machines/terminals.md)

## 升級

<ItemLink id="ae2:wireless_crafting_terminal" /> 支援以下[升級](ae2:items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="ae2:energy_card" />，用於提升電池容量
*   <ItemLink id="ae2wtlib:quantum_bridge_card" />，讓終端擁有無限範圍，甚至可以跨維度訪問，並可自動從 ME 網路為終端充能
*   <ItemLink id="ae2wtlib:magnet_card" />，用於新增磁鐵功能

## 配方

<RecipeFor id="ae2:wireless_crafting_terminal" />
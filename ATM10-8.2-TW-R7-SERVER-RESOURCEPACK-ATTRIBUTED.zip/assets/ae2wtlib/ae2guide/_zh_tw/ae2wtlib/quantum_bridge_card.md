---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 量子橋卡
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# 量子橋卡

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

量子橋卡是一種[升級卡](ae2:items-blocks-machines/upgrade_cards.md)，可用於 [AE2wtlib 無線終端](wireless_terminals.md)。
它可以將你的[無線終端](wireless_terminals.md)連線到[量子橋](ae2:items-blocks-machines/quantum_bridge.md)。

將一張量子橋卡和一個 <ItemLink id="ae2:quantum_entangled_singularity" /> 放入你的無線終端中，
再將另一個奇點放入一個連線到你網路的[量子橋](ae2:items-blocks-machines/quantum_bridge.md)中。

你的無線終端現在已量子連結，可以在任何地方訪問你的網路，甚至跨維度訪問（前提是承載網路的區塊已載入，例如使用 <ItemLink id="ae2:spatial_anchor" />），
並且會自動從你的網路中補充能量。
（請確保你的網路擁有足夠的[能量儲存](ae2:items-blocks-machines/energy_cells.md)）

## 配方

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
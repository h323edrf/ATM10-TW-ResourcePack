---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: AE2WTLib無線終端
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
- ae2wtlib:wireless_pattern_encoding_terminal
- ae2wtlib:wireless_pattern_access_terminal
---

# 無線終端

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

除了 <ItemLink id="ae2:energy_card" /> 之外，所有 AE2WTLib 無線終端都可以用 <ItemLink id="ae2wtlib:quantum_bridge_card" />
進行升級，並組合成一個 <ItemLink id="ae2wtlib:wireless_universal_terminal" />。

和 AE2 的 <ItemLink id="ae2:wireless_terminal" /> 一樣，它可以透過按鍵繫結訪問，也可以放入飾品欄中
（如果安裝了任意實現 curio api 的模組）。

無線終端也可以像普通的 <ItemLink id="ae2:wireless_terminal" /> 一樣，使用 <ItemLink id="ae2:wireless_access_point" /> 進行繫結

## 無線通用終端

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> 是將多個無線終端組合成一個物品的產物。

## 無線合成終端

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> 是合成終端的無線版本。
與原版 AE2 相比，它具有一些[額外功能](wireless_crafting_terminal.md)。

## 無線樣板編碼終端

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

<ItemLink id="ae2:pattern_encoding_terminal" /> 的無線版本

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## 無線樣板管理終端

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

<ItemLink id="ae2:pattern_access_terminal" /> 的無線版本

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## 附加終端

其他附屬模組中的大多數無線終端也能與 <ItemLink id="ae2wtlib:wireless_universal_terminal" /> 配合使用。

## 無法在通用終端中使用的終端

<ItemLink id="ae2:wireless_terminal" /> 不能在 <ItemLink id="ae2wtlib:wireless_universal_terminal" /> 中使用，
因為與 <ItemLink id="ae2:wireless_crafting_terminal" /> 相比，它不會帶來任何好處。
它也無法使用 <ItemLink id="ae2wtlib:quantum_bridge_card" />
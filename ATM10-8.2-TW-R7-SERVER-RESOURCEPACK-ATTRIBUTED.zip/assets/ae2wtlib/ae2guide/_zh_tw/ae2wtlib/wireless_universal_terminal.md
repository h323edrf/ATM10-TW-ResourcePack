---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: 無線通用終端
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
- ae2wtlib:wireless_universal_terminal
---

# 無線通用終端

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> 是將多個[無線終端](wireless_terminals.md)組合成一個物品的產物。

所有[AE2WTLib 無線終端](wireless_terminals.md)都可以合併為一個終端。

AE2 的 <ItemLink id="ae2:wireless_terminal" />***不能***組合成 <ItemLink id="ae2wtlib:wireless_universal_terminal" />。


## 介面

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> 會在終端 UI 中新增一個按鈕，
左鍵點選（或右鍵點選）它即可切換到下一個（或上一個）[無線終端](wireless_terminals.md)。


## 升級

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> 可接受與已安裝的 [無線終端](wireless_terminals.md) 相同的升級。
每安裝一個終端都會額外增加 2 個升級槽位。

## 能量儲存

新增終端會合並它們的能量儲存，
因此帶有兩個終端的 <ItemLink id="ae2wtlib:wireless_universal_terminal" /> 的能量儲存量是[無線終端](wireless_terminals.md)的兩倍。
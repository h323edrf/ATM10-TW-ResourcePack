---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: ME裝罐器
  icon: extendedae:caner
categories:
- extended devices
item_ids:
- extendedae:caner
---

# ME裝罐器

<BlockImage id="extendedae:caner" scale="8"></BlockImage>

ME裝罐器是一臺可將各種東西“裝罐”的機器，包括流體、Mekanism 氣體、Botania 魔力，甚至能量！

第一個槽位用於放入要填充的內容物，第二個槽位用於放入要被填充的容器。

它執行時需要能量，並且每次操作消耗 80 AE。

![GUI](../pic/caner_gui.png)

預設情況下它只能填充流體，你需要安裝相應的附屬模組才能讓它填充其他東西。

### 支援的附屬：
- 應用通量
- 應用能源：通用機械附屬
- 應用能源：植物魔法附屬

## 使用 ME裝罐器進行自動合成

只有頂部和底部兩個面可以接收能量並連線到網路。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

這是一個適用於 ME裝罐器 的簡單搭建。ME裝罐器在從 <ItemLink id="ae2:pattern_provider" /> 接受原料後，會自動彈出已填充的物品。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

樣板中只能包含要填充的內容物和要被填充的容器。以下是一些示例：

裝滿水桶：

![P1](../pic/fill_water.png)

強化能量板（需要安裝 Applied Flux）：

![P1](../pic/fill_energy.png)


## 開罐

ME裝罐器在空桶模式下也可以從容器中抽取內容物。你需要在樣板中切換輸入和輸出。
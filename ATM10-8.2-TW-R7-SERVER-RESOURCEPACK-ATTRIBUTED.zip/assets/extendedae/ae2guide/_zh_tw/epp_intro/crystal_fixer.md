---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: ME水晶修復器
  icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# ME水晶修復器

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

ME水晶修復器可以修復賽特斯晶芽塊，並將其轉化為升級版。

它需要 <ItemLink id="ae2:charged_certus_quartz_crystal" /> 和電力才能工作。手持 <ItemLink id="ae2:charged_certus_quartz_crystal" /> 右鍵點選它以輸入。

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
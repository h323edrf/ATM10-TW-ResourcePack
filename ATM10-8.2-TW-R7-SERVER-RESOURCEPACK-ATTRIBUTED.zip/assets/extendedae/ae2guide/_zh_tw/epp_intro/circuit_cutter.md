---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 電路切片器
  icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# 電路切片器

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

受不了壓印器的緩慢速度嗎？現在我們有電路切片器了！它們可以直接將材料塊切成處理器
[印模](ae2:items-blocks-machines/processors.md)，因此在大多數情況下速度最多可達到壓印器的 9 倍。

**注意：沒有埠的玻璃面無法連線到網路。**
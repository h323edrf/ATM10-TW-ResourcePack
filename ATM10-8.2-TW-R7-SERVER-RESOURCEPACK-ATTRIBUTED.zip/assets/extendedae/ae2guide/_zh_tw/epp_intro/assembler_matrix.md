---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 裝配矩陣
  icon: extendedae:assembler_matrix_frame
categories:
- extended devices
item_ids:
- extendedae:assembler_matrix_frame
- extendedae:assembler_matrix_wall
- extendedae:assembler_matrix_glass
- extendedae:assembler_matrix_pattern
- extendedae:assembler_matrix_crafter
- extendedae:assembler_matrix_speed
---

# 裝配矩陣

<Row>
<BlockImage id="extendedae:assembler_matrix_frame" p:formed="true" p:powered="true" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_wall" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_glass" scale="5"></BlockImage>
</Row>
<Row>
<BlockImage id="extendedae:assembler_matrix_pattern" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_crafter" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_speed" scale="5"></BlockImage>
</Row>

裝配矩陣是一種多方塊結構。它是 <ItemLink id="ae2:molecular_assembler" /> 與 <ItemLink id="ae2:pattern_provider" /> 的組合。
它可以同時執行大量合成任務（前提是你的 ME 網路中有足夠的 <ItemLink id="ae2:crafting_accelerator" />），並幫你節省頻道。

## 結構

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/assembler_matrix.snbt"></ImportStructure>
</GameScene>

它是一個長方體，邊長介於 3 到 7 之間。 
- 稜由裝配矩陣框架構成。
- 面由裝配矩陣牆/玻璃構成。
- 內部由裝配矩陣樣板/合成/速度核心構成。

一個有效的裝配矩陣必須至少包含一個樣板核心和一個合成核心。
它必須被完全填滿，不能是中空的。
當裝配矩陣正確成型並通電後，裝配矩陣框架上的線條會變成藍色。

## 裝配矩陣核心

共有 3 種不同的裝配矩陣核心。

- 裝配矩陣樣板核心

裝配矩陣只會從其樣板核心中獲取樣板。每個樣板核心可為裝配矩陣提供 36 個樣板槽位。

- 裝配矩陣合成核心

裝配矩陣會將接收到的合成任務分配給它的合成核心。每個合成核心都可以同時執行 8 個合成任務。

- 裝配矩陣速度核心

它是裝配矩陣的 <ItemLink id="ae2:speed_card" />。5 個速度核心即可讓裝配矩陣滿速執行。
安裝超過 5 個速度核心不會帶來額外的速度提升。

## 圖形使用者介面

右鍵點選一個已成型且線上的裝配矩陣即可開啟其 GUI。

![GUI](../pic/assembler_matrix.png)

你可以在其中放入或搜尋樣板，並檢視它當前正在執行多少個合成任務。
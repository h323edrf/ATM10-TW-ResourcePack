---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 擴充套件充能器
  icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# 擴充套件充能器

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

擴充套件充能器是高階的 <ItemLink id="ae2:charger" />。

它可以同時為 4 個物品充能。
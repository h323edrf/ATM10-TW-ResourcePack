---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅粉
  icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# 恩特羅粉

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

你可以透過粉碎一個 <ItemLink id="extendedae:entro_crystal" /> 或破壞[熵化福魯伊克斯晶簇母巖](./entro_budding.md)來獲得它。

它用於製作某些 AE2擴充套件 機器和 <ItemLink id="extendedae:entro_ingot" />。
---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 併發處理器
  icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# 併發處理器

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

併發處理器常用於多執行緒機器，因此它們可以同時處理多項工作。
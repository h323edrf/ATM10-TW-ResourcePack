---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅錠
  icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# 恩特羅錠

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*“恩特羅水晶太過易碎，無法用於機器框架，但我們可以將它與金錠融合來提升其延展性。”*

它用於合成 <ItemLink id="extendedae:machine_frame" /> 以及其他少量 AE2擴充套件 的內容。
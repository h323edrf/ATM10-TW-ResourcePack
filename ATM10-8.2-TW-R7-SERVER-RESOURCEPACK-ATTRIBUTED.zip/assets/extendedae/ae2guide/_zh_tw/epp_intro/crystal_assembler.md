---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 水晶裝配器
  icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# 水晶裝配器

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

這些擴充套件裝置過於複雜，無法在工作臺中製作，而你需要使用水晶裝配器來製作其中的大多數。

**注意：螢幕所在的一面無法連線到網路。**

它還可以執行某些世界內轉化配方，例如福魯伊克斯轉化。
---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅化的福魯伊克斯母巖
  icon: extendedae:entro_budding_fully
categories:
- entro system
item_ids:
- extendedae:entro_budding_fully
- extendedae:entro_budding_mostly
- extendedae:entro_budding_half
- extendedae:entro_budding_hardly
- extendedae:entro_cluster_small
- extendedae:entro_cluster_medium
- extendedae:entro_cluster_large
- extendedae:entro_cluster
---

# 恩特羅化的福魯伊克斯母巖

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/budding_entro.snbt"></ImportStructure>
  <IsometricCamera yaw="195" pitch="30"></IsometricCamera>
</GameScene>

它們是 <ItemLink id="extendedae:entro_crystal" /> 的來源，而你可以透過將 <ItemLink id="extendedae:entro_seed" /> 注入 <ItemLink id="ae2:fluix_block" /> 來獲得恩特羅化的福魯伊克斯母巖。

恩特羅芽的生長機制與[賽特斯石英](ae2:items-blocks-machines/budding_certus.md)相似。然而，恩特羅化的福魯伊克斯母巖的劣化
流程無法避免，最終它會變成 <ItemLink id="ae2:quartz_block" />。
理論上，不帶時運附魔時，你可以從一個完全恩特羅化的福魯伊克斯中獲得約 10 個 <ItemLink id="extendedae:entro_crystal" />。

恩特羅化的福魯伊克斯母巖在被破壞時，無論處於何種狀態，都會始終掉落**一個** <ItemLink id="extendedae:entro_dust" />。
恩特羅芽在未完全長成時會掉落 <ItemLink id="extendedae:entro_shard" />。
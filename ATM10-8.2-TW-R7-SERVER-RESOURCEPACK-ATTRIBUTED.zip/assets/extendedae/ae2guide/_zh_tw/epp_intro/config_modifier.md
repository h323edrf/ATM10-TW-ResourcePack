---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 配置修改器
  icon: extendedae:config_modifier
categories:
- extended items
item_ids:
- extendedae:config_modifier
---

# 配置修改器

配置修改器是一種用於批次修改配置容器的工具。

<ItemImage id="extendedae:config_modifier" scale="4"></ItemImage>

右鍵點選它即可開啟其 GUI。

## 用法

配置修改器可以根據其設定快速修改諸如介面配置容器之類的內容，例如將配置物品的
數量設為最大值，或直接全部移除。

你可以手持配置修改器在世界中點選目標裝置（方塊或部件）來修改其配置。

## 設定

它有兩個主要設定：**修改模式**和**修改數量（X）**。

你可以點選按鈕來切換模式。

![GUI](../pic/cm.png)

- 加/減/乘/除：將配置數量按 X 進行加/減/乘/除。
- 最大化：將配置數量設為最大值。
- 最小化：將配置數量設為最小值。
- 設定：將配置數量設為 X。
- 清除：清空全部配置。
---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅塊
  icon: extendedae:entro_block
categories:
- entro system
item_ids:
- extendedae:entro_block
---

# 恩特羅塊

<Row>
<BlockImage id="extendedae:entro_block" scale="8"></BlockImage>
</Row>

用於儲存 <ItemLink id="extendedae:entro_crystal" /> 的儲存方塊。
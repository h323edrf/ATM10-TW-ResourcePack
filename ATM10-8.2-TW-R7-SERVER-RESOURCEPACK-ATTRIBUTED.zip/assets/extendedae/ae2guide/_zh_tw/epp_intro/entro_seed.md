---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅種子
  icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# 恩特羅種子

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

這些種子蘊含著強大的恩特羅能量。手持恩特羅種子右鍵點選 <ItemLink id="ae2:fluix_block" /> 可將其變為[恩特羅化的福魯伊克斯母巖](./entro_budding.md)，
你也可以使用 <ItemLink id="extendedae:crystal_assembler" /> 注入種子，但與手動方式相比，它產出的[恩特羅化的福魯伊克斯母巖](./entro_budding.md)品級會更低。
---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅碎片
  icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# 恩特羅碎片

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

如果你破壞尚未完全長成的[恩特羅晶簇](./entro_budding.md)，你會獲得恩特羅碎片。8 個恩特羅碎片可以重新合成為
<ItemLink id="extendedae:entro_crystal" />。
---
navigation:
  title: AE2擴充套件簡介
  position: 60
---

# 擴充套件你的 AE 佈局！

Extended AE 為現代 AE 帶回了一些 1.7.10/1.12.2 時代的 AE 功能。

[AE2擴充套件 GitHub](https://github.com/GlodBlock/ExtendedAE)

## 恩特羅水晶系統
<CategoryIndex category="entro system"></CategoryIndex>

## 擴充套件基礎
<CategoryIndex category="extended foundation"></CategoryIndex>

## 擴充套件裝置
<CategoryIndex category="extended devices"></CategoryIndex>

## 擴充套件物品
<CategoryIndex category="extended items"></CategoryIndex>
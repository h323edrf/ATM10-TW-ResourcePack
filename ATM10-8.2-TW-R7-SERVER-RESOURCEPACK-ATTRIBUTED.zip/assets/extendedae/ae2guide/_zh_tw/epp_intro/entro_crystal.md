---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 恩特羅水晶
  icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# 恩特羅水晶

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*“向福魯伊克斯水晶注入末影粉塵後，恩特羅水晶會表現出極強的維度親和性，並能跨越時空產生共振。”*

這是大多數 AE2擴充套件 物品和機器的主要合成材料。你需要使用 <ItemLink id="extendedae:entro_seed" /> 將
<ItemLink id="ae2:fluix_block" /> 轉化為[恩特羅化的福魯伊克斯母巖](./entro_budding.md)，並收穫恩特羅晶簇來獲得恩特羅水晶。
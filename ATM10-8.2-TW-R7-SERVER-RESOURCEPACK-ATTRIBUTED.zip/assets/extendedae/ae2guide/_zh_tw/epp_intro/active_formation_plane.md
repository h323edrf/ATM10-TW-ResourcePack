---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: ME主動成型面板
  icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME主動成型面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME主動成型面板是一種 <ItemLink id="ae2:formation_plane" />，能夠主動放置方塊或丟出物品。

你不需要為它搭建子網路。它的工作方式類似於 <ItemLink id="ae2:export_bus" />，但會放置方塊，而不是
將其輸出到箱子中。
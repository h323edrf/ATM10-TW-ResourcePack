---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: ME擴充套件驅動器
  icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# ME擴充套件驅動器

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

ME擴充套件驅動器是一種 <ItemLink id="ae2:drive" />，擁有更大的儲存元庫存。它可以容納 20 個儲存單元。
---
navigation:
  title: "機器連結器"
  icon: "machine_chainer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:machine_chainer
  - extended_industrialization:machine_chainer_relay
---

# 機器連結器

<GameScene zoom="2" interactive={true} fullWidth={true}>
	<ImportStructure src="machine_chainer_example.nbt" />
	<IsometricCamera yaw="180" pitch="30" />
</GameScene>

機器連結器能沿一條直線，在最多 64 格的範圍內連線許多機器、木桶，或是任何帶有 `#extended_industrialization:machine_chainer/linkable` 標籤的容器方塊。被連線的容器會與連結器合併成同一個共享容器。連結器可以朝向任意方向，包括朝上和朝下。

連結器支援物品、流體和能量的傳輸！不過能量傳輸被限制在同等級單根電纜傳輸速率的 3 倍以內，並且無法與電壓不匹配的已連線機器交換能量。

## 機器連結中繼器

中繼器是一種能被連結器連線、但自身沒有容器的方塊。當你不想為了填補空隙而擺一臺機器時，可以用它來充當已連結機器之間的填充物。

<RecipeFor id="extended_industrialization:machine_chainer_relay" />

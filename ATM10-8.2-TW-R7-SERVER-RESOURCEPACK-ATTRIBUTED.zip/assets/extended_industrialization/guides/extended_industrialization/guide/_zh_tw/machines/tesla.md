---
navigation:
  title: "特斯拉"
  icon: "tesla_coil"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:tesla_calibrator
  - extended_industrialization:tesla_handheld_receiver
  - extended_industrialization:tesla_interdimensional_upgrade
  - extended_industrialization:tesla_coil
  - extended_industrialization:tesla_receiver
  - extended_industrialization:lv_tesla_receiver_hatch
  - extended_industrialization:mv_tesla_receiver_hatch
  - extended_industrialization:hv_tesla_receiver_hatch
  - extended_industrialization:ev_tesla_receiver_hatch
  - extended_industrialization:superconductor_tesla_receiver_hatch
  - extended_industrialization:tesla_tower
  - extended_industrialization:aluminum_tesla_winding
  - extended_industrialization:annealed_copper_tesla_winding
  - extended_industrialization:copper_tesla_winding
  - extended_industrialization:electrum_tesla_winding
  - extended_industrialization:superconductor_tesla_winding
---

# 特斯拉

特斯拉線圈與接收器讓你能以一定代價無線傳輸 EU。一個特斯拉網路只能有一個發射器（特斯拉線圈或特斯拉電塔），對特斯拉接收器的數量則沒有固有限制。每種發射器都有各自的範圍和被動損耗代價。

## 特斯拉校準器

要把特斯拉發射器和接收器連結起來，先手持特斯拉校準器，對發射器按 **<KeyBind id="key.sneak" />** + **<KeyBind id="key.use" />**。然後手持校準器對任意接收器按 **<KeyBind id="key.use" />**，即可完成連結。

<RecipeFor id="extended_industrialization:tesla_calibrator" />

## 特斯拉發射器

特斯拉發射器是每個特斯拉網路的源頭。

發射器無法把能量傳給電壓不完全一致的接收器。舉個例子，裝了進階機器框架的特斯拉線圈無法傳給沒有框架的特斯拉接收器，但可以傳給同樣裝了進階機器框架的那一個。

特斯拉線圈的被動 EU/t 損耗代價，由放入其中的框架電壓決定（不放則另算）。

<RecipeFor id="extended_industrialization:tesla_coil" />

特斯拉電塔傳輸的電壓，由所用的能量輸入倉決定。

特斯拉電塔的被動 EU/t 損耗代價、傳輸上限和範圍，由所用的繞組決定。每種繞組的具體數值寫在它們各自的提示裡。

<Row>
	<GameScene zoom="0.75" interactive={true} fullWidth={false}>
		<MultiblockShape controller="extended_industrialization:tesla_tower" />
	</GameScene>
	<RecipeFor id="extended_industrialization:tesla_tower" />
</Row>

## 特斯拉接收器

特斯拉接收器是你從發射器傳出的能量的目的地。

特斯拉接收器會儲存收到的能量，並從它的輸出面排出。也可以像對待其他任何能量輸出方塊那樣，用電纜從它那裡抽取能量。

<RecipeFor id="extended_industrialization:tesla_receiver" />

特斯拉接收倉接收能量的方式與普通的特斯拉接收器相同，但它同時充當多方塊結構的能量輸入倉。它把兩者合二為一，省得你既要一個接收器、又要一個能量輸入倉來接收它排出的能量。

<RecipeFor id="extended_industrialization:lv_tesla_receiver_hatch" />

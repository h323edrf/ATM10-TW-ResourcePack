---
navigation:
  title: "釀造機"
  icon: "electric_brewery"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steel_brewery
  - extended_industrialization:electric_brewery
  - extended_industrialization:blazing_essence_bucket
---

# 釀造機

<Row>
	<RecipeFor id="extended_industrialization:steel_brewery" />
	<RecipeFor id="extended_industrialization:electric_brewery" />
</Row>

釀造機像普通機器那樣工作，但它執行的是釀造臺的配方。不過有幾處不同。

釀造機吃的是烈焰精華，而不是烈焰粉。每釀造一批藥水，它正好消耗 1 mB 烈焰精華。

釀造機一次正好釀造 _4 瓶_ 藥水，而不像釀造臺那樣允許 1 到 3 瓶。

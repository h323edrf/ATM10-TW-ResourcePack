---
navigation:
  title: "太陽能"
  icon: "lv_solar_panel"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:bronze_solar_boiler
  - extended_industrialization:steel_solar_boiler
  - extended_industrialization:lv_solar_panel
  - extended_industrialization:mv_solar_panel
  - extended_industrialization:hv_solar_panel
  - extended_industrialization:lv_photovoltaic_cell
  - extended_industrialization:mv_photovoltaic_cell
  - extended_industrialization:hv_photovoltaic_cell
---

# 太陽能

## 太陽能鍋爐

太陽能鍋爐的運作方式與普通的青銅鍋爐、鋼鍋爐類似，但它不消耗任何燃料。作為代價，它的正上方必須能照到陽光，而且產出的能量只有同型別標準鍋爐的一半。當然，它仍然需要水。

隨著時間推移，太陽能鍋爐會鈣化並損失效率，最多損失 33%。對太陽能鍋爐使用斧頭可以重置它的鈣化狀態。改用蒸餾水代替普通水，則能完全避免鈣化。

<Row>
	<RecipeFor id="extended_industrialization:bronze_solar_boiler" />
	<RecipeFor id="extended_industrialization:steel_solar_boiler" />
</Row>

## 太陽能板

太陽能板放置在能直射到陽光的地方，並裝入對應等級的光伏電池後即可產出能量。隨著時間推移，光伏電池會磨損，最終損壞。這意味著必須持續不斷地生產光伏電池，才能在白天穩定地發電。為太陽能板供給蒸餾水，可以讓光伏電池的壽命延長一倍。

<Row>
	<RecipeFor id="extended_industrialization:lv_solar_panel" />
	<RecipeFor id="extended_industrialization:mv_solar_panel" />
	<RecipeFor id="extended_industrialization:hv_solar_panel" />
</Row>

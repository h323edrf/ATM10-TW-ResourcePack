---
navigation:
  title: "批次處理多方塊"
  icon: "processing_array"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:large_steam_furnace
  - extended_industrialization:large_steam_macerator
  - extended_industrialization:large_electric_furnace
  - extended_industrialization:large_electric_macerator
  - extended_industrialization:processing_array
---

# 批次處理多方塊

某些多方塊結構能像同型別的普通機器那樣運作，但會給它一次能處理的輸入量乘上一個倍數。也就是說，一臺能以 Y 份為一批執行某類配方的多方塊結構，一次可以消耗 1 到 Y 倍的輸入，並按當前的批次大小產出對應的結果。機器消耗的 EU/t 同樣會乘上它當前執行的批數。

批次處理多方塊能跑多少批各不相同。具體數值請檢視該機器物品上的提示。

和其他機器完全一樣，它們也無法同時執行一個以上的配方。

## 大型爐

大型電爐能跑多少批，取決於多方塊結構中使用的線圈，與電力高爐的搭建方式類似。某種線圈在爐中能提供多大的批次，請檢視該線圈的提示。

<Row>
	<RecipeFor id="extended_industrialization:large_steam_furnace" />
	<RecipeFor id="extended_industrialization:large_electric_furnace" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_furnace" />
    <MultiblockShape controller="extended_industrialization:large_electric_furnace" x="-6" y="-1" z="-6" />
</GameScene>

## 大型研磨機

<Row>
	<RecipeFor id="extended_industrialization:large_steam_macerator" />
	<RecipeFor id="extended_industrialization:large_electric_macerator" />
</Row>

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:large_steam_macerator" />
    <MultiblockShape controller="extended_industrialization:large_electric_macerator" x="-6" z="-6" />
</GameScene>

## 處理陣列

處理陣列能批次執行任何放入其介面的單方塊電動合成機器的配方。它能跑多大的批次，受自身尺寸以及放入的機器數量限制。

<RecipeFor id="extended_industrialization:processing_array" />

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:processing_array" />
    <MultiblockShape controller="extended_industrialization:processing_array" useBigShape={true} x="-6" z="-8" />
</GameScene>

---
navigation:
  title: "農耕機"
  icon: "steam_farmer"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:steam_farmer
  - extended_industrialization:electric_farmer
---

# 農耕機

<Row>
	<RecipeFor id="extended_industrialization:steam_farmer" />
	<RecipeFor id="extended_industrialization:electric_farmer" />
</Row>

農耕機不是那種執行配方的典型機器，它做的是耕地、保溼土壤、種植、施肥，以及收穫作物、植物和樹木。這些任務並不是全都得用上農耕機才能工作，事實上有時你反而會想避開其中某些任務。例如在打理樹木時，你就不會希望農耕機去耕地或保溼土壤。

能量不足時農耕機不會運轉。蒸汽農耕機需要 32 EU/t 的蒸汽，電動農耕機需要 64 EU/t。

農耕機多方塊結構中所需的泥土，可以換成任何帶有 `#extended_industrialization:farmer_dirt` 標籤的方塊。

## 任務

### 耕地

在多方塊結構的形狀設定中啟用後，屬於該多方塊結構的泥土方塊會像被鋤頭鋤過一樣，轉化為耕地。

### 保溼

當農耕機透過輸入倉獲得水時，它會讓所有耕地保持溼潤，無需在附近放水。

### 種植

當農耕機的輸入倉中有可種植的物品時，它會把它們種到作業範圍內任何合適的方塊上。只有帶 `#extended_industrialization:farmer_plantable` 物品標籤的物品才能被種植。

### 施肥

施肥是電動農耕機獨有的。當輸入倉中提供了可用的流體肥料（可在 EMI 中檢視）時，農耕機會對作業範圍內的植物施加類似骨粉的效果。這種類似骨粉的效果，對仙人掌、甘蔗這類通常無法使用骨粉的植物同樣有效。

### 收穫

當有植物已經完全成熟（比如長好的小麥，或是樹苗已經長成樹），並且輸出倉中有足夠的存放空間時，它就會被破壞並收進倉裡。

帶有 `#extended_industrialization:farmer_voidable` 標籤的物品在存入輸出倉時優先順序較低，若在被收穫的方塊掉落它時已經沒有空位，它會被直接丟棄。<ItemLink id="minecraft:stick" /> 和 <ItemLink id="minecraft:apple" /> 就是這類物品的例子——這意味著你可以把輸出倉的輸出槽位鎖定為只放原木和樹苗，不必操心怎麼存放那些東西。

## 蒸汽農耕機

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:steam_farmer" />
    <MultiblockShape controller="extended_industrialization:steam_farmer" useBigShape={true} x="-10" z="-10" />
</GameScene>

## 電動農耕機

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_farmer" />
    <MultiblockShape controller="extended_industrialization:electric_farmer" useBigShape={true} x="-12" z="-12" />
</GameScene>

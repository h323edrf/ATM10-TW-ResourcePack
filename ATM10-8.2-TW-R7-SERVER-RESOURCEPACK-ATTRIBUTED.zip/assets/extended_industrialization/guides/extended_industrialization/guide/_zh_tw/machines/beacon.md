---
navigation:
  title: "電力信標"
  icon: "electric_beacon"
  parent: extended_industrialization:machines.md
categories:
  - machines
item_ids:
  - extended_industrialization:electric_beacon
---

# 電力信標

<RecipeFor id="extended_industrialization:electric_beacon" />

電力信標消耗藥水，以每種效果 256 EU/t 的代價，把效果提供給附近所有玩家。一瓶藥水在信標裡能持續多久，取決於它最短的那個效果，再減半。多數情況下藥水只有一種效果。舉個例子，一瓶 8 分鐘的迅捷藥水被信標消耗後，會在範圍內提供總共 4 分鐘的效果，代價是 256 EU/t。同樣地，一瓶 40 秒的龜仙人藥水只能維持 20 秒，卻要花 512 EU/t，因為它有兩種效果（緩慢和抗性提升）。由於藥水會被信標消耗掉，建議用[釀造機](brewery.md)搭一套自動化迴圈，好讓信標一直運轉下去。

信標的範圍比普通訊標更大，由它下方的層數決定（不含鋼製機器外殼）。

| 層數 | 範圍 |
|------|------|
| 1    | 30   |
| 2    | 50   |
| 3    | 70   |
| 4    | 90   |

<GameScene zoom="1.5" interactive={true} fullWidth={true}>
    <MultiblockShape controller="extended_industrialization:electric_beacon" />
    <MultiblockShape controller="extended_industrialization:electric_beacon" useBigShape={true} x="-9" y="2" z="-9" />
</GameScene>

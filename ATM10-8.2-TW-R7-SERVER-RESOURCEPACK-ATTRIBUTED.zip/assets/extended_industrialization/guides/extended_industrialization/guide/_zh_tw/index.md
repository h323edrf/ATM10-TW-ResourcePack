---
navigation:
  title: "擴充套件工業化"
  position: 0
---

# 擴充套件工業化

<MarginFloatingImage src="assets/logo.png" left="0" right="10" />

擴充套件工業化是現代工業化的附屬模組，加入了各式各樣的機器與工具！

擴充套件工業化的首要目標，是在忠於現代工業化設計思路與用途的前提下，把它的內容拓展到更多領域。例如[批次處理多方塊](machines/batching_multiblocks.md)的加入，讓你在少配置幾臺機器、還更省效能的同時，把工廠的規模推得比以往更大。

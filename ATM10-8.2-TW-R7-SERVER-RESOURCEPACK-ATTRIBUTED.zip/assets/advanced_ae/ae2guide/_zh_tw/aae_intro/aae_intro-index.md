---
navigation:
  title: 高階AE簡介
  position: 70
---

# 高階AE！

高階AE專注於提升處理 ME 系統時的使用者體驗，並拓展遊戲後期各類系統的可能性。
這個模組允許你升級樣板供應器，使其具備將物品推送到目標機器特定面的能力；還能建立可執行無限量合成任務的多方塊計算機，在仍有合成儲存可用時共享協處理器；此外還有大量其他提升體驗的內容！

![PEGui1](../pic/aae_intro.png)

要檢視所提供方塊和物品的完整列表，請參閱以下指南頁面：

## 高階裝置

<CategoryIndex category="advanced devices"></CategoryIndex>

## 高階物品

<CategoryIndex category="advanced items"></CategoryIndex>

發現問題了？缺少某項功能？
請在此反饋：
[高階AE GitHub](https://github.com/pedroksl/AdvancedAE)
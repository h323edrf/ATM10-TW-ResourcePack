---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 庫存輸出匯流排
  icon: advanced_ae:stock_export_bus_part
categories:
- advanced items
item_ids:
- advanced_ae:stock_export_bus_part
---

# 庫存輸出匯流排

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

庫存輸出匯流排可配置為精確匯出過濾物品堆的指定數量。它會追蹤目標容器中
當前已有的數量，並且不會插入超過該數字的內容。配置方式是：開啟 GUI，將
目標物品拖入過濾槽，然後透過中鍵點選來設定數量。注意，它不會調節輸出，
這意味著如果容器中的物品/流體超過設定數量，它不會把多餘的部分提取出來。
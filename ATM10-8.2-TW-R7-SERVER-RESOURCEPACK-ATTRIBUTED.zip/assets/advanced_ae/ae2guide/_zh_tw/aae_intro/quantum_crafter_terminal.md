---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子合成器終端
  icon: advanced_ae:quantum_crafter_terminal
categories:
- advanced devices
item_ids:
- advanced_ae:quantum_crafter_terminal
- advanced_ae:wireless_quantum_crafter_terminal
---

# 量子合成器終端

<Row gap="20">
<ItemImage id="advanced_ae:quantum_crafter_terminal" scale="4"></ItemImage>
<ItemImage id="advanced_ae:wireless_quantum_crafter_terminal" scale="4"></ItemImage>
</Row>

量子合成器終端允許玩家在一個位置管理整張網路中的 <ItemLink id="advanced_ae:quantum_crafter"/>。
無線版本則便於你隨時隨地修改設定，只需將其插入到
無線接入點中並與網路連結即可使用！

<Row gap="20">
<RecipeFor id="advanced_ae:quantum_crafter_terminal" />
<RecipeFor id="advanced_ae:wireless_quantum_crafter_terminal" />
</Row>
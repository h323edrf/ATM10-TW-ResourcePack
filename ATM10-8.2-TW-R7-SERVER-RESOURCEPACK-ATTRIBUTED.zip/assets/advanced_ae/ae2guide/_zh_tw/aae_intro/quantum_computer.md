---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子計算機
  icon: advanced_ae:quantum_core
categories:
- advanced devices
item_ids:
- advanced_ae:quantum_unit
- advanced_ae:quantum_core
- advanced_ae:quantum_structure
- advanced_ae:quantum_accelerator
- advanced_ae:quantum_multi_threader
- advanced_ae:quantum_storage_128
- advanced_ae:quantum_storage_256
- advanced_ae:data_entangler
---

# 量子計算機

量子計算機是一種特殊的合成計算機。只要擁有足夠的合成儲存，
它就能夠執行無限數量的合成請求。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## 量子核心

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

量子核心是量子計算機的核心。它自身擁有 256M 合成儲存和 8 條協處理器執行緒。
它是唯一一個可以單獨形成量子計算機並提供量子計算機全部優勢的方塊。
不過，如果用於構建多方塊結構，就能建立更強大的計算機。作為獨立計算機使用時，
必須從帶有聯結器的上側或下側輸入電力。

## 量子儲存

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

這些方塊可擴充套件量子核心的合成儲存。它們實際上提升了
量子計算機可同時執行的任務數量。共有兩種版本，容量分別為 128M 和 256M。

## 量子資料糾纏器

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

資料糾纏器是一種特殊方塊，會影響多方塊結構中存在的所有儲存方塊。它們使儲存
方塊能夠在多個維度中儲存資料，實際上將其儲存容量提升為 4 倍。每個量子計算機多方塊結構中
只能放置一個。

## 量子加速器

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

量子加速器會為量子計算機多方塊結構增加 8 個協處理器。需要注意的是，所有由量子計算機
執行的合成樣板都能夠共享這些協處理器，因此投入大量這類部件通常是個不錯的選擇。

## 量子多執行緒處理器

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

與資料糾纏器類似，多執行緒處理器可讓加速器在獨立維度中執行額外執行緒，
使其協處理能力提升為 4 倍。每個量子計算機多方塊結構中只能放置一個。

## 量子結構

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

這些方塊構成了量子計算機的框架。它們用作量子計算機的構建方塊，
並將所有部分連線在一起。

## 多方塊結構

要建立一個多方塊量子計算機，必須遵守一些規則：
- 最大尺寸為 7x7x7（外部尺寸）；
- 多方塊結構內部不能有空隙。可以用 <ItemLink id="advanced_ae:quantum_unit" />
填充，但不會帶來額外收益；
- 恰好一個 <ItemLink id="advanced_ae:quantum_core" />；
- 最多一個 <ItemLink id="advanced_ae:data_entangler" />；
- 最多一個 <ItemLink id="advanced_ae:quantum_multi_threader" />；
- 外層上的所有方塊都必須是 <ItemLink id="advanced_ae:quantum_structure" />；
- 內部不能有任何方塊是 <ItemLink id="advanced_ae:quantum_structure" />。

## 伺服器配置

有多個數值可以透過伺服器配置進行調整，例如：
- 多方塊結構的最大尺寸；
- 每個量子加速器中的協處理器數量；
- 量子多執行緒處理器的最大數量；
- 多執行緒處理器的執行緒倍率；
- 資料糾纏器的最大數量；
- 資料糾纏器的儲存倍率；

你當前例項的限制可以透過物品的工具提示檢視。
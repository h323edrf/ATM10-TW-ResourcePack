---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 輸入輸出匯流排
  icon: advanced_ae:import_export_bus_part
categories:
- advanced items
item_ids:
- advanced_ae:import_export_bus_part
---

# 輸入輸出匯流排

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

輸入/輸出匯流排是 <ItemLink id="ae2:import_bus" /> 和 <ItemLink id="ae2:export_bus" /> 的結合體。
過濾器可用於配置要匯出的物品堆。任何不在過濾器中的內容，都會被視為可匯入的有效物品堆。
---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME高階樣板供應器
  icon: advanced_ae:adv_pattern_provider
categories:
- advanced devices
item_ids:
- advanced_ae:adv_pattern_provider
- advanced_ae:small_adv_pattern_provider
- advanced_ae:adv_pattern_provider_part
- advanced_ae:small_adv_pattern_provider_part
---

# ME高階擴充套件樣板供應器

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

ME高階擴充套件樣板供應器是一種新型的 <ItemLink id="ae2:pattern_provider" />，可將
標準版本或 <ItemLink id="extendedae:ex_pattern_provider" /> 升級為能夠配置樣板中每個獨立物品應推送到
哪個面的版本。這一強大擴充套件使得那些
需要從特定側面輸入特定材料的機器，也能只用一個方塊且無需管道實現自動化！

*我說的就是你，Mekanism。*

要使用此功能，你需要插入一個 <ItemLink id="advanced_ae:adv_processing_pattern" />。其製作方式是將一個已編碼樣板放入 <ItemLink id="advanced_ae:adv_pattern_encoder" /> 中，然後取出其高階版本。

還有一個擴充套件版本，單個樣板供應器最多可容納 36 個樣板。

![AAEGui](../pic/app_gui.png)
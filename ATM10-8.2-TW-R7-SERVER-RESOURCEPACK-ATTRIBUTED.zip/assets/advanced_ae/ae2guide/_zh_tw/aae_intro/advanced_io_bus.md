---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 高階IO匯流排
  icon: advanced_ae:advanced_io_bus_part
categories:
- advanced items
item_ids:
- advanced_ae:advanced_io_bus_part
---

# 高階IO匯流排

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

高階IO匯流排是與外部容器互動的強大工具。它由
一個 <ItemLink id="advanced_ae:import_export_bus_part"/> 和一個 <ItemLink id="advanced_ae:stock_export_bus_part"/> 融合而成，繼承了
兩者的功能。此外，高階IO匯流排的基礎速度是 <ItemLink id="ae2:export_bus"/> 基礎速度的 8 倍。雖然它需要一些時間來逐步提速，但在完全升級後會快得驚人。

## 輸出

高階IO匯流排會根據過濾器匯出內容，直到達到設定的固定數量後停止。在 UI 左側
還有一項配置，允許使用者選擇是否調節物品庫存。

## 匯入

高階IO匯流排還會匯入所有未被過濾為匯出的內容。匯入和匯出操作
是分別計算的，因此匯流排不會卡在只執行其中一種操作上。當匯流排被配置為調節模式時，它會
優先匯入所有超過設定數量的內容。如果還有剩餘操作次數，則會匯入未被過濾的內容。

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>
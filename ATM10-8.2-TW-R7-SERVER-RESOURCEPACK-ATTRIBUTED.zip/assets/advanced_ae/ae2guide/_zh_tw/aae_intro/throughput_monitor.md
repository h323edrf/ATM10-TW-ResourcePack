---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME吞吐量監控器
  icon: advanced_ae:throughput_monitor
categories:
- advanced items
item_ids:
- advanced_ae:throughput_monitor
- advanced_ae:throughput_monitor_configurator
---

# ME吞吐量監控器

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

吞吐量監視器是監視器的一個子型別。它提供與 <ItemLink id="ae2:storage_monitor" />
相同的功能，並額外增加了吞吐量計量功能。它會追蹤單一種物品/流體，並監控其
數量變化，向玩家顯示每秒變化量。

它*不*需要頻道。

## 按鍵繫結

*   手持物品右擊，或用流體容器雙擊右擊，將監控器設定為該物品/流體。
*   空手右擊以清除監控器。
*   空手 Shift+右擊以鎖定監控器。

## 吞吐量監視器配置器

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

吞吐量監控配置器是一種可用於更改顯示資料的工具。手持它對監視器右鍵點選
可在三個選項之間迴圈切換：

* 每刻物品數
* 每秒物品數
* 每分鐘物品數

注意：切換模式後，讀數可能需要一些時間才能穩定下來，因此不要相信初始數值！
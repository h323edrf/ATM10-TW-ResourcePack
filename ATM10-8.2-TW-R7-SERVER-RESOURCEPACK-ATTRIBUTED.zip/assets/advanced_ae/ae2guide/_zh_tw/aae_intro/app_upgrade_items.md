---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 高階樣板供應器升級物品
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
- advanced items
item_ids:
- advanced_ae:adv_pattern_provider_upgrade
- advanced_ae:adv_pattern_provider_capacity_upgrade
---

# 高階樣板供應器升級

這是 AdvancedAE 的供應器物品，讓你無需移動所有樣板和
升級，就能升級樣板供應器。

## 高階樣板供應器升級

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

這些升級可用於普通 AE 樣板供應器以及 AE2擴充套件 的擴充套件樣板供應器。對這些機器使用後，
會將它們升級為高階版本，同時保留原有的槽位數量。這意味著在將普通供應器升級為擴充套件供應器的過程中，
你不會損失此前用於升級的材料。

## 高階樣板供應器容量升級

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

容量升級可直接將普通樣板供應器升級為高階樣板供應器，使其擁有 36 個樣板
槽位。
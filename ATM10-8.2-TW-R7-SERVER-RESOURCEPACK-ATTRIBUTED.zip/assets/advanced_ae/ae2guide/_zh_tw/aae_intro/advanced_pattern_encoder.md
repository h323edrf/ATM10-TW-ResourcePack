---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 高階樣板編碼器
  icon: advanced_ae:adv_pattern_encoder
categories:
- advanced items
item_ids:
- advanced_ae:adv_pattern_encoder
- advanced_ae:adv_processing_pattern
---

# 高階樣板編碼器

為了讓 ME高階擴充套件樣板供應器知道該把物品傳送到哪裡，需要一種特殊裝置來編碼這些
資訊。手持它右鍵點選即可開啟其 GUI。

<ItemImage id="advanced_ae:adv_pattern_encoder" scale="4"></ItemImage>

編碼後的處理樣板可以插入左側槽位，隨後會被解碼，所有原材料將
以列表形式顯示出來。

![PEGui1](../pic/ape_pattern.png)

每一行都包含一組按鈕，用來表示該材料可被髮送到的所有可能方塊面。
如果將選擇保留在 “A” 按鈕上，它會被髮送到與樣板供應器直接連線的那一面；而如果選擇某個特定面，則會強制物品插入到該面。
需要注意的是，高階樣板只能由 <ItemLink id="advanced_ae:adv_pattern_provider" /> 正確解析，
如果在其他型別的樣板供應器中使用，則會像普通樣板一樣運作。
此外，如果單個物品無法插入到指定的面中，則不會按方向插入任何物品，而是會應用標準的樣板供應器行為。
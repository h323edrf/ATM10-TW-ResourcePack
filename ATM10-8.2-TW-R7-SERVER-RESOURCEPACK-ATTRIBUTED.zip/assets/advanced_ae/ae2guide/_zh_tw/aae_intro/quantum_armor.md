---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 量子盔甲套裝
  icon: advanced_ae:quantum_helmet
categories:
- advanced items
item_ids:
- advanced_ae:quantum_helmet
- advanced_ae:quantum_chestplate
- advanced_ae:quantum_leggings
- advanced_ae:quantum_boots
- advanced_ae:quantum_upgrade_base
- advanced_ae:walk_speed_card
- advanced_ae:sprint_speed_card
- advanced_ae:step_assist_card
- advanced_ae:jump_height_card
- advanced_ae:lava_immunity_card
- advanced_ae:flight_card
- advanced_ae:water_breathing_card
- advanced_ae:auto_feeding_card
- advanced_ae:auto_stock_card
- advanced_ae:magnet_card
- advanced_ae:hp_buffer_card
- advanced_ae:evasion_card
- advanced_ae:regeneration_card
- advanced_ae:strength_card
- advanced_ae:attack_speed_card
- advanced_ae:luck_card
- advanced_ae:reach_card
- advanced_ae:swim_speed_card
- advanced_ae:night_vision_card
- advanced_ae:flight_drift_card
- advanced_ae:recharging_card
- advanced_ae:portable_workbench_card
- advanced_ae:pick_craft_card
---

# 量子盔甲套裝

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

你是否曾想過，把你的 AE 系統穿在身上會是什麼感覺？現在你不用再猜了。量子盔甲套裝是一套高度科技化、兼具隱蔽性的裝備，能夠連線到 AE2 系統，讓你隨時隨地方便地取用一切物品！預設情況下，它是一套由能量驅動的護甲，防禦能力可與下界合金裝備媲美。它還能利用自身的緩衝能量生成能量盾，提供相當可觀的傷害吸收。靴子還可免疫摔落傷害，而胸甲則能移除飛行時的挖掘速度懲罰。不過，這套護甲真正的力量，只有在你為其裝滿升級後才會徹底解鎖！

<br/>

## 連線護甲

這些護甲部件可以透過插入到 <ItemLink id="ae2:wireless_access_point" /> 的相應槽位中，
分別連結到系統。根據裝備部件以及已安裝的升級
卡，會解鎖不同的特性。後面會詳細介紹。請注意，要讓這些額外功能正常工作，你還必須處於
已連線接入點的範圍內。

<br/>

## 安裝升級

要安裝升級，你需要先裝備對應部件，然後按下快捷鍵（預設為 N）
開啟量子裝甲配置選單。

![QAGUI](../pic/quantum_armor_config.png)

在這個介面中，你可以新增/移除升級，也可以將它們切換為開啟/關閉狀態，並配置那些帶有設定項的
升級。

<br/>

## 量子升級基礎卡

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

<ItemLink id="advanced_ae:quantum_upgrade_base" /> 本身沒有任何特殊作用，但它可用作
所有升級卡的合成材料。

<br/>

## 自動飼育卡

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_feeding_card" /> 可讓你選擇用於給
玩家進食的特定物品。只需將所需物品拖入篩選槽位中，如果該裝備已連線到 AE2 網路，它就會在玩家飢餓時嘗試
從系統中找到這些物品並餵給玩家。

<br/>

## 自動補貨卡

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_stock_card" /> 同樣要求該裝備部件已連線到 AE2 系統，
並且位於接入點的有效範圍內。它可以配置若干組物品，使其在使用者物品欄中始終維持特定數量。
這些槽位並不限於一組，因此如果你願意，也可以將其設定為始終在物品欄中保持超過一格的數量。

<br/>

## 速度卡

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

這些升級卡可以提升佩戴者的移動速度。它們都可以配置你想要的移動速度，
並且也會影響潛行和飛行時的移動。需要注意的是，這些升級同樣可以用來
降低速度，以便在已經存在其他加速效果時獲得更好的控制。

<br/>

## 高度卡

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

這些升級會改變垂直移動方式，允許你配置更高的跳躍高度或自動跨步輔助。

<br/>

## 飛行卡

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### 飛行卡

安裝後，<ItemLink id="advanced_ae:flight_card" /> 可啟用創造飛行。飛行速度可以透過
UI 中的滑塊進行配置。它還會疊加受到步行/疾跑速度升級的影響。

### 飛行慣性卡

<ItemLink id="advanced_ae:flight_drift_card" /> 只有在安裝了飛行卡時才會生效，它會額外新增一個
配置滑塊，用於調整影響創造飛行的慣性。數值越低，你停下來的速度越快；當該值設為 0 時，
會瞬間停止。

<br/>

## ME無線充能卡

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:recharging_card" /> 可為所裝備的部件啟用無線充能。這要求它已
連線到網路，並且位於接入點範圍內。若將此升級安裝在胸甲上，還有一個額外好處：
它也會為物品欄槽位充能。

<br/>

## 行動式元件工作臺卡

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:portable_workbench_card" /> 為量子套裝新增了一個行動式儲存元件工作臺。要開啟
它，你需要按下已配置的快捷鍵。它的工作方式與方塊形式相同。

<br/>

## 點選合成卡

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:pick_craft_card" /> 為這套盔甲新增了一個熱鍵功能。按下後會嘗試
合成玩家當前瞄準的方塊。該功能要求存在與網路終端的連結，並且有一個
與目標匹配的樣板。隨後會彈出一個視窗要求輸入所需數量，其處理流程與普通的
自動合成請求完全相同。

<br/>

## 實用卡

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

這些卡片會為套裝穿戴者提供多種實用效果，使其免疫某些型別的傷害並獲得
夜視效果。其中，磁鐵卡尤其特別，它帶有一個設定介面，你可以在其中設定要拾取或不拾取的物品過濾器，
並配置其作用範圍。

<br/>

## 防禦卡

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" />
* <ItemLink id="advanced_ae:regeneration_card" />
* <ItemLink id="advanced_ae:evasion_card" />

這些升級會以多種形式為套裝穿戴者提供防禦方面的增益。生命值卡會提升最大
生命值，而再生卡會提高生命恢復速度。閃避卡則有機率使你對任意傷害來源完全
免疫。

<br/>

## 攻擊卡

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

這些升級會提升穿戴者的進攻能力，提供攻擊傷害和攻擊速度加成。

<br/>

## 屬性卡

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" />
* <ItemLink id="advanced_ae:reach_card" />

這些升級卡會為穿戴者提供固定屬性加成，影響幸運值以獲得更好的掉落結果，並增加方塊觸及
距離。觸及卡可以配置為你想要的具體數值。

<br/>

## 更多內容即將到來

這套裝置已作為基礎內容釋出，後續還計劃推出大量其他功能，敬請期待！
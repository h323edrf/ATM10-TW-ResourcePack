---
navigation:
  title: 附屬：AE2輸入輸出卡
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
- ae2importexportcard:block_picker_card
---

# AE2輸入輸出卡

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />

  <ItemImage id="ae2importexportcard:import_card" scale="2" />

  <ItemImage id="ae2importexportcard:block_picker_card" scale="2" />
</Row>

輸入卡、輸出卡和選取方塊卡可透過玩家物品欄輸入/輸出物品。

## 輸入卡

<ItemImage id="ae2importexportcard:import_card" scale="2" />

輸入卡會將你物品欄特定槽位中的物品存入ME系統。

![輸入卡](diagrams/import_card.png)

點選槽位可進行標記。標記槽位中的任意物品都會輸入ME系統。將物品拖放到介面上方以進行過濾。

### 升級

輸入卡支援如下[升級](items-blocks-machines/upgrade_cards.md)：

*   <ItemLink id="fuzzy_card" />使得該卡能按耐久度或忽略物品NBT過濾
*   <ItemLink id="inverter_card" />將白名單變為黑名單

### 配方

<RecipeFor id="ae2importexportcard:import_card" />

## 輸出卡

<ItemImage id="ae2importexportcard:export_card" scale="2" />

輸出卡的運作方式與輸入卡完全一致，只不過是會從ME網路中抽取物品放入玩家物品欄。

![輸出卡](diagrams/export_card.png)

從物品欄中拖動物品至介面上方的槽位，再點選物品欄中槽位，將其標號修改為上方槽位對應的數，即可規定抽取的物品種類。右擊可重置為無數字。

### 升級

輸出卡支援如下[升級](items-blocks-machines/upgrade_cards.md)：

*   <ItemLink id="fuzzy_card" />使得該卡能按耐久度或忽略物品NBT過濾
*   <ItemLink id="speed_card" />增加每次傳輸時移動的物品數，可從1個物品升級至整組物品
*   <ItemLink id="crafting_card" />使該卡能請求合成當前不可用的物品

### 配方

<RecipeFor id="ae2importexportcard:export_card" />

## 選取方塊卡

<ItemImage id="ae2importexportcard:block_picker_card" scale="2" />

選取方塊卡可從網路中直接取出你當前注視的方塊。只需瞄準一個方塊並按下“選取方塊”按鍵；若網路中有匹配的方塊，它就會被取出並放入你的物品欄。

![選取方塊卡](diagrams/block_picker_card.png)

### 配方

<RecipeFor id="ae2importexportcard:block_picker_card" />

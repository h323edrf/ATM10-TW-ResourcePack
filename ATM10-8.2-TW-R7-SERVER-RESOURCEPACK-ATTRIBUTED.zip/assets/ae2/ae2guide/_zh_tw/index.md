---
navigation:
  title: 內容目錄
  position: 0
---

![Logo](assets/logo.png)

# 應用能源 2是什麼？

# 如何使用此指南

* 左側為側邊欄，其中有所有條目的目錄。
* 許多頁面都有互動示例圖。若示例圖旁邊有![加號](assets/diagrams/plus.png)和![減號](assets/diagrams/minus.png)（縮放）按鈕，即可旋轉和移動視角。按住左鍵拖拽以旋轉，按住右鍵拖拽以平移。

# 應用能源 2是什麼？

應用能源 2（Applied Energistics 2）為物流與儲存新增了各類元件與機制。你可以將自己原先一大間屋子的箱子替換成一個緊湊的ME網路，而這也只是冰山一角。應用能源應當與模組包內其他模組一起運作並將其自動化。只需一次點選，就能讓系統自動合成複雜合成鏈上的每一箇中間產物以及最終產物，或是在庫存中維持物品的數量，根據需求合成更多，抑或僅是向基地各處傳輸物品。

* [開始與入門](getting-started.md)
* [提示與技巧](tips-and-tricks.md)
* [AE2機制](ae2-mechanics/ae2-mechanics-index.md)
* [設施示例](example-setups/example-setups-index.md)
* [物品、方塊與機器](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
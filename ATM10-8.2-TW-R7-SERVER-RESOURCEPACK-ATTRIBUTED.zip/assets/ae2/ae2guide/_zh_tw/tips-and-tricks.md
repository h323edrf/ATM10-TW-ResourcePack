---
navigation:
  title: 提示與技巧
  position: 20
---

# 提示與技巧

一大堆小推薦。

* 移除Optifine。
* 可以旋轉或縮放帶有縮放和顯隱註釋圖示的指南示例圖。
* 保持網路的樹狀結構，避免構造環狀結構。
* 方塊形態[裝置](ae2-mechanics/devices.md)一區域最多8個，除非你對[頻道](ae2-mechanics/channels.md)在網路中的分佈瞭解很深。
* 在所有[樣板](items-blocks-machines/patterns.md)中只採用一種木材。允許樣板使用替代材料偶爾確實有用，但在所有地方都用同種木材能大大減少麻煩。
* 在<ItemLink id="pattern_access_terminal" />中縱向排布[樣板](items-blocks-machines/patterns.md)，或是將樣板分到各[供應器](items-blocks-machines/pattern_provider.md)中以並行使用配方。
* 加入[能源元件](items-blocks-machines/energy_cells.md)以處理網路能量尖峰。
* 可向<ItemLink id="condenser" />輸入水。
* 保持網路通暢的最好方式是不放入劍、盔甲之類的生物隨機掉落物，每一種魔咒和耐久度的組合都分屬不同[型別](ae2-mechanics/bytes-and-types.md)。
* 傳輸回[處理樣板](items-blocks-machines/patterns.md)的產物時必須發生一次“物品輸入系統”事件，例如透過<ItemLink id="import_bus" />、<ItemLink id="interface" />，或是<ItemLink id="pattern_provider" />的返回欄，不能只將產物輸入接有<ItemLink id="storage_bus" />的箱子。
* 切記你可以旋轉或縮放帶有縮放和顯隱註釋圖示的指南示例圖。
* <ItemLink id="pattern_provider" />只會傳出完整的配方材料批次，且只會從一面傳出。此特性可避免機器只拿到一部分原材料，但有時會需要把材料供給到多個位置，這項需求可用<ItemLink id="interface" />實現：用作[“管道”子網路](example-setups/pipe-subnet.md)，或是利用其能同時儲存多種不同的物品組、流體、化學品等的能力作為緩衝箱子/儲罐。
* 可以旋轉或縮放帶有縮放和顯隱註釋圖示的指南示例圖。
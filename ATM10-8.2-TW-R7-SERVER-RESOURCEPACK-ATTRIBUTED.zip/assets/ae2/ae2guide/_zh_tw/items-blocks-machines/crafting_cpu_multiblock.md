---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 合成CPU多方塊結構（合成儲存器、並行處理單元、合成監控器、合成單元）
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# 合成CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

合成CPU管理合成請求與合成任務。它們會在執行多步驟合成任務時將中間產物存於自身，並影響合成任務的大小上限，某種程度上也會影響這些任務的完成速度。詳細資訊見[自動合成](../ae2-mechanics/autocrafting.md)。

每個合成CPU一次只能處理1個請求或任務，因此若要同時請求一個運算處理器和256個平滑石頭，就需要2個CPU多方塊結構。

右擊合成CPU會開啟合成狀態UI，可在此檢查CPU正在處理的合成任務進度。

## 設定

*   合成CPU可設定為僅接受玩家請求，僅接受自動化系統請求（如裝有<ItemLink id="crafting_card" />的<ItemLink id="export_bus" />），或兩者均接受。

## 建造

合成CPU是多方塊結構，且必須為沒有空隙的實心長方形稜柱。它們由若干元件組成。

每個CPU必須包含至少1個合成儲存器（可用的最小CPU實際上就是單個1k合成儲存器）。

# 合成單元

<BlockImage id="crafting_unit" scale="4" />

（可選）合成單元僅用於填充CPU內空隙，以保證CPU的形狀是實心長方形稜柱。沒有其他元件時可用此填補。它們也是其他元件的合成材料。

<RecipeFor id="crafting_unit" />

# 合成儲存器

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

（必需）合成儲存器支援所有標準元件大小（1k、4k、16k、64k、256k）。它們會將與合成相關的材料和中間材料存於自身，因此處理所需材料更多的合成任務需要更大的或更多個合成儲存器。

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# 並行處理單元

<BlockImage id="crafting_accelerator" scale="4" />

（可選）並行處理單元透過提升CPU運轉速度讓系統從<ItemLink id="pattern_provider" />更為頻繁地傳送材料批次，以使系統跟上處理速度較快的機器。例如，被<ItemLink id="molecular_assembler" />包圍的樣板供應器送出材料的速度快於單個裝配室的加工速度時，其會將材料批次在各裝配室間分配。

某些複雜配方可能包含多個可並行進行的步驟，比如製造書架時並行製造木板和書。在合成狀態UI（右擊CPU或右擊[終端](terminals.md)的錘子圖示）中，這些步驟都顯示為“計劃合成”。每個並行處理單元都可額外使一個上述步驟並行進行（也即顯示為“正在合成”）。不過，這點通常不那麼重要，因為加入大量並行處理單元的原因通常是為提升傳送速度，而非增加加工配方的並行數量。

<RecipeFor id="crafting_accelerator" />

# 合成監控器

<BlockImage id="crafting_monitor" scale="4" />

（可選）合成監控器會顯示CPU當前正在處理的任務。其螢幕可用<ItemLink id="color_applicator" />染色。

<RecipeFor id="crafting_monitor" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯粉
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# 福魯伊克斯粉

<ItemImage id="fluix_dust" scale="4" />

被<ItemLink id="inscriber" />粉碎的<ItemLink id="fluix_crystal" />。用於製造部分AE2機器和元件。

## 配方

<RecipeFor id="fluix_dust" />

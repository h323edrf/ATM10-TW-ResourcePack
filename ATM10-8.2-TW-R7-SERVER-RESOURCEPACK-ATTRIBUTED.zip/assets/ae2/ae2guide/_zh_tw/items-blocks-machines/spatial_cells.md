---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間元件
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# 空間儲存元件

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

空間儲存元件可用於[儲存物理空間中的某一區域](../ae2-mechanics/spatial-io.md)。可用於<ItemLink id="spatial_io_port" />。

和[儲存元件](storage_cells.md)不同，空間元件不可重新格式化。

**空間元件使用後便無法重置，無法重新格式化，無法重設尺寸。**&zwnj;如果需要更改所定義區域尺寸，應新制作元件。


## 配方

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# 外殼

元件可由空間元件和外殼合成，也可在外殼配方中央放入空間元件：

<Row>
  <Recipe id="network/cells/spatial_storage_cell_2_cubed" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

外殼自身的配方如下：

  <RecipeFor id="item_cell_housing" />

# 空間元件

空間元件是空間儲存元件的核心。每級元件容量的邊長是前一級元件的8倍。

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>
---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 能源接收器
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# 能源接收器

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

能源接收器會將其他科技模組的常見能量系統轉換為AE2內部使用的[能量](../ae2-mechanics/energy.md)⸺AE。雖然<ItemLink id="controller" />也能做到這一點，但控制器的面非常珍貴，一般還是推薦使用能源接收器。

Forge Energy與Techreborn Energy的轉換比為

*   2 FE = 1 AE（Forge）
*   1 E  = 2 AE（Fabric）

轉換速度完全由網路能量容量決定，具體原因參見[此頁](../ae2-mechanics/energy.md)。

## 變種

能源接收器有2種變種⸺普通、面板/[子部件](../ae2-mechanics/cable-subparts.md)，便於設計緊湊設施。

能源接收器的普通和麵板形態可在合成方格中轉換。

## 配方

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />
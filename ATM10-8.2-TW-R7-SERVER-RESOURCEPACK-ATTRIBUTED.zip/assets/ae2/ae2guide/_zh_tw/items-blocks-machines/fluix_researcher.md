---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯研究員（村民）
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# 福魯伊克斯研究員

<Row>
![福魯伊克斯研究員](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

福魯伊克斯研究員是一種村民職業。對應的工作站點為<ItemLink id="charger" />。

## 交易

交易跟隨原版結構，每級會解鎖隨機2項交易（除非該等級只有1種交易）。

| 等級 | 購買的物品                                         | 出售的物品                                       |
| ---- | -------------------------------------------------- | ------------------------------------------------ |
| 新手 | 3個<ItemLink id="minecraft:emerald" />             | 4個<ItemLink id="certus_quartz_crystal" />       |
| 新手 | 2個<ItemLink id="minecraft:emerald" />             | 1個<ItemLink id="meteorite_compass" />           |
|      |                                                    |                                                  |
| 學徒 | 3個<ItemLink id="charged_certus_quartz_crystal" /> | 1個<ItemLink id="minecraft:emerald" />           |
| 學徒 | 5個<ItemLink id="silicon" />                       | 1個<ItemLink id="minecraft:emerald" />           |
| 學徒 | 5個<ItemLink id="minecraft:emerald" />             | 8個<ItemLink id="sky_stone_block" />             |
|      |                                                    |                                                  |
| 老手 | 2個<ItemLink id="quartz_glass" />                  | 1個<ItemLink id="minecraft:emerald" />           |
| 老手 | 5個<ItemLink id="minecraft:emerald" />             | 4個<ItemLink id="fluix_crystal" />               |
|      |                                                    |                                                  |
| 專家 | 5個<ItemLink id="matter_ball" />                   | 1個<ItemLink id="minecraft:emerald" />           |
| 專家 | 10個<ItemLink id="minecraft:emerald" />            | 1個<ItemLink id="silicon_press" />               |
| 專家 | 10個<ItemLink id="minecraft:emerald" />            | 1個<ItemLink id="logic_processor_press" />       |
| 專家 | 10個<ItemLink id="minecraft:emerald" />            | 1個<ItemLink id="calculation_processor_press" /> |
| 專家 | 10個<ItemLink id="minecraft:emerald" />            | 1個<ItemLink id="engineering_processor_press" /> |
|      |                                                    |                                                  |
| 大師 | 8個<ItemLink id="minecraft:emerald" />             | 5個<ItemLink id="minecraft:slime_ball" />        |
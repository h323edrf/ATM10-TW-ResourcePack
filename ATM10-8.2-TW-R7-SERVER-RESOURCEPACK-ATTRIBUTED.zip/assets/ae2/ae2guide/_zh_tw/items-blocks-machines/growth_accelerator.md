---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 催生器
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# 催生器

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

與母巖相鄰放置時，催生器會大幅加快賽特斯石英和紫水晶的[生長](../ae2-mechanics/certus-growth.md)。

奇怪的是，它*也能*加速各種植物的生長。

這種加速的本質是對周圍方塊執行“隨機刻”，自然產生的隨機刻也依然保留。理論上來說，1臺催生器就能使得事物的生長速度變為原本的大約90倍，多臺催生器的效果加算。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

需向其頂面或底面供能，AE2[線纜](cables.md)和其他模組的能量線纜均可。催生器能接受AE2能量（AE）和Forge能量（FE）。

在頂面或底面放置<ItemLink id="crank" />並右擊手搖即可手工供能。

頂面和底面可透過粉紅色的福魯伊克斯珠分辨。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配方

<RecipeFor id="growth_accelerator" />

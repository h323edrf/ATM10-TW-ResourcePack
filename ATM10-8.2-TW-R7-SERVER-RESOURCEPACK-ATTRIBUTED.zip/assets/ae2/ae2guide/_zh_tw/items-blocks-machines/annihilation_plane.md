---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 破壞面板
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# 破壞面板

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

破壞面板能破壞方塊和撿起物品。它會將物品輸入[網路儲存](../ae2-mechanics/import-export-storage.md)，與<ItemLink id="import_bus" />工作方式類似。它只會撿起與面板碰撞的物品，而不是區域內所有物品。

破壞面板接受所有鎬魔咒，因此只要模組包允許，就可以為其附上等級很高的時運再放去[自動化礦石處理](../example-setups/ore-fortuner.md)。此外，精準採集和帶有此魔咒的工具表現相同，效率能減少破壞方塊的能量消耗，耐久則提升破壞時不使用能量的機率。

破壞面板是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

**記得在你認領的區塊內允許放置假玩家**

## 過濾

破壞面板只會在掉落物或物品能存入網路時破壞方塊或撿起物品。也即*需要限制其網路中可儲存物品的種類*才能過濾破壞面板，通常會將其放在[子網路](../ae2-mechanics/subnetworks.md)中。使用<ItemLink id="storage_bus" />或設定[分割槽](cell_workbench.md)的[元件](storage_cells.md)可達成這一點。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        過濾為所破壞事物的掉落物
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        分割槽為所破壞事物的掉落物
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

破壞面板過濾的是*掉落物*。因此假如要設定僅破壞<ItemLink id="minecraft:amethyst_cluster" />，則面板必須附有精準採集。未長成的紫晶芽什麼都不會掉落，而網路永遠能存下“空氣”，因此普通的破壞面板會一直破壞它們。

## 破壞面板

<RecipeFor id="annihilation_plane" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 充能器
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# 充能器

<BlockImage id="charger" scale="8" />

充能器能為其支援的工具和<ItemLink id="certus_quartz_crystal" />充能。

需向其頂面或底面供能，AE2[線纜](cables.md)和其他模組的能量線纜均可。充能器能接受AE2能量（AE）和Forge能量（FE）。其允許從各面輸入輸出物品。只有產物才會被抽出，因此不需要設定過濾。可用<ItemLink id="certus_quartz_wrench" />旋轉以實現自動化。

可將<ItemLink id="certus_quartz_crystal" />充能為<ItemLink id="charged_certus_quartz_crystal" />，或是將<ItemLink id="minecraft:compass" />變為<ItemLink id="meteorite_compass" />。

在頂面或底面放置<ItemLink id="crank" />並右擊手搖即可手工充能物品。

它也是[福魯伊克斯研究員](fluix_researcher.md)的工作站點。

## 簡單自動化

如下例，充能器的可旋轉性使其能按下述方式半自動化：

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配方

<RecipeFor id="charger" />

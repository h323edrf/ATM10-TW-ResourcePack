---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 控制器
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# 控制器

<BlockImage id="controller" p:state="online" scale="8" />

控制器是[ME網路](../ae2-mechanics/me-network-connections.md)的尋路中心。若沒有控制器，則網路是“自組織”網路，且最多隻能包含8臺佔用頻道的[裝置](../ae2-mechanics/devices.md)。

同一個[ME網路](../ae2-mechanics/me-network-connections.md)中不允許存在多組控制器。

控制器每面提供32個[頻道](../ae2-mechanics/channels.md)。

每個控制器方塊需要消耗6 AE/t才可正常工作。每個控制器方塊可儲存8,000 AE，更大的網路可能需要額外的能量儲存容量。詳細資訊參見[能量](../ae2-mechanics/energy.md)。

多方塊控制器的結構相對自由。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

不過，仍有幾條需要遵守的規則：

1.  同一個[ME網路](../ae2-mechanics/me-network-connections.md)的所有控制器方塊必須相鄰，否則所有方塊都會變紅。
2.  控制器的尺寸需小於等於7x7x7，否則會變紅。
3.  控制器中方塊最多只能在1個軸向方向上有2個相鄰方塊，若有方塊違反此規則，控制器會失效並變紅。

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

在遵守所有規則且供給能量的情況下，控制器會發光並迴圈變色。

右擊控制器可開啟和<ItemLink id="network_tool" />相同的GUI。

## 配方

<RecipeFor id="controller" />

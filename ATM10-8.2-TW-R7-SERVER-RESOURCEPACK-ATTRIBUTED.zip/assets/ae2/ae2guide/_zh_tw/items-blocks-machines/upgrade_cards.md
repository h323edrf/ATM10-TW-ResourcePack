---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 升級卡
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# 升級卡

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

升級卡能改變AE2[裝置](../ae2-mechanics/devices.md)和機器的行為，增加速度，加強過濾功能，啟用紅石控制，如此種種。

## 升級卡元件

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

升級卡需用基礎卡或高階卡合成。

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## 紅石卡

<ItemImage id="redstone_card" scale="2" />

紅石卡給予紅石控制功能，並會向裝置的GUI中加入對應多種紅石訊號狀況的切換按鈕。

<RecipeFor id="redstone_card" />

## 容量卡

<ItemImage id="capacity_card" scale="2" />

容量卡能增加輸入匯流排、輸出匯流排、儲存匯流排、成型面板的過濾槽數。

<RecipeFor id="capacity_card" />

## 溢位銷燬卡

<ItemImage id="void_card" scale="2" />

溢位銷燬卡可在<ItemLink id="cell_workbench" />中裝入[儲存元件](storage_cells.md)，其會在元件已滿時銷燬輸入物品。（一定要給元件[分割槽](cell_workbench.md)！）若同時裝有均分卡，則會在特定物品的扇區已滿時銷燬多餘的該物品，而無視其他物品的裝滿情況。

<RecipeFor id="void_card" />

## 模糊卡

<ItemImage id="fuzzy_card" scale="2" />

模糊卡允許可過濾的裝置和工具按耐久度或忽略NBT過濾，從而允許無視耐久度和魔咒輸出鐵斧，或是隻輸出耐久度不滿的鑽石劍。

以下是模糊耐久度的比較方式示例，表格左側為匯流排配置，頂部為被比較物品。

| 25%          | 耐久度剩餘10%的鎬 | 耐久度剩餘30%的鎬 | 耐久度剩餘80%的鎬 | 完好無損的鎬 |
| ------------ | ----------------- | ----------------- | ----------------- | ------------ |
| 接近破損的鎬 | ✅                 | \*\*\*\*          | \*\*\*\*          | \*\*\*\*     |
| 完好無損的鎬 | \*\*\*\*          | ✅                 | ✅                 | ✅            |

| 50%          | 耐久度剩餘10%的鎬 | 耐久度剩餘30%的鎬 | 耐久度剩餘80%的鎬 | 完好無損的鎬 |
| ------------ | ----------------- | ----------------- | ----------------- | ------------ |
| 接近破損的鎬 | ✅                 | ✅                 | \*\*\*\*          | \*\*\*\*     |
| 完好無損的鎬 | \*\*\*\*          | \*\*\*\*          | ✅                 | ✅            |

| 75%          | 耐久度剩餘10%的鎬 | 耐久度剩餘30%的鎬 | 耐久度剩餘80%的鎬 | 完好無損的鎬 |
| ------------ | ----------------- | ----------------- | ----------------- | ------------ |
| 接近破損的鎬 | ✅                 | ✅                 | \*\*\*\*          | \*\*\*\*     |
| 完好無損的鎬 | \*\*\*\*          |                   | ✅                 | ✅            |

| 99%          | 耐久度剩餘10%的鎬 | 耐久度剩餘30%的鎬 | 耐久度剩餘80%的鎬 | 完好無損的鎬 |
| ------------ | ----------------- | ----------------- | ----------------- | ------------ |
| 接近破損的鎬 | ✅                 | ✅                 | ✅                 | \*\*\*\*     |
| 完好無損的鎬 | \*\*\*\*          | \*\*\*\*          | \*\*\*\*          | ✅            |

| 忽略         | 耐久度剩餘10%的鎬 | 耐久度剩餘30%的鎬 | 耐久度剩餘80%的鎬 | 完好無損的鎬 |
| ------------ | ----------------- | ----------------- | ----------------- | ------------ |
| 接近破損的鎬 | ✅                 | ✅                 | ✅                 | **✅**        |
| 完好無損的鎬 | **✅**             | **✅**             | **✅**             | ✅            |

<RecipeFor id="fuzzy_card" />

## 加速卡

<ItemImage id="speed_card" scale="2" />

加速卡使得事物運作得更快，輸入匯流排和輸出匯流排每次操作能移動更多物品，也可讓壓印器和裝配室工作加速。

<RecipeFor id="speed_card" />

## 反相卡

<ItemImage id="inverter_card" scale="2" />

反相卡將裝置和工具的過濾從白名單變為黑名單。

<RecipeFor id="inverter_card" />

## 合成卡

<ItemImage id="crafting_card" scale="2" />

合成卡給予裝置向[自動合成](../ae2-mechanics/autocrafting.md)系統傳送相關物品合成請求的能力。

<RecipeFor id="crafting_card" />

## 均分卡

<ItemImage id="equal_distribution_card" scale="2" />

均分卡可在<ItemLink id="cell_workbench" />中裝入[儲存元件](storage_cells.md)，其會根據自身[分割槽](cell_workbench.md)將元件分為均等大小的扇區。如此即可避免某種物品將元件填滿。

<RecipeFor id="equal_distribution_card" />

## 能源卡

<ItemImage id="energy_card" scale="2" />

能源卡會為便攜終端等工具增加能量容量，也可增加<ItemLink id="vibration_chamber" />的效率。

<RecipeFor id="energy_card" />

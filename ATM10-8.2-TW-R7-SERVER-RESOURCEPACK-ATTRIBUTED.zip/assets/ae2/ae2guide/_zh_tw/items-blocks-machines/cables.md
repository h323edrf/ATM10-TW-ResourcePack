---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 線纜
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# 線纜

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

雖然相鄰的ME機器也可建立ME網路，大面積擴充套件ME網路的主要方式仍是線纜。

線纜異色可避免相鄰的線纜連線，使得[頻道](../ae2-mechanics/channels.md)的分佈更有效率。它們也會影響其上終端的顏色，就不會只出現紫色的終端了。福魯伊克斯色線纜可與所有顏色的線纜相連。

需要注意，**頻道和線纜顏色沒有關係**。

## 重要備註

**如果你新入門AE2，還不熟悉頻道的話，可以在各處儘量使用智慧線纜和緻密線纜。它們會顯示頻道在網路中的路徑，方便理解頻道的行為。**

## 另一則備註

**頻道不是物品/流體/能量/其他型別的管道。**&zwnj;頻道沒有內部儲存空間，樣板供應器和機器不會向頻道“輸入”物品，頻道唯一做的事情便是將AE2[裝置](../ae2-mechanics/devices.md)連成一個網路。

## 玻璃線纜

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" />是最簡單的線纜，能傳輸能量，最多可傳輸8個[頻道](../ae2-mechanics/channels.md)。它共有17種顏色，預設為福魯伊克斯色，且可用16種染料染成相應顏色。

在合成方格內用8個線纜包圍染料以合成染色線纜（合成用線纜的顏色不要求一致，但必須是同種線纜，如玻璃，智慧等）。也可用任意Forge相容的顏料刷給世界中的線纜染色。

可將任意染色線纜與水桶合成以洗去染料。

可用羊毛包裹線纜製得<ItemLink id="fluix_covered_cable" />，也可合成<ItemLink id="fluix_smart_cable" />以更好觀察[頻道](../ae2-mechanics/channels.md)的行為。

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## 包層線纜

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

相對<ItemLink id="fluix_glass_cable" />，包層線纜並未提供任何額外遊戲功能。不過如果喜歡包層線纜的外觀的話，也可以用作實用裝飾。

包層線纜可像<ItemLink id="fluix_glass_cable" />一樣染色。四個<ItemLink id="fluix_covered_cable" />再加紅石和熒石就可合成<ItemLink id="fluix_covered_dense_cable" />。

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## 緻密線纜

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

高容量線纜，能傳輸32個頻道，而非普通線纜的8個。但是緻密線纜不支援匯流排，必須先將緻密線纜降為小型線纜（例如<ItemLink id="fluix_glass_cable" />和<ItemLink id="fluix_smart_cable" />），才能放上匯流排和麵板。

緻密線纜會對頻道的“最短路徑”特性稍加修改：頻道會先沿最短路徑抵達致密線纜，再沿經過該緻密線纜的最短路徑抵達控制器。

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## 智慧線纜

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

雖然外形與<ItemLink id="fluix_covered_cable" />較為相似，但智慧線纜能在其上顯示頻道的使用情況，具有診斷功能。頻道會顯示為線纜黑色條紋上的帶色細線，便於理解網路內頻道的使用狀況。普通智慧線纜上前四個頻道與線纜同色，後四個為白色。緻密線纜的每條細線則代表4個頻道。

在帶有<ItemLink id="controller" />的網路中，線纜上的細線和頻道的實際線路完全一致。

處於自組織網路的智慧線纜則會顯示全網路所佔用的頻道數，而非經過自身的頻道數。

智慧線纜可像<ItemLink id="fluix_glass_cable" />一樣染色。

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />

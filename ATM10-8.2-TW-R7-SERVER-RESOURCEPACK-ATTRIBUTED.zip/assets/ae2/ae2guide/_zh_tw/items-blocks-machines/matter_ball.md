---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物質球
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# 物質球

<ItemImage id="matter_ball" scale="4" />

一團物質組成的球，可作為<ItemLink id="matter_cannon" />的彈藥或用於生產[染色球](paintballs.md)。

由物質球模式的<ItemLink id="condenser" />聚合256個物品或256桶流體而得。

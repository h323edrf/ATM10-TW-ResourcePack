---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 監控器
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# 監控器

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

監控器可在不開啟GUI的情況下展示單種物品或流體，並允許與其互動。

監控器會繼承支援其的[線纜](cables.md)的顏色。

如果監控器位於頂面或底面，則可用<ItemLink id="certus_quartz_wrench" />選擇。

它們是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

# 儲存監控器

能顯示單種物品或流體，以及其數量。在農場之類的設施旁放幾個比較好⋯⋯

*不需要*佔用[頻道](../ae2-mechanics/channels.md)。

按鍵繫結：

*   手持物品右擊或手持流體容器右鍵雙擊以將監控器設定為該物品/流體
*   空手右擊以清空設定
*   空手Shift右擊以鎖定監控器

## 配方

<RecipeFor id="storage_monitor" />

# 交換監控器

交換監控器和儲存監控器類似，同時允許取出或存入所展示的物品。

如果所設定的物品可[自動合成](../ae2-mechanics/autocrafting.md)且庫存內無該物品，取出物品時監控器會開啟設定合成數量的UI。

*需要*佔用[頻道](../ae2-mechanics/channels.md)。

新增按鍵繫結：

*   左擊以取出一組物品，沒有對應物品時會傳送合成請求
*   手持任意物品右擊以存入該物品
*   空手右擊以存入物品欄內所有所設定的物品

## 配方

<RecipeFor id="conversion_monitor" />

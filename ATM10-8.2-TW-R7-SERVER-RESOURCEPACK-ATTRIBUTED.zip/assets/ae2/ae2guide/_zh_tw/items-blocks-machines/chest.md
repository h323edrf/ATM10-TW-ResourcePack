---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME箱子
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# ME箱子

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

ME箱子類似於帶有<ItemLink id="terminal" />、<ItemLink id="drive" />、<ItemLink id="energy_acceptor" />的微縮網路。可將其用作小型網路儲存，但其僅能裝下單個[儲存元件](storage_cells.md)的容量則限制了其功能性。

它在與其中元件單獨互動方面非常有用。整合其中的終端只能訪問箱子內的元件，而普通網路中的[裝置](../ae2-mechanics/devices.md)則能訪問任何[網路儲存](../ae2-mechanics/import-export-storage.md)位置，包括ME箱子。

其有2個GUI，且對面敏感。與頂面的終端互動會開啟終端介面，物流系統僅可向其輸入，而不能從中抽取物品。與其他面互動則會開啟放置儲存元件和優先順序設定的GUI。物品物流系統僅可透過帶有元件槽的面輸出輸出元件。

可被<ItemLink id="certus_quartz_wrench" />旋轉。

其只有一小型AE能量快取，因此若不配備[能源元件](energy_cells.md)，對其同時輸入輸出過多物品可能會導致能量耗盡。

終端可用<ItemLink id="color_applicator" />染色。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 設定

ME箱子的設定與<ItemLink id="terminal" />和<ItemLink id="crafting_terminal" />的相同，但不支援<ItemLink id="view_cell" />。

## 元件狀態LED

箱子中的元件可透過其LED表明其狀態：

| 顏色 | 狀態                                                          |
| :--- | :------------------------------------------------------------ |
| 綠色 | 空                                                            |
| 藍色 | 裝有事物                                                      |
| 橙色 | [型別](../ae2-mechanics/bytes-and-types.md)已滿，不可新增型別 |
| 紅色 | [位元組](../ae2-mechanics/bytes-and-types.md)已滿，不可新增物品 |
| 黑色 | 無能量或箱子缺少[頻道](../ae2-mechanics/channels.md)          |

## 優先順序

可點選GUI右上角扳手以設定優先順序。輸入網路的物品會優先進入最高優先順序的儲存位置，如果有兩個優先順序相同的儲存位置，則會優先選擇已經存有該物品的那個。經過[分割槽](cell_workbench.md)的元件在同優先順序情況下視作已經存有該物品。從儲存中輸出的物品會優先從最低優先順序的位置輸出。這一優先順序系統使得在輸入輸出物品的過程中，高優先順序的儲存位置會被填滿，而低優先順序的會被搬空。

## 配方

<RecipeFor id="chest" />

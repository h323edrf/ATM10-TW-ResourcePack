---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME輸入匯流排
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# 輸入匯流排

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

輸入匯流排會從其所連線的容器中抽出物品和流體（以及附屬新增的其他型別），並存入[網路儲存](../ae2-mechanics/import-export-storage.md)。

為減少卡頓，輸入匯流排會在近期未輸入的情況下進入某種“睡眠模式”，此時其工作速度較慢，並會在其輸入物品時被喚醒並逐漸進入正常狀態（每秒傳輸4次）。

輸入匯流排是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

## 過濾

預設情況下，輸入匯流排會輸入所有其能訪問的事物。放入其過濾槽的物品會加入白名單，也即只會輸入其中指明的事物。

如果沒有所需物品或流體，可從JEI/REI中拖拽以放入過濾槽。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

## 升級

輸入匯流排支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="capacity_card" />增加過濾槽位數
*   <ItemLink id="speed_card" />增加每次傳輸時移動的物品數
*   <ItemLink id="fuzzy_card" />使得匯流排能按耐久度或忽略物品NBT過濾
*   <ItemLink id="inverter_card" />將白名單變為黑名單
*   <ItemLink id="redstone_card" />加入紅石控制功能，使其會在高訊號、低訊號、遇脈衝時啟動

## 速度

| 加速卡數 | 每次傳輸移動的物品數 |
|:---------|:---------------------|
| 0        | 1                    |
| 1        | 8                    |
| 2        | 32                   |
| 3        | 64                   |
| 4        | 96                   |

## 配方

<RecipeFor id="import_bus" />

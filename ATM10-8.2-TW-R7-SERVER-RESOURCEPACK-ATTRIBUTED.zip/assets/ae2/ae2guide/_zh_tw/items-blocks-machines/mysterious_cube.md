---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 神秘方塊
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# 神秘方塊

<BlockImage id="mysterious_cube" scale="8" />

還記得要找好幾顆隕石才能集齊壓印模板的歲月嗎？這段歲月已然不再！現在隕石都會自帶一個神秘方塊。

不知道破壞（不帶精準採集）的時候會發生什麼事⋯⋯

也可以製造一個複製翻版⸺沒那麼神秘的方塊。

## 配方

<RecipeFor id="not_so_mysterious_cube" />

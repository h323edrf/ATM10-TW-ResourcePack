---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯升級鍛造模板
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# 福魯伊克斯升級鍛造模板

和原版的鍛造模板不同，這個鍛造模板可以直接製造。

是製造[福魯伊克斯工具](fluix_tools.md)的必需品。

## 配方

<RecipeFor id="fluix_upgrade_smithing_template" />
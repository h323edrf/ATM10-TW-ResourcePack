---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 成型與破壞核心
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# 成型與破壞核心

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

這些是AE2輸入輸出[裝置](../ae2-mechanics/devices.md)的基礎元件。其中的<ItemLink id="fluix_crystal" />和[邏輯處理器](processors.md)使其能賦予裝置輸入輸出物品、方塊、流體等的能力。（沒有實際功能，只是中間合成材料。）

## 配方

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />

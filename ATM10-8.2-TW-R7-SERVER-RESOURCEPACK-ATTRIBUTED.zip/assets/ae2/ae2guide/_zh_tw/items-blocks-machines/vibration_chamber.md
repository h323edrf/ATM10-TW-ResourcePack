---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 諧振倉
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# 諧振倉

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

給網路供給[能量](../ae2-mechanics/energy.md)的基礎方法是<ItemLink id="energy_acceptor" />，諧振倉則能直接生成少量到中量的AE。

預設狀況下（無[升級](upgrade_cards.md)且處於預設配置），它會產出40 AE/t。

網路的[能量](../ae2-mechanics/energy.md)存滿時，諧振倉會減緩工作速度以減少燃料消耗，但它不會完全停止工作。

## 設定

*   諧振倉提供調整全域性能量單位（AE、E/FE）的設定

## 升級

諧振倉支援如下[升級](upgrade_cards.md)：

*   每張<ItemLink id="energy_card" />會將諧振倉的效率+50%，最大+150%，也即基礎效率的250%
*   每張<ItemLink id="speed_card" />會將諧振倉的燃燒速率+50%，最大+150%，也即基礎能量輸出的250%

## 配置

諧振倉各屬性可在.minecraft/config/ae2/common.json中修改。

*   baseEnergyPerFuelTick設定諧振倉未經升級的基礎效率。
*   minEnergyPerGameTick設定產能水平下限（即便網路不需要能量，諧振倉也會緩慢消耗燃料）。
*   maxEnergyPerGameTick設定諧振倉未經升級的輸出上限（和速度）。

## 配方

<RecipeFor id="vibration_chamber" />

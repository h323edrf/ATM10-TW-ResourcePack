---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物質炮
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# 物質炮

<ItemImage id="matter_cannon" scale="4" />

物質炮是能將小型物品彈射出去的行動式軌道炮，彈藥包括<ItemLink id="matter_ball" />和金屬粒。傷害由發射的物品決定，金粒（10點傷害）之類較“重”的物品造成的傷害比物質球（2點傷害）之類較輕的物品更多。每次發射基礎消耗1600AE。

配置“matterCannonBlockDamage”為true時，物質炮會根據方塊硬度和彈藥傷害破壞方塊。

可在<ItemLink id="charger" />中為其充能。

物質炮和[儲存元件](storage_cells.md)表現類似，可將其放入<ItemLink id="chest" />的元件槽以補充彈匣。

## 升級

物質炮支援如下[升級](upgrade_cards.md)，需用<ItemLink id="cell_workbench" />裝入：

*   <ItemLink id="fuzzy_card" />使得物質炮可按耐久度或忽略NBT分割槽
*   <ItemLink id="inverter_card" />將白名單變為黑名單
*   <ItemLink id="speed_card" />增加每次發射的能量消耗，射出的子彈能量更大
*   <ItemLink id="void_card" />會在物質炮已滿時銷燬輸入的物品，設定分割槽的時候要小心！
*   <ItemLink id="energy_card" />可增加其能量容量

## 配方

<RecipeFor id="matter_cannon" />

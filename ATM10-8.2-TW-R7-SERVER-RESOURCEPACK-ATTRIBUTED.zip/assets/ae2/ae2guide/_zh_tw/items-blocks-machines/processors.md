---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 處理器
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# 處理器

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

處理器是AE2[裝置](../ae2-mechanics/devices.md)和機器的基礎合成材料之一。它們也是你遇到的第一個大型自動化挑戰。共有三種處理器，分別由金、<ItemLink id="certus_quartz_crystal" />、鑽石製成。可在<ItemLink id="inscriber" />中以[壓印模板](presses.md)透過多步合成過程製造（通常由一系列壓印器和帶有過濾的管道實現）。

## 生產步驟

<Column gap="5">

  1.  收集/製造所需材料：矽、紅石、金、<ItemLink id="certus_quartz_crystal" />、鑽石。

  <RecipeFor id="silicon" />

  <br />

  2.  壓印出中間產物電路板

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

  3.  最終組裝步驟

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>

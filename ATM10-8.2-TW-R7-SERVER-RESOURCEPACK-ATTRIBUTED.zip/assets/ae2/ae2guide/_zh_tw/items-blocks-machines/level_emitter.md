---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 標準發信器
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# 標準發信器

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

標準發信器會根據[網路儲存](../ae2-mechanics/import-export-storage.md)中物品數量發出紅石訊號。

它有一根據網路中[能量](../ae2-mechanics/energy.md)水平發出紅石訊號的變種。

如果沒有所需物品或流體，可從JEI/REI中拖拽以放入過濾槽。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

它們是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

和其他[裝置](../ae2-mechanics/devices.md)不同，標準發信器*不*需要[頻道](../ae2-mechanics/channels.md)。

## 設定

*   標準發信器有“大於等於”和“小於”兩種模式。
*   裝有<ItemLink id="crafting_card" />時，有“當物品合成時發出紅石訊號”和“發出紅石訊號以合成物品”兩種模式。

## 升級

標準發信器支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="fuzzy_card" />使得發信器能按耐久度或忽略物品NBT過濾
*   <ItemLink id="crafting_card" />能啟用合成功能

## 合成功能

如果裝有<ItemLink id="crafting_card" />，則發信器會進入合成狀態。

此時其有兩種模式：

第一種是“當物品合成時發出紅石訊號”，此時發信器會在[自動合成](../ae2-mechanics/autocrafting.md)系統以<ItemLink id="pattern_provider" />合成特定物品時發出紅石訊號。如此就可在某些耗能量大的自動化設施真正需要使用時才啟動它們。

第二種是“發出紅石訊號以合成物品”，此模式在處理無限農場和機率產出產物的自動化設施上極其有用。發信器會同時建立一個所過濾物品的虛[樣板](patterns.md)，可供[自動合成](../ae2-mechanics/autocrafting.md)系統使用。（為正常運轉，<ItemLink id="pattern_provider" />中**不應存在**同一物品的相同配方。）

這種“樣板”不會定義也不會關心合成材料。換言之，“如果在此標準發信器發出紅石訊號，則ME系統會在未來某時間點收到這些物品”。其通常用於啟用或禁用不需要輸入材料的無限農場，或是啟用處理[遞迴配方](../example-setups/recursive-crafting-setup.md)（標準自動合成無法處理）的系統，例如“1x 圓石 = 2x 圓石”，如果有一臺能複製圓石的機器的話。

## 配方

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />

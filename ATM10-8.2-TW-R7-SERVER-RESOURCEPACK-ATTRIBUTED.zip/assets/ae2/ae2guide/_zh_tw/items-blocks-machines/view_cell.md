---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 顯示元件
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# 顯示元件

<ItemImage id="view_cell" scale="2" />

顯示元件可過濾[終端](terminals.md)的顯示，需在<ItemLink id="cell_workbench" />中為其分割槽。

例如，也許你會想讓某個終端只顯示一部分石制建材。將顯示元件分割槽為這些材料並裝入終端，終端就只會顯示這些物品了。

顯示元件的效果會疊加，比如裝入分割槽為橡木木板和分割槽為圓石的顯示元件，相應裝置兩者都會顯示。

## 配方

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 染色器
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# 染色器

<ItemImage id="color_applicator" scale="4" />

染色器可為[線纜](cables.md)、羊毛、陶瓦、玻璃、混凝土等可染色方塊染色。它需要消耗[染色球](paintballs.md)或染料，如果需要洗去線纜顏色或方塊上的染料灘的話，可在其中裝入雪球。

可在<ItemLink id="charger" />中為其充能。

染色器和[儲存元件](storage_cells.md)表現類似，可將其放入<ItemLink id="chest" />的元件槽以補充染料。

手持染色器對染色目標右擊以染色。Shift滾動滾輪以更改當前染色球和染料，不對準任何目標右擊也可更改。

## 升級

染色器支援如下[升級](upgrade_cards.md)，需用<ItemLink id="cell_workbench" />裝入：

*   <ItemLink id="equal_distribution_card" />會為每個型別分配同等大小的扇區，也即單個型別無法填滿染色器
*   <ItemLink id="void_card" />會在元件已滿（或在裝有均分卡時某型別已滿）時銷燬輸入的物品，設定分割槽的時候要小心！
*   <ItemLink id="energy_card" />可增加其能量容量

## 配方

<RecipeFor id="color_applicator" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 賽特斯石英母巖
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# 賽特斯石英母巖

（見[賽特斯石英的生長](../ae2-mechanics/certus-growth.md)）

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

賽特斯石英芽會從賽特斯石英母巖中生長出來，與紫水晶類似。母巖可在[隕石](../ae2-mechanics/meteorites.md)中找到。共有4種等級的賽特斯石英母巖：無瑕、有瑕、開裂、損壞。可由HWYLA、Jade、The One Probe等模組輕鬆辨別。（F3介面也可。）

對於有瑕、開裂、損壞的母巖而言，每次石英芽生長時，母巖都有可能降一級，並最終變為普通的<ItemLink id="quartz_block" />。

無瑕的賽特斯石英母巖不會因石英芽的生長而降級，可用作無限生產源。

若用普通鎬破壞，賽特斯石英母巖會降一級。若用精準採集鎬破壞，則除無瑕母巖外不會降級。**這也意味著無瑕的賽特斯石英母巖無法用鎬完好破壞或搬運**。不過可以用[空間儲存](../ae2-mechanics/spatial-io.md)以剪下貼上無瑕母巖。

## 配方

有瑕、開裂、損壞的賽特斯石英母巖可透過將上一級母巖（或<ItemLink id="quartz_block" />）和若干個<ItemLink id="charged_certus_quartz_crystal" />投入水中合成。

無瑕的賽特斯石英母巖無法合成，只能在世界中搜尋而得。

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>

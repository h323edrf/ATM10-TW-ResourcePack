---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 物質聚合器
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# 物質聚合器

<BlockImage id="condenser" scale="8" />

物質聚合器可用作垃圾箱，或是用於製造<ItemLink id="matter_ball" />和[奇點](singularities.md)。它能接受物品，流體等可儲存於儲存元件的事物。

## 設定/可用配方

*   在銷燬模式下，物質聚合器會銷燬所有輸入物品。
*   在物質球模式下，物質聚合器會用輸入物品製造<ItemLink id="matter_ball" />。此模式需要在聚合器頂部槽位裝有儲存元件。製造物質球需消耗256個物品或256桶流體，<ItemLink id="cell_component_1k" />（8192位容量）就已足夠。
*   在奇點模式下，物質聚合器會用輸入物品製造[奇點](singularities.md)。此模式需要在聚合器頂部槽位裝有儲存元件。製造奇點需消耗256,000個物品或256,000桶流體，<ItemLink id="cell_component_64k" />（524,288位容量）就已足夠。

注意，在後兩種模式下，物質聚合器*有可能*被產物堵塞；若能量和輸出物品快取均已滿，它便不會再接受輸入。

## 配方

<RecipeFor id="condenser" />

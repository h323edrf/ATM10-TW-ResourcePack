---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 壓印器
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# 壓印器

<BlockImage id="inscriber" scale="8" />

壓印器可透過[壓印模板](presses.md)壓印電路板和[處理器](processors.md)，也可將若干物品打成粉末。它能接受AE2能量（AE）和Fabric/Forge能量（E/FE）。其可設定為面敏感，如此從不同面輸入的物品會進入不同槽位。可用<ItemLink id="certus_quartz_wrench" />旋轉以利用此特性。也可將其設定為將產物彈出至相鄰容器。

輸入快取的大小可以調整。假如需要用單個容器為許多壓印器提供材料，則可使用小快取，以提高材料的分配效率（而非第一臺填滿至64個但其餘的仍為空）。

4種電路板壓印模板可用於製作[處理器](processors.md)。

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

而名稱壓印模板則可像鐵砧一樣命名物品，便於在<ItemLink id="pattern_access_terminal" />中標記事物。

<ItemImage id="name_press" scale="4" />

## 設定

* 壓印器可設定為面敏感（解釋見下），或是允許從所有面輸入，並交由內部過濾決定目標槽位。在非面敏感模式下，無法從其頂部和底部槽位抽取物品。
* 壓印器可設定為向相鄰容器彈出物品。
* 壓印器的輸入快取可調，大快取適用於手動供材的獨立壓印器，而小快取適合大量並行的壓印器。


## GUI與面敏感性

處於面敏感模式時，壓印器會根據物品輸入輸出的面決定其目標槽位。

![壓印器GUI](../assets/diagrams/inscriber_gui.png) ![壓印器各面](../assets/diagrams/inscriber_sides.png)

A. **頂部輸入**需從頂面訪問（允許輸入輸出）

B. **中央輸入**需從左面、右面、正面、背面訪問（允許輸入，不允許輸出）

C. **底部輸入**需從底面訪問（允許輸入輸出）

D. **輸出**可從左面、右面、正面、背面抽出（允許輸出，不允許輸入）

## 簡單自動化

如下例，壓印器的面敏感性和可旋轉性使其能按下述方式半自動化：

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

也可以在非面敏感狀態直接輸入輸出物品。

## 升級

壓印器支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="speed_card" />

## 配方

<RecipeFor id="inscriber" />

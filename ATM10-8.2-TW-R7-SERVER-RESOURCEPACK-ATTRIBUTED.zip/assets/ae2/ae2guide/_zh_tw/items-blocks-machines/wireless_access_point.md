---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線訪問點
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# 無線訪問點

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

允許從<ItemLink id="wireless_terminal" />無線訪問網路。其工作範圍與能量消耗由其中安裝的<ItemLink id="wireless_booster" />的數量決定。

單個網路可有任意個無線訪問點，每個其中可裝有任意個<ItemLink id="wireless_booster" />，可透過更改這些來最佳化工作範圍和能量消耗。

需佔用1個[頻道](../ae2-mechanics/channels.md)。

也用於繫結[無線終端](wireless_terminals.md)。

# 無線訊號增幅器

<ItemImage id="wireless_booster" scale="2" />

用於增加無線訪問點的工作範圍。

## 配方

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 曲柄
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# 曲柄

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

在沒有產能途徑時，曲柄可為需要能量的機器（或<ItemLink id="energy_acceptor" />）供能。遊戲早期的陣痛，是吧？

## 配方

<RecipeFor id="crank" />

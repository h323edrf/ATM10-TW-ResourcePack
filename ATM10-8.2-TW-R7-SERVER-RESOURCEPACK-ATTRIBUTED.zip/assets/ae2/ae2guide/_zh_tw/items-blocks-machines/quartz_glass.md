---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英玻璃
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# 石英玻璃

<BlockImage id="quartz_glass" scale="8" />

幾乎完全通透的玻璃，由<ItemLink id="certus_quartz_dust" />製成。用於製造大多數AE2機器和物品。

其變種聚能石英玻璃會發光。

## 配方

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 元件工作臺
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# 元件工作臺

<BlockImage id="cell_workbench" scale="8" />

元件工作臺可用於配置[儲存元件](storage_cells.md)和<ItemLink id="view_cell" />。

可向元件裝入[升級卡](upgrade_cards.md)，或配置“分割槽”以限定元件可儲存的物品種類。

如果沒有所需物品或流體，可從JEI/REI中拖拽以放入過濾槽。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

## 設定

元件工作臺左上角有若干按鈕：

*   可根據元件已存有的物品為其分割槽
*   可清空元件的分割槽設定
*   元件工作臺可設定為保留分割槽設定，便於將其複製到其他元件中

## 配方

<RecipeFor id="cell_workbench" />

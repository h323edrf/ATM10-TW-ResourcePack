---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 線纜錨
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# 線纜錨

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

附著於線纜的裝飾性小型刺狀物，能阻止線纜連線，也能將線纜變為梯子，還可以讓線纜看上去和周圍的牆相連。也用於合成<ItemLink id="facade" />。

線纜錨阻止其附著位置形成連線。

可以像梯子一樣沿其攀爬。

## 配方

<RecipeFor id="cable_anchor" />

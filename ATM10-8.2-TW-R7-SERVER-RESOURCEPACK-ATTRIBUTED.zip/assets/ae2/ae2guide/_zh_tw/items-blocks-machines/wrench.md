---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 扳手
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# 扳手

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

扳手可用於旋轉AE2裝置（右擊）和拆卸AE2方塊（Shift右擊）。也可將單個[子部件](../ae2-mechanics/cable-subparts.md)拆下而不影響同線纜上其他事物。（也可拆下線纜而不影響子部件。）

許多AE2方塊都可旋轉，指南未提及並不意味不能旋轉。

## 配方

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間IO埠
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# 空間IO埠

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

空間IO埠用於[空間IO](../ae2-mechanics/spatial-io.md)，可容納[空間元件](spatial_cells.md)並控制空間IO操作。

其中元件槽可被任意物品物流裝置（如漏斗和AE2匯流排）抽出或存入，便於自動化。

## 配方

<RecipeFor id="spatial_io_port" />
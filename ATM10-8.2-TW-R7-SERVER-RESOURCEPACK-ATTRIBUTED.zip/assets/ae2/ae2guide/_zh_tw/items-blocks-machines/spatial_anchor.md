---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間錨
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# 空間錨

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

AE2網路需要所有[裝置](../ae2-mechanics/devices.md)均被區塊載入才可工作，只有一部分被載入可能導致執行失常。空間錨則解決了這個問題。它會強制載入其所處網路佔用的區塊。僅是跨過區塊邊界的單個線纜就足以載入該新區塊了。

其“載入範圍”會穿過[量子橋](quantum_bridge.md)，但不會跨維度載入，因此如果有連線至下界的量子橋，則需要在基地和下界都有一個空間錨。

預設情況下，它也會啟用載入區塊的隨機刻，這一特性可被AE2配置關閉。

空間錨可用<ItemLink id="certus_quartz_wrench" />旋轉，如果真有需要的話。

## 設定

*   空間錨提供調整全域性能量單位（AE、E/FE）的設定。
*   可在世界內顯示被載入區塊的全息圖。

## 能量

空間錨的[能量](../ae2-mechanics/energy.md)消耗遵從如下等式：

e = 80 + (x\*(x+1))/2

x為被載入區塊的數量

## 配方

<RecipeFor id="spatial_anchor" />

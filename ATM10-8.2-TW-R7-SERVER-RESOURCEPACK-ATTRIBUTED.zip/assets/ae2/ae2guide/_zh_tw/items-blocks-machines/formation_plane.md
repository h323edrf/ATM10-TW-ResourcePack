---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 成型面板
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# 成型面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

成型面板能放置方塊和投出物品。它會在[裝置](../ae2-mechanics/devices.md)（如<ItemLink id="import_bus" />和<ItemLink id="interface" />）將物品存入[網路儲存](../ae2-mechanics/import-export-storage.md)時放置或投出它們，與僅存入的<ItemLink id="storage_bus" />工作方式類似。

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

注意，這些裝置在[管道子網路](../example-setups/pipe-subnet.md)中類似“輸入匯流排 -> 儲存匯流排”和“介面 -> 儲存匯流排”。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

在[管道子網路](../example-setups/pipe-subnet.md)等設施中，此[裝置](../ae2-mechanics/devices.md)的行為方式類似儲存匯流排；如果需要放置方塊或投出物品而非傳輸的話，也能替代儲存匯流排。

成型面板是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

**記得在你認領的區塊內允許放置假玩家**

## 過濾

預設情況下，成型面板不會放置或投出任何東西。放入其過濾槽的物品會加入白名單，也即只會放置其中指明的事物。

如果沒有所需物品或流體，可從JEI/REI中拖拽以放入過濾槽。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

## 優先順序

單擊GUI右上角扳手圖示以設定優先順序。進入網路的物品會優先送至優先順序最高的儲存位置。

## 設定

*   成型面板可設定為放置方塊或投出物品。

## 升級

成型面板支援如下[升級](upgrade_cards.md)：

*   <ItemLink id="capacity_card" />增加過濾槽位數
*   <ItemLink id="fuzzy_card" />使得面板能按耐久度或忽略物品NBT過濾
*   <ItemLink id="inverter_card" />將白名單變為黑名單

## 配方

<RecipeFor id="formation_plane" />

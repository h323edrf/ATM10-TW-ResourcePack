---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME IO埠
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# ME IO埠

<BlockImage id="io_port" p:powered="true" scale="8" />

IO埠會藉助[網路儲存](../ae2-mechanics/import-export-storage.md)迅速填滿或清空[儲存元件](storage_cells.md)。

可被<ItemLink id="certus_quartz_wrench" />旋轉。

## 設定

*   IO埠可設定為在元件為空、元件裝滿、工序完成時將元件移至輸出槽。
*   若裝有<ItemLink id="redstone_card" />，則會出現紅石訊號相關的選項。
*   在GUI中央有一指示傳輸方向的箭頭，方向可為從元件至[網路儲存](../ae2-mechanics/import-export-storage.md)和從網路儲存至元件。

## 升級

IO埠支援如下[升級](upgrade_cards.md)：

*   <ItemLink id="speed_card" />增加每次傳輸時移動的物品數
*   <ItemLink id="redstone_card" />加入紅石控制功能，使其會在高訊號、低訊號、遇脈衝時啟動

## 配方

<RecipeFor id="io_port" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 樣板供應器
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# 樣板供應器

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

樣板供應器是自動合成系統與世界互動的基礎方式。它們會將[樣板](patterns.md)指明的材料輸出至相鄰容器，並且也可向其輸入物品以輸入網路。通常可將機器的產物傳輸給附近的樣板供應器（一般就是輸出材料的那個）以節省頻道，而非讓<ItemLink id="import_bus" />提取產物。

需要注意，它們會直接從合成CPU中的[合成儲存器](crafting_cpu_multiblock.md#合成儲存器)中輸出物品；因此，模板供應器本身並不儲存物品，也就不能直接從此抽取物品：需要將物品輸出至另一個容器（比如木桶），再從那裡抽取才行。

此外，供應器會同時輸出整份材料，不會輸出半份。這一特性非常有用。

樣板供應器和介面有一特殊互動效果⸺[子網路](../ae2-mechanics/subnetworks.md)：如果介面未經修改（請求槽內無內容），則供應器會跳過介面，直接輸出到該子網路的[儲存模組](../ae2-mechanics/import-export-storage.md)，而非輸出到介面的儲存槽；更重要的是，只要對應的機器沒有足夠的空間，下一批物品就不會輸出。阻擋模式下此功能才可正常運作，供應器會監測機器中的材料槽，而非介面中的槽位。

例如，下方設施會將需燒煉的事物和燃料直接送入熔爐對應的槽位中。可利用此特性向機器的多個面或多個機器供應樣板。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        （1）樣板供應器：以賽特斯石英扳手改為方向型，裝有相應樣板。

        ![鐵樣板](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        （2）介面：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        （3）儲存匯流排#1：過濾煤炭。
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        （4）儲存匯流排#2：透過反相卡設定為排除煤炭。
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

如下是為多臺機器提供材料的通用設施示例

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        介面（必須為面板型，不能為方塊型）
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        儲存匯流排
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        樣板供應目的地
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

允許存在多個擁有相同樣板的樣板供應器，它們會並行工作。

樣板供應器會嘗試在其所有面輪詢材料批次，從而並行使用所有相鄰的機器。

## 變種

樣板供應器有3種變種：普通、方向、面板。形態會影響各面輸出材料，接收物品，提供網路連線的能力。

* 普通型樣板供應器會向各面輸出材料，會從各面接收物品，且和大多數AE2機器一樣向各面提供[網路連線](../ae2-mechanics/me-network-connections.md)，類似線纜。

* 方向型樣板供應器可透過對普通樣板供應器使用<ItemLink id="certus_quartz_wrench" />產生。它們只會向選中面輸出材料，會從各面接收物品，並且僅不向選中面提供[網路連線](../ae2-mechanics/me-network-connections.md)。這使得它們能向AE2機器輸出物品而不連線網路，在構建子網路上非常有用。

* 面板型樣板供應器是[線纜子部件](../ae2-mechanics/cable-subparts.md)，因此可在同一線纜上放置多個該種供應器，便於設計緊湊設施。它們和方向型供應器選中面功能類似：輸出樣板材料，接收物品，且**不**提供[網路連線](../ae2-mechanics/me-network-connections.md)。

樣板供應器的普通和麵板形態可在合成方格中轉換。

## 設定

樣板供應器有多種模式：

*   **阻擋模式**能在機器中已有材料時阻止供應器輸出新批次
*   **鎖定合成**能在多種紅石訊號狀況下鎖定供應器，也可在前一批材料的合成產物未返回該供應器前將其鎖定
*   供應器可在<ItemLink id="pattern_access_terminal" />上顯示或隱藏

## 優先順序

可點選GUI右上角扳手以設定優先順序。有多個[樣板](patterns.md)對應同一物品時，在高優先順序供應器中的樣板會先於低優先順序供應器中樣板使用，除非網路無法向高優先順序樣板供給所需材料。

## 常見誤解

人們似乎總是會這麼想⸺我不理解為什麼，不過希望這一節能幫上忙。（也許人們只是理解錯了，認為只有<ItemLink id="export_bus" />才能將物品輸出網路，而沒意識到樣板供應器也能輸出。）

如下設定不會如期望運作。正如[線纜](cables.md)中所提，線纜不是物品管道，它們沒有內部儲存空間，供應器無法向線纜輸出。

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        不是高爐
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

因為供應器沒有輸出的目的地，所以它不會運作。此處供應器僅作為將<ItemLink id="export_bus" />連線至網路的線纜存在。

供應器同樣不會告訴<ItemLink id="export_bus" />要輸出什麼⸺輸出匯流排只會輸出其過濾槽中的事物。

我們實際搭建的設施如下：

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        不是高爐
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

你可能想搭建的是這個，此處的樣板供應器能將樣板所需的材料輸出至相鄰機器：

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        不是高爐
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## 與分子裝配室配合使用

<ItemLink id="molecular_assembler" />和其他機器本質上完全一致。它們都有接受物品的內部槽位，都可以對這些槽位中物品進行操作，也都可以向相鄰的容器彈出產物。因此，分子裝配室和供應器的配合也應與其他機器一致，不過裝配室還有一條特性：

分子裝配室可以從其中的<ItemLink id="crafting_pattern" />、<ItemLink id="smithing_table_pattern" />和<ItemLink id="stonecutting_pattern" />直接獲取配方。這在裝配線設計中非常有用，但為每一種合成配方都設定專用的裝配室就太麻煩了。

因此，樣板供應器具有配合分子裝配室的特殊功能，它們會在輸出原材料的同時送出樣板的資料。只需在供應器旁放置裝配室，就可直接處理各種型別的合成樣板、鍛造臺樣板、切石機樣板了。

真就是這麼簡單，往供應器裡塞樣板就行了：

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*需要注意此設施包含8個供應器，也是單個裝配室、供應器、非緻密線纜可傳遞的頻道數上限。*

## 配方

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />

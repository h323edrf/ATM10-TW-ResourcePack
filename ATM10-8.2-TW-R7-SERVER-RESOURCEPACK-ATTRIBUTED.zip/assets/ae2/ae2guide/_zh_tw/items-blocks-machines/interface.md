---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 介面
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# 介面

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

介面可視作小型箱子和流體儲罐，能根據自身設定對[網路儲存](../ae2-mechanics/import-export-storage.md)輸入輸出。其會嘗試在單個遊戲刻內完成輸入輸出，也即1遊戲刻最多可傳輸9組物品。這也讓其成為一種快速的輸入輸出手段，適用於快速運送物品。

介面還有一個實用特性，大多數流體儲罐只能儲存1種流體，而介面能儲存最多9種，物品也是一樣。它們實際上就是帶有若干額外功能的箱子/多流體儲罐，且可斷開網路連線以禁用額外功能。因此，在某些需要儲存少量多種事物的特定場合下，它們十分有用。

## 介面內部的工作原理

正如前文所提，介面本質上就是箱子和儲罐，再附上一些超級酷炫的<ItemLink id="import_bus" />和<ItemLink id="export_bus" />以及<ItemLink id="level_emitter" />。

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        一系列標準發信器，用於維持設定的物品數量
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        一系列標準發信器，用於維持設定的物品數量
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        一系列超級酷炫的輸入匯流排，每遊戲刻能傳輸1組事物
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        一系列超級酷炫的輸出匯流排，每遊戲刻能傳輸1組事物
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9個獨立的內部槽位
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## 特殊互動

介面和其他AE2[裝置](../ae2-mechanics/devices.md)間有若干種特殊互動功能：

連線有<ItemLink id="storage_bus" />的未經修改的介面會將其所處網路的[網路儲存](../ae2-mechanics/import-export-storage.md)向儲存匯流排所處網路展示，此時介面網路就好像一整個接有儲存匯流排的大箱子。在介面的過濾槽中設定物品會禁用此特性。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

樣板供應器和介面有一特殊互動效果⸺[子網路](../ae2-mechanics/subnetworks.md)：如果介面未經修改（請求槽內無內容），則供應器會跳過介面，直接輸出到該子網路的[儲存模組](../ae2-mechanics/import-export-storage.md)，而非輸出到介面的儲存槽；更重要的是，只要對應的儲存模組沒有足夠的空間，下一批物品就不會輸出。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        介面（必須為面板型，不能為方塊型）
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        儲存匯流排
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        樣板供應目的地（多臺機器，或單臺機器的多個面）
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 變種

介面有2種變種：普通、面板/[子部件](../ae2-mechanics/cable-subparts.md)。這會影響各面輸出材料，接收物品，提供網路連線的能力。

*   普通型介面會向各面輸出材料，會從各面接收物品，且和大多數AE2機器一樣向各面提供網路連線，類似線纜。

*   面板型介面是[線纜子部件](../ae2-mechanics/cable-subparts.md)，因此可在同一線纜上放置多個，便於設計緊湊設施。它們能從其儲存空間輸出，或接收物品至儲存空間，並給予其他事物訪問其儲存空間的許可權，但不提供網路連線。

介面的普通和麵板形態可在合成方格中轉換。

## 設定

介面上排槽位設定需要儲存於自身的物品。可直接放入或從JEI/REI中拖拽放入，有物品的槽位上方會出現扳手圖示，可用其設定數量。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

設定為儲存模式的槽位同時不會接受任何其他事物進入其中。

## 升級

介面支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="fuzzy_card" />使得介面能按耐久度或忽略物品NBT過濾
*   <ItemLink id="crafting_card" />使介面能向[自動合成](../ae2-mechanics/autocrafting.md)系統傳送所需物品的請求；其會優先從儲存中獲取物品，無足夠物品才會傳送合成請求

## 優先順序

可點選GUI右上角扳手以設定優先順序。高優先順序的介面會先於低優先順序介面獲取物品。

## 配方

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />

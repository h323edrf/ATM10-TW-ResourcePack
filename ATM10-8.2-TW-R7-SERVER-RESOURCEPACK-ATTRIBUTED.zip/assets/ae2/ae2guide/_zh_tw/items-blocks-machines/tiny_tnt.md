---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 迷你TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# 迷你TNT

<BlockImage id="tiny_tnt" scale="8" />

專為小型爆炸設計的小型TNT。在製造<ItemLink id="quantum_entangled_singularity" />對的過程中非常有用。

如果需要在伺服器中禁用TNT和苦力怕，可在設定檔中禁用此物品的地形破壞效果，從而允許在禁用破壞地形的情況下製作奇點對。

## 配方

<RecipeFor id="tiny_tnt" />

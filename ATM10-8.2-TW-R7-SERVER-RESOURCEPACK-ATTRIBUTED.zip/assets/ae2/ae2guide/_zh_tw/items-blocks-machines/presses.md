---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 壓印模板
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# 壓印模板

共有5種壓印模板可用於<ItemLink id="inscriber" />。

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## 處理器壓印模板

矽、邏輯、計算、工程壓印模板均用於[處理器](processors.md)的製造過程。這4種壓印模板是由破壞[隕石](../ae2-mechanics/meteorites.md)中<ItemLink id="mysterious_cube" />所得的。也可在<ItemLink id="inscriber" />中複製它們。

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## 名稱壓印模板

名稱壓印模板可用於壓印器以命名物品，與鐵砧類似。

手持<ItemLink id="certus_quartz_cutting_knife" />或<ItemLink id="nether_quartz_cutting_knife" />右擊並放入一個金屬錠，輸入希望印上去的名字後拿出產物即可。可在壓印器內使用一塊或同時使用兩塊名稱壓印模板，若使用兩塊，則會壓印出兩者名稱的結合，先壓印頂部槽位再壓印底部槽位。

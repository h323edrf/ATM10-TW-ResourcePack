---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 觸發匯流排
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# 觸發匯流排

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

觸發匯流排是與<ItemLink id="fluix_glass_cable" />和其他線纜功能類似的匯流排，區別在於其連線狀態會受紅石訊號調控。可用其連通或切斷[ME網路](../ae2-mechanics/me-network-connections.md)的連線。

觸發匯流排會在收到紅石訊號時連通連線，<ItemLink id="inverted_toggle_bus" />則行為相反，會在收到紅石訊號時斷開連線。

需要注意，切換連線狀態會導致網路重啟並重新統計所連的裝置。

它們是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

## 配方

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯珍珠
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# 福魯伊克斯珍珠

<ItemImage id="fluix_pearl" scale="4" />

覆有一層<ItemLink id="fluix_crystal" />的末影珍珠，用於製造若干種AE2元件。

## 配方

<RecipeFor id="fluix_pearl" />

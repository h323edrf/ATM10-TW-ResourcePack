---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME儲存匯流排
  icon: storage_bus
  position: 220
categories:
- devices
item_ids:
- ae2:storage_bus
---

# 儲存匯流排

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/storage_bus.snbt" />
</GameScene>

有想過*不把*箱子倉庫換成其他更合理的設施嗎？我們為此推出了儲存匯流排！

儲存匯流排會將其所連線的容器視為[網路儲存](../ae2-mechanics/import-export-storage.md)。它使得網路能檢視該容器的內容物，並可對該容器輸入輸出以滿足[裝置](../ae2-mechanics/devices.md)的輸入輸出需求。

鑑於AE2的[裝置](../ae2-mechanics/devices.md)功能互動產生<a title="譯註：湧現（Emergence），指多個個體間的相互作用遵循簡單的規則，而它們所組成的系統擁有了個體不具備的特性，這種特性僅存在於系統的層面。">湧現</a>機制的哲學，儲存匯流排*並不*只具有*儲存*功能。如果將[子網路](../ae2-mechanics/subnetworks.md)的*唯一*儲存位置設定為若干儲存匯流排，就可將這些匯流排視為物品傳輸的起點或終點。（見[“管道”子網路](../example-setups/pipe-subnet.md)。）

注意事項：抽屜這類經過最佳化的大容器效能表現不錯，但巨型箱子等擁有大量槽位的、*未*經最佳化的大容器和儲存匯流排放在一起時，效能會受到嚴重影響。

儲存匯流排是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

## 過濾

預設情況下，儲存匯流排會儲存所有事物。放入其過濾槽的物品會加入白名單，也即只會儲存其中指明的事物。

如果沒有所需物品或流體，可從JEI/REI中拖拽以放入過濾槽。

用流體容器（如鐵桶或流體儲罐）右擊即可將流體設為過濾，而非鐵桶和儲罐物品。

## 優先順序

可點選GUI右上角扳手以設定優先順序。輸入網路的物品會優先進入最高優先順序的儲存位置，如果有兩個優先順序相同的儲存位置，則會優先選擇已經存有該物品的那個。所有白名單元件在同優先順序情況下視作已經存有該物品。從儲存中輸出的物品會優先從最低優先順序的位置輸出。這一優先順序系統使得在輸入輸出物品的過程中，高優先順序的儲存位置會被填滿，而低優先順序的會被搬空。

## 設定

*   儲存匯流排可分割槽（過濾）為相鄰容器當前的內容物。
*   可設定相鄰容器中無法被匯流排抽出的物品是否對網路可見（例如，儲存匯流排無法從<ItemLink id="inscriber" />的中間輸入槽中抽出物品）。
*   儲存匯流排可設定為雙向過濾或僅過濾存入操作。
*   儲存匯流排可為雙向、僅存入、僅輸出。

## 升級

儲存匯流排支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="capacity_card" />增加過濾槽位數
*   <ItemLink id="fuzzy_card" />使得匯流排能按耐久度或忽略物品NBT過濾
*   <ItemLink id="inverter_card" />將白名單變為黑名單
*   <ItemLink id="void_card" />會在對應容器為滿時清空輸入的物品，可避免農場產物堆積。設定分割槽的時候要小心！

## 配方

<RecipeFor id="storage_bus" />

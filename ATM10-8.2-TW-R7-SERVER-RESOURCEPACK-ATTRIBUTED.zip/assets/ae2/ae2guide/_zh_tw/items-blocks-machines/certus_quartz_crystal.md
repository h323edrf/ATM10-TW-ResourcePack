---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 賽特斯石英水晶
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# 賽特斯石英水晶

<ItemImage id="certus_quartz_crystal" scale="4" />

*“賽特斯石英水晶具有一種獨特性質⸺它的晶態基質中能儲存大量能量”*

AE2方塊、[裝置](../ae2-mechanics/devices.md)、物品的基礎合成材料之一。由培養[賽特斯石英母巖](../ae2-mechanics/certus-growth.md)獲得。

## 部分替代配方

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />

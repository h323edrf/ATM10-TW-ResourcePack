---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 奇點
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# 奇點

<ItemImage id="singularity" scale="4" />

極其緻密的物質球。

由奇點模式的<ItemLink id="condenser" />聚合256,000個物品或256,000桶流體而得。

## 量子纏繞態奇點

<ItemImage id="quantum_entangled_singularity" scale="4" />

在兩個[量子網橋](quantum_bridge.md)間建立連線的必需品，製造時必然成對產出。在需連線的量子網橋中<ItemLink id="quantum_link" />放入一對量子纏繞態奇點之一即可。

在<ItemLink id="minecraft:ender_pearl" />或<ItemLink id="ender_dust" />和<ItemLink id="singularity" />間觸發反應即可合成量子纏繞態奇點。任何爆炸力都應能觸發反應。

<RecipeFor id="quantum_entangled_singularity" />

***幾乎任何爆炸都行得通，甚至也包括苦力怕的。***

產出時必然成對，但只需消耗單個<ItemLink id="singularity" />。

推薦在製成時使用原版鐵砧為其命名。

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: P2P通道
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# P2P通道

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2P通道是在網路中傳輸物品、流體、紅石訊號、能量、光、[頻道](../ae2-mechanics/channels.md)等事物的一種方式，且不必直接與網路互動。P2P通道有多種變種，每種只能傳輸一類事物。可將它們看做能遠距直接連線兩方塊的傳送門。這種連線有確定的輸入和輸出端，而並非雙向的。

![Portal](../assets/assemblies/p2p_portal.png)

例如，朝向物品P2P通道的漏斗和直接放在木桶上的漏斗沒有區別，物品可以正常傳輸。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

但是，相鄰放置的兩個木桶不會互相傳輸物品。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

也有其他變種，如紅石P2P通道。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

以及傳輸頻道的ME P2P通道。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2P通道的型別與調諧

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

P2P通道有許多種類，其中只有ME P2P通道才可直接合成，其他則需要以物品右擊任意P2P通道：
- ME P2P通道需手持任意[線纜](cables.md)右擊調諧
- 紅石P2P通道需手持紅石元件右擊調諧
- 物品P2P通道需手持箱子或漏斗右擊調諧
- 流體P2P通道需手持鐵桶或玻璃瓶右擊調諧
- 能源P2P通道需手持能量容器右擊調諧
- 光P2P通道需手持火把或熒石右擊調諧

某些P2P通道的特性比較奇怪。比如，ME P2P通道的頻道無法穿過其他ME P2P通道，能源P2P通道則會因自身[能量](../ae2-mechanics/energy.md)消耗而剋扣途徑能量的2.5%（FE、E）。

## P2P通道的最常見用途

P2P通道的最常見用途是透過ME P2P通道以高效傳輸[頻道](../ae2-mechanics/channels.md)。傳輸大量頻道不再需要一束緻密線纜了，一根緻密線纜就已足夠。

在此示例中，8個ME P2P通道輸入端會從主網路的<ItemLink id="controller" />中傳輸256（8*32）個頻道，其餘8個ME P2P輸出端則將其送至其他位置。注意每個P2P通道輸入和輸出端只佔用1個頻道。如此就可在單根線纜中傳輸大量頻道了。而因為P2P通道均位於專用[子網路](../ae2-mechanics/subnetworks.md)中，它們甚至不會佔用主網路的頻道！此外，注意P2P通道可直接面向控制器放置，可在兩者間放入[緻密線纜](cables.md#智慧線纜)以視覺化被傳輸的頻道。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        石英纖維會在主網路和P2P子網路間傳輸能量。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        可以直接讓P2P通道傳輸面緊貼控制器，或者用線纜連線兩者。
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

另一示例（與[量子橋](quantum_bridge.md)共同運用）可見下方用畫圖畫出來的粗略圖案：

![P2P和量子橋](../assets/diagrams/p2p_quantum_network.png)

## 巢狀

但是，這一系統無法在單根線纜中傳輸無限頻道。ME P2P通道的頻道無法穿過其他ME P2P通道，也因此無法巢狀它們。注意位於外層紅色線纜上的ME P2P通道處於離線狀態。這一性質僅適用於ME P2P通道，其他種類的P2P通道則可穿過ME P2P通道；比如，此處連線的紅石P2P通道能正常工作。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## 連線

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2P通道連線可用<ItemLink id="memory_card" />建立。連線頻率會在P2P通道背面顯示為2x2的顏色陣列。
- Shift右擊以生成新P2P連線頻率。
- 右擊以貼上設定或升級卡，或連線頻率。

Shift右擊的通道為輸入端，右擊的通道為輸出端。允許存在多個輸出端，但ME P2P通道傳輸的頻道會分給各輸出端，而非每個輸出端都獲得所有頻道，如此可避免頻道複製。

## 配方

<RecipeFor id="me_p2p_tunnel" />
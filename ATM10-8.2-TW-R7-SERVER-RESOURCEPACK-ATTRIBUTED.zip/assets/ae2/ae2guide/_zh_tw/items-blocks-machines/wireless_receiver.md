---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線接收器
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# 無線接收器

<ItemImage id="wireless_receiver" scale="4" />

置於反射碟中的<ItemLink id="fluix_pearl" />，是一種短距離無線ME科技元件。

## 配方

<RecipeFor id="wireless_receiver" />

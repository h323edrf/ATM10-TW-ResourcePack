---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 切割刀
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# 切割刀

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

切割刀可用於製作<ItemLink id="name_press" />和<ItemLink id="cable_anchor" />。

製作名稱壓印模板時，只需手持切割刀右擊並放入一個金屬錠，輸入希望印上去的名字後拿出產物即可。

## 配方

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>

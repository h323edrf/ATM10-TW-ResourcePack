---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯工具
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# 福魯伊克斯工具

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

[福魯伊克斯](fluix_crystal.md)工具與鐵工具類似，但其耐久度為3倍，且攻擊傷害和挖掘速度較高。

所有福魯伊克斯工具都可視作自帶時運 I/搶奪 I，在沒有附魔臺時相當有用。

需要製作<ItemLink id="fluix_upgrade_smithing_template" />。

## 配方

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: ME驅動器
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# ME驅動器

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

驅動器是用於放置[儲存元件](storage_cells.md)的[裝置](../ae2-mechanics/devices.md)，其中元件視作[網路儲存](../ae2-mechanics/import-export-storage.md)。其有10個接受單個元件的槽位。

如有需求，可使用任意物流方式（如漏斗和AE2匯流排）抽取或存入元件。

可被<ItemLink id="certus_quartz_wrench" />旋轉。

## 元件狀態LED

驅動器中的元件可透過其LED表明其狀態：

| 顏色 | 狀態                                                          |
| :--- | :------------------------------------------------------------ |
| 綠色 | 空                                                            |
| 藍色 | 裝有事物                                                      |
| 橙色 | [型別](../ae2-mechanics/bytes-and-types.md)已滿，不可新增型別 |
| 紅色 | [位元組](../ae2-mechanics/bytes-and-types.md)已滿，不可新增物品 |
| 黑色 | 無能量或驅動器缺少[頻道](../ae2-mechanics/channels.md)        |

## 優先順序

可點選GUI右上角扳手以設定優先順序。輸入網路的物品會優先進入最高優先順序的儲存位置，如果有兩個優先順序相同的儲存位置，則會優先選擇已經存有該物品的那個。經過[分割槽](cell_workbench.md)的元件在同優先順序情況下視作已經存有該物品。從儲存中輸出的物品會優先從最低優先順序的位置輸出。這一優先順序系統使得在輸入輸出物品的過程中，高優先順序的儲存位置會被填滿，而低優先順序的會被搬空。

## 配方

<RecipeFor id="drive" />

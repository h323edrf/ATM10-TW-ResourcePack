---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 偽裝板
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# 偽裝板

偽裝板能讓基地看起來更整潔。它們能遮擋各種形制的線纜，且可由多種方塊製成。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

它們能夠遮擋線纜的每一面，但[子部件](../ae2-mechanics/cable-subparts.md)和線纜連線不會被遮斷。

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

靈活使用偽裝板。從提升基地觀感，到製造各面紋理不同的方塊，如此種種都能做到。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 隱藏偽裝板

手持[網路工具](network_tool.md)時偽裝板會自動隱藏。

此時可以直接與隱藏的偽裝板後方的方塊互動，無需取下偽裝板。

## 配方

將帶有想要偽裝成的紋理的方塊放在4個<ItemLink id="cable_anchor" />中間即可。

![偽裝板配方](../assets/diagrams/facade_recipe.png)

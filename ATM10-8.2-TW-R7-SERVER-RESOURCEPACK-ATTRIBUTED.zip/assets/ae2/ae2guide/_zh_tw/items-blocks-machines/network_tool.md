---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 網路工具
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# 網路工具

<ItemImage id="network_tool" scale="4" />

網路工具是[扳手](wrench.md)的改版，它能顯示網路診斷資訊，也能儲存[升級卡](upgrade_cards.md)。它仍保留了扳手拆卸[子部件](../ae2-mechanics/cable-subparts.md)等事物的能力，但無法再旋轉方塊。

網路工具有9個[升級卡](upgrade_cards.md)儲存槽位，當其在物品欄內時，這些升級卡可直接在任意AE2裝置UI中訪問。

與右擊<ItemLink id="controller" />類似，手持網路工具右擊網路任意一處會顯示診斷資訊視窗。此視窗會顯示：

*   網路中頻道佔用數
*   全域性切換網路能量單位（AE、E/FE）
*   網路中當前[能量](../ae2-mechanics/energy.md)總量和最大容量
*   能量流入和使用量
*   網路中所有[裝置](../ae2-mechanics/devices.md)和元件的列表

此視窗在搭建[子網路](../ae2-mechanics/subnetworks.md)時很有用，可用於判斷兩段線纜是否處於同一網路。

## 隱藏偽裝板

手持網路工具時[偽裝板](facades.md)會自動隱藏。

此時可以直接與隱藏的偽裝板後方的方塊互動，無需取下偽裝板。

## 配方

<RecipeFor id="network_tool" />

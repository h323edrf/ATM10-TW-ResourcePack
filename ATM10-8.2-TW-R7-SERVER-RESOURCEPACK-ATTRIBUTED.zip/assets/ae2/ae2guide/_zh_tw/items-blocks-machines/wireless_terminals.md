---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 無線終端
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# 無線終端

<Row>
  <ItemImage id="wireless_terminal" scale="4" />

  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

無線終端是普通有線[終端](terminals.md)的便攜版本。它們的UI完全一致，不過無線終端只有[升級卡](upgrade_cards.md)槽，而無<ItemLink id="view_cell" />槽。

可將終端放入<ItemLink id="wireless_access_point" />右上角槽位（帶有無線終端圖示且下方有箭頭）以與訪問點所在的網路配對。

只有在<ItemLink id="wireless_access_point" />範圍內才能工作。

可在<ItemLink id="charger" />中為其充能。

# 無線終端

<ItemImage id="wireless_terminal" scale="4" />

基礎終端，但是是便攜版！可在<ItemLink id="wireless_access_point" />範圍內任何地方訪問[網路儲存](../ae2-mechanics/import-export-storage.md)，或是向[自動合成](../ae2-mechanics/autocrafting.md)設施傳送請求。

## 介面

見[終端](terminals.md)。

## 升級

無線終端支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="energy_card" />以增加能量容量

## 配方

<RecipeFor id="wireless_terminal" />

# 無線合成終端

<ItemImage id="wireless_crafting_terminal" scale="4" />

無線合成終端和無線終端比較相似，它們的UI區域與設定均相同，但無線合成終端新增了可自動從[網路儲存](../ae2-mechanics/import-export-storage.md)中補充的合成方格。按住Shift合成時要小心謹慎！
## 介面

見[終端](terminals.md)。

## 升級

無線合成終端支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="energy_card" />以增加能量容量

## 配方

<RecipeFor id="wireless_crafting_terminal" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 終端
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# 終端

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="pattern_provider" />、<ItemLink id="import_bus" />、<ItemLink id="storage_bus" />等是AE2網路與世界互動的基礎方式，終端則是AE2網路與*你*互動的基礎方式。終端有多種功能各異的變種。

終端會繼承支援其的[線纜](cables.md)的顏色。

它們是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

## 終端的放置

終端通常是最先放置的[子部件](../ae2-mechanics/cable-subparts.md)，因此出現放置問題或反著放置等都是正常現象。應當做和不應當做的事見下方示例：

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

終端和能源接收器都還在，但終端的方向正確且網路連線正確，整體的空間佔用也更優。

<a name="terminal-ui"></a>

# 終端搜尋

搜尋框接受正規表示式，因此可以輸入“gtceu:.*ore”以搜尋所有格雷科技（Gregtech）的礦石。正規表示式的學習則留給讀者作為練習。

# 終端

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

基礎終端，使你能訪問[網路儲存](../ae2-mechanics/import-export-storage.md)的內容，也可向[自動合成](../ae2-mechanics/autocrafting.md)設施傳送請求。

## 介面

基礎終端的UI分為若干部分。

中間部分為網路儲存，可向其中存入或從中取出物品。此部分支援若干滑鼠/鍵盤快捷鍵：

*   左擊拿出一組，右擊拿出半組
*   如果某物品或流體等允許[自動合成](../ae2-mechanics/autocrafting.md)，繫結至“選取方塊”的按鍵（通常是滑鼠中鍵）會喚起設定自動合成數量的UI。也可輸入諸如`3*64/2`的公式，還可輸入`=32`以補齊網路儲存中距32個物品缺少的數量
*   按住Shift會將所展示物品固定，防止其在數量變動或物品進入系統時重新組織
*   手持桶或其他流體容器右擊可存入流體，以空流體容器左擊終端內流體可將其取出

左側部分有如下設定按鈕：

*   按物品名稱、物品數量、模組等排序
*   瀏覽已儲存、可合成，或兩者均顯示
*   瀏覽物品、流體，或兩者均顯示
*   更改排序順序
*   開啟詳細終端設定視窗
*   更改終端UI的高度

右側部分是<ItemLink id="view_cell" />槽位。

中間部分的右上角（錘子圖示）會顯示[自動合成](../ae2-mechanics/autocrafting.md)狀態UI，允許檢視自動合成的進度和各個[合成CPU](crafting_cpu_multiblock.md)的當前任務。

## 配方

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# 合成終端

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

合成終端和普通終端比較相似，它們的UI區域與設定均相同，但合成終端新增了可自動從[網路儲存](../ae2-mechanics/import-export-storage.md)中補充的合成方格。按住Shift合成時要小心謹慎！

應當**儘快**將普通終端升級為合成終端。

## 介面

合成終端的UI與普通終端的相同，並在中間加入了合成方格。

新增了2個按鈕，可將合成方格內物品清空至網路儲存或物品欄。

## 配方

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# 樣板編碼終端

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

樣板編碼終端和普通終端比較相似，它們的UI區域與設定均相同，但樣板編碼終端新增了[樣板](patterns.md)編碼介面。其和合成終端的UI外形較為相似，不過此處的合成方格並不能真正進行合成。

應當在擁有合成終端後再配一個樣板編碼終端。

## 介面

樣板編碼終端的UI與普通終端的相同，並在中間加入了[樣板](patterns.md)編碼介面。

樣板編碼介面分為若干區域：

*   可放入<ItemLink id="blank_pattern" />的槽位
*   用於編碼樣板的大箭頭
*   可放入經過編碼的樣板的槽位；在此處放入經過編碼的樣板以修改，按下“編碼”箭頭即可儲存
*   右側用於更改樣板至如下型別的4個選項欄：
    *   合成
    *   處理
    *   鍛造臺
    *   切石機

中間的UI會根據所選編碼型別而變：

*   合成模式：
    *   左擊或從JEI/REI拖拽以將材料加至配方；右擊以移除材料
    *   允許替代配方可支援類似任意木板合成木棍的配方；應當僅在絕對必要時才啟用
    *   流體替代允許使用儲存中的流體替代桶裝流體
    *   也可直接從JEI/REI配方介面中編碼樣板

*   處理模式：
    * 左擊，右擊或從JEI/REI拖拽以設定配方的輸入和輸出
    * 以桶、流體儲罐等流體容器右擊可將其中流體，而非將桶或儲罐物品本身設為原材料
    * 持有一組物品時，左擊放入整組，右擊放入一個物品；左擊已有的材料移除整組，右擊則減少一個；繫結至“選取方塊”的按鍵（通常是滑鼠中鍵）可精確設定物品或流體所需量
    * 輸出槽中有一個主產物槽和若干副產物槽，方便自動合成演算法獲取資訊
    * 輸入和輸出槽都可滾動，共有81個材料槽和26個副產物槽
    * 也可直接從JEI/REI配方介面中編碼樣板

*   鍛造臺和切石機模式的UI和實際的鍛造臺與切石機類似。

## 配方

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# 樣板管理終端

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

樣板管理終端可以解決此類問題：在一整個緊湊的<ItemLink id="pattern_provider" />和<ItemLink id="molecular_assembler" />陣列中無法直接向供應器放入樣板。此外，也可解決不想跑到基地其他位置放[樣板](patterns.md)的懶惰問題。樣板管理終端允許訪問網路中的所有樣板供應器。

## 介面

樣板管理終端的UI和其他終端不同。

此UI有UI高度和顯示何種樣板供應器的設定。

終端中每一行都對應一個樣板供應器。

各樣板供應器會根據其連線的方塊以及名稱（鐵砧或<ItemLink id="name_press" />賦予）分類。

## 配方

<RecipeFor id="pattern_access_terminal" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 賽特斯石英塊
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# 賽特斯石英塊

<BlockImage id="quartz_block" scale="8" />

用於儲存<ItemLink id="certus_quartz_crystal" />的方塊。可用於製造[賽特斯石英母巖](budding_certus.md)和[賽特斯石英裝飾方塊](decorative_certus.md)。

## 配方

<RecipeFor id="quartz_block" />

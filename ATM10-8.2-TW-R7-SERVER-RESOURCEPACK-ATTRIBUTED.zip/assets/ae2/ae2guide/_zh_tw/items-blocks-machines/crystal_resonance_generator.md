---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 水晶諧振發生器
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# 水晶諧振發生器

<BlockImage id="crystal_resonance_generator" scale="8" />

此裝置無需燃料就能為ME網路產生能量。同時它也會產生晶體振盪，同一個網路也因此只能存在一臺這種裝置。這種振盪甚至能在<ItemLink id="quartz_fiber" />中傳播。

**發電速率：**<ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## 配方

<RecipeFor id="crystal_resonance_generator" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 量子橋
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# 量子網橋

![已搭建完成的量子網橋](../assets/diagrams/quantum_bridge_demonstration.png)

量子網橋能將[網路](../ae2-mechanics/me-network-connections.md)無限延伸，甚至能跨維度連線。它們能傳輸共32個頻道（無論線纜連線方式如何），可視作無線的[緻密線纜](cables.md#緻密線纜)。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        兩端之間的虛線纜
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

需要注意，**量子網橋的兩端點均需區塊載入**，假如兩端距離很遠，則必須使用<ItemLink id="spatial_anchor" />或再加區塊載入器。

# 量子環

<BlockImage id="quantum_ring" scale="8" />

在<ItemLink id="quantum_link" />周圍放下8個此方塊即可建立一個量子網橋。只有與<ItemLink id="quantum_link" />相鄰的4個<ItemLink id="quantum_ring" />才會接受網路連線，角上的4格無法與線纜相連。

## 配方

<RecipeFor id="quantum_ring" />

# 量子連結倉

<BlockImage id="quantum_link" scale="8" />

在<ItemLink id="quantum_ring" />的中心放下1個此方塊即可建立一個量子網橋。此方塊不會與線纜相連，且只會在量子網橋搭建完畢後算作網路元件。

此方塊的儲存空間可裝下一個<ItemLink id="quantum_entangled_singularity" />，且此儲存空間可被自動化設施訪問。

## 配方

<RecipeFor id="quantum_link" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 染色球
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:orange_paint_ball
- ae2:magenta_paint_ball
- ae2:light_blue_paint_ball
- ae2:yellow_paint_ball
- ae2:lime_paint_ball
- ae2:pink_paint_ball
- ae2:gray_paint_ball
- ae2:light_gray_paint_ball
- ae2:cyan_paint_ball
- ae2:purple_paint_ball
- ae2:blue_paint_ball
- ae2:brown_paint_ball
- ae2:green_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
- ae2:white_lumen_paint_ball
- ae2:orange_lumen_paint_ball
- ae2:magenta_lumen_paint_ball
- ae2:light_blue_lumen_paint_ball
- ae2:yellow_lumen_paint_ball
- ae2:lime_lumen_paint_ball
- ae2:pink_lumen_paint_ball
- ae2:gray_lumen_paint_ball
- ae2:light_gray_lumen_paint_ball
- ae2:cyan_lumen_paint_ball
- ae2:purple_lumen_paint_ball
- ae2:blue_lumen_paint_ball
- ae2:brown_lumen_paint_ball
- ae2:green_lumen_paint_ball
- ae2:red_lumen_paint_ball
- ae2:black_lumen_paint_ball
---

# 染色球

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />

  <ItemImage id="orange_paint_ball" scale="4" />

  <ItemImage id="green_paint_ball" scale="4" />

  <ItemImage id="blue_paint_ball" scale="4" />

  <ItemImage id="red_paint_ball" scale="4" />
</Row>

染色球可用於<ItemLink id="color_applicator" />，以給[線纜](cables.md)、羊毛、陶瓦、玻璃，混凝土等可染色方塊染色。它們也可用於<ItemLink id="matter_cannon" />以射出一小灘染料。

## 配方

在染料周圍放置8個物質球。

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />

    <RecipeFor id="orange_paint_ball" />

    <RecipeFor id="green_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_paint_ball" />

    <RecipeFor id="red_paint_ball" />

    <RecipeFor id="black_paint_ball" />
  </Row>

  <br />
</Column>

# 光通染色球

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />

  <ItemImage id="orange_lumen_paint_ball" scale="4" />

  <ItemImage id="green_lumen_paint_ball" scale="4" />

  <ItemImage id="blue_lumen_paint_ball" scale="4" />

  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

它們和普通染色球表現相同，不過在<ItemLink id="matter_cannon" />中發射時，它們留下的染料灘會發光。也許適合拿來當訊號槍。

## 配方

在熒石粉周圍放置8個染色球。

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />

    <RecipeFor id="orange_lumen_paint_ball" />

    <RecipeFor id="green_lumen_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />

    <RecipeFor id="red_lumen_paint_ball" />

    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>

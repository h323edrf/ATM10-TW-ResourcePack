---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英纖維
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# 石英纖維

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

石英纖維可在[網路](../ae2-mechanics/me-network-connections.md)之間傳輸能量而不會將其連線起來。也由此不用到處擺能源接收器和供能線纜就能給[子網路](../ae2-mechanics/subnetworks.md)供能了。它也能阻止線纜連線，不過使用異色線纜或者<ItemLink id="cable_anchor" />更便宜也更有效。

石英纖維是[線纜子部件](../ae2-mechanics/cable-subparts.md)。

## 配方

<RecipeFor id="quartz_fiber" />

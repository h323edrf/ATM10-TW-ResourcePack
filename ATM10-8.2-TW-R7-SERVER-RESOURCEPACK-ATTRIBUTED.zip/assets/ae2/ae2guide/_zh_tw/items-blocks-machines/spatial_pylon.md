---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空間塔
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# 空間塔

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

空間塔用於[空間IO](../ae2-mechanics/spatial-io.md)，可生成空間場並確定影響區域。

每一段連續的空間塔段佔用1個[頻道](../ae2-mechanics/channels.md)。

空間塔段至少需2格長才可正常工作。

## 配方

<RecipeFor id="spatial_pylon" />
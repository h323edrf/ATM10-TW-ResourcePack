---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 隕石羅盤
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# 隕石羅盤

<ItemImage id="meteorite_compass" scale="4" />

隕石羅盤會指向最近的<ItemLink id="mysterious_cube" />，也即指向最近的[隕石](../ae2-mechanics/meteorites.md)。應當首先製作這種AE2物品。

## 配方

<RecipeFor id="meteorite_compass" />

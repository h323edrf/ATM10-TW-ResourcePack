---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 樣板
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# 樣板

<ItemImage id="crafting_pattern" scale="4" />

樣板可在<ItemLink id="pattern_encoding_terminal" />中以空白樣板製作而得，可裝入<ItemLink id="pattern_provider" />和<ItemLink id="molecular_assembler" />。

有若干種不同的樣板，分別為不同處理方式設計：

*   <ItemLink id="crafting_pattern" />能編碼工作臺的配方。可將此類樣板直接放入<ItemLink id="molecular_assembler" />以令其在收到材料時自動合成，但它們的主要用途是放在與分子裝配室相鄰的<ItemLink id="pattern_provider" />中。樣板供應器在此情況下有特殊行為，會將相關樣板和材料輸入相鄰裝配室。因為裝配室會將產物自動彈出到相鄰容器，相鄰放置的裝配室和樣板供應器就是自動化合成樣板所需的一切了。

***

*   <ItemLink id="smithing_table_pattern" />與合成樣板非常相似，但編碼的是鍛造臺配方。它們也可透過樣板供應器和分子裝配室自動化，工作流程也完全一致。實際上，合成、鍛造臺、切石機樣板所需的設施均完全一致。

***

*   <ItemLink id="stonecutting_pattern" />與合成樣板非常相似，但編碼的是切石機配方。它們也可透過樣板供應器和分子裝配室自動化，工作流程也完全一致。實際上，合成、鍛造臺、切石機樣板所需的設施均完全一致。

***

*   <ItemLink id="processing_pattern" />則是自動合成的靈活性所在。它們是最通用的樣板型別，簡單來說，“如果樣板供應器將這些材料輸出到相鄰容器，則ME系統會在未來某時間點收到這些物品”。它們是配合幾乎所有其他模組機器（或者說熔爐類的機器）自動合成的方式。原因在於它們非常通用，且完全不關心輸出材料和輸入產物間發生了什麼。你大可做些古怪透頂的事，比如將材料輸入一整條複雜工廠產線進行分揀，再從無限生產的農場中運出其他材料，列印出一整篇《蜜蜂總動員》的劇本；只要ME系統能拿到樣板指明的產物，它就完全不會關心這些。實際上，它甚至不會關心材料和產物之間有沒有聯絡。你可以告訴系統“1x 櫻花木板 = 1x 下界之星”，然後讓凋靈農場每接收到一個櫻花木板時殺一隻凋靈即可，完全不會出任何問題。

多個擁有相同樣板的<ItemLink id="pattern_provider" />會並行工作，並且，還可以設定諸如“8x 圓石 = 8x 石頭”的配方，而非“1x 圓石 = 1x 石頭”：樣板供應器每次執行都會向燒煉設施輸入8個圓石而非每次1個。

## 配方

<RecipeFor id="blank_pattern" />

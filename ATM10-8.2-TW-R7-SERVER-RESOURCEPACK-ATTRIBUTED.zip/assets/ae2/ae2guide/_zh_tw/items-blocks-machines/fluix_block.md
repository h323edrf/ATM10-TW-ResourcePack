---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福魯伊克斯塊
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# 福魯伊克斯塊

<BlockImage id="fluix_block" scale="8" />

用於儲存<ItemLink id="fluix_crystal" />的方塊。也用在部分機器的配方中。

## 配方

<RecipeFor id="fluix_block" />

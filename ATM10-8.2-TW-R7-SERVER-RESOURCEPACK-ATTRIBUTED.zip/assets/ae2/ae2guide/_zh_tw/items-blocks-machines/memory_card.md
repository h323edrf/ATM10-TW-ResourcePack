---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 記憶體卡
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# 記憶體卡

<ItemImage id="memory_card" scale="4" />

記憶體卡可在AE2[裝置](../ae2-mechanics/devices.md)間複製貼上設定，也可連線[P2P通道](p2p_tunnels.md)。它也能將[升級卡](upgrade_cards.md)複製到裝置中。

- Shift右擊以生成新P2P連線頻率。
- 右擊以貼上設定或升級卡，或連線頻率。

## 配方

<RecipeFor id="memory_card" />

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 能源元件
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# 能源元件

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

能源元件給予網路更大的[能量](../ae2-mechanics/energy.md)容量。一定量的能量快取能減少大量輸入輸出造成的能量尖峰影響，更大的能量儲存容量則使得網路能在脫離供電時（例如晚上的太陽能板陣列）運作，也可處理[空間儲存](../ae2-mechanics/spatial-io.md)產生的巨量瞬時能量消耗。

## 填充條

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

元件側面的填充條對應其能量水平。

*   充滿程度少於25%時為0。
*   充滿程度在25%到50%之間時為1。
*   充滿程度在50%到75%之間時為2。
*   充滿程度在75%到99%之間時為3。
*   充滿程度超過99%時為4。

## 元件種類

*   <ItemLink id="energy_cell" />可儲存200kAE，能輕鬆應對普通網路的能量尖峰；通常，每個網路中放一個就夠了。
*   <ItemLink id="dense_energy_cell" />可儲存1.6MAE，適用於脫離能量供應執行網路的情況和處理大型[空間儲存](../ae2-mechanics/spatial-io.md)的巨量瞬時能量消耗。
*   <ItemLink id="creative_energy_cell" />是用於測試的創造模式物品，能提供無！限！能！量！

## 配方

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 儲存元件
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# 儲存元件

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

儲存元件是應用能源中儲存的基礎方式之一。需將其裝入<ItemLink id="drive" />或<ItemLink id="chest" />中。

有關其位元組和型別容量的介紹參見[位元組與型別](../ae2-mechanics/bytes-and-types.md)。

若儲存元件為空，則可手持Shift右擊以將儲存元件從元件外殼中取出。

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    在合成方格中將儲存元件與更高階的儲存元件合成，即可將其升級為更高階的儲存元件。元件內的事物會保留，同時會返還較低階的儲存元件。
</Row>

## 儲存容量與型別數變化關係

[每型別預先佔用量](../ae2-mechanics/bytes-and-types.md)設計為：存有1個型別的元件的容量是存滿63個元件的容量的兩倍。

| 元件                                     | 使用1個型別時總容量 | 使用63個型別時總容量 |
| ---------------------------------------- | ------------------: | -------------------: |
| <ItemLink id="item_storage_cell_1k" />   |               8,128 |                4,160 |
| <ItemLink id="item_storage_cell_4k" />   |              32,512 |               16,640 |
| <ItemLink id="item_storage_cell_16k" />  |             130,048 |               66,560 |
| <ItemLink id="item_storage_cell_64k" />  |             520,192 |              266,240 |
| <ItemLink id="item_storage_cell_256k" /> |           2,080,768 |            1,064,960 |


## 分割槽

與過濾<ItemLink id="storage_bus" />類似，元件可過濾為只接受特定物品。此操作需在<ItemLink id="cell_workbench" />中完成。

如果沒有所需物品，可從JEI/REI中拖拽以放入過濾槽。

## 升級

儲存元件支援如下[升級](upgrade_cards.md)，需用<ItemLink id="cell_workbench" />裝入：

*   <ItemLink id="fuzzy_card" />（流體元件不可用）使得元件可按耐久度或忽略NBT分割槽
*   <ItemLink id="inverter_card" />將白名單變為黑名單
*   <ItemLink id="equal_distribution_card" />會為每個型別分配同等大小的扇區，也即單個型別無法填滿元件
*   <ItemLink id="void_card" />會在元件已滿（或在裝有均分卡時某型別已滿）時銷燬輸入的物品，可避免農場產物堆積。設定分割槽的時候要小心！
*   便攜元件也接受<ItemLink id="energy_card" />，可增加其能量容量

## 染色

便攜物品和流體元件可像皮革盔甲一樣染色，與染料合成即可。

# 外殼

元件可由儲存元件和外殼合成，也可在外殼配方中央放入儲存元件：

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

外殼自身的配方如下：

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# 儲存元件

儲存元件是所有AE2元件的核心，決定了元件的容量。每級元件的容量是前一級的4倍，消耗則為3倍。

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# 物品儲存元件

物品儲存元件可儲存最多63種物品，且覆蓋所有標準容量。

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## 便攜物品元件

它們是口袋版（或者揹包版）的<ItemLink id="chest" />。可在<ItemLink id="charger" />中為其充能。

和標準的儲存元件不同，隨著位元組容量上升，它們的型別容量會*下降*，且位元組容量為標準的一半。

除其他元件能接受的升級卡外，便攜元件也接受<ItemLink id="energy_card" />以增加能量容量。

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# 流體儲存元件

流體儲存元件可儲存最多5種流體，且覆蓋所有標準容量。

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## 便攜流體元件

它們是口袋版（或者揹包版）的<ItemLink id="chest" />。可在<ItemLink id="charger" />中為其充能。

和標準的儲存元件不同，隨著位元組容量上升，它們的型別容量會*下降*，且位元組容量為標準的一半。

除其他元件能接受的升級卡外，便攜元件也接受<ItemLink id="energy_card" />以增加能量容量。

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# 創造儲存元件

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

創造元件**並不能提供無限儲存空間**。它們是所[分割槽](cell_workbench.md)物品或流體的無限供應源和銷燬池。

---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 石英工具
  icon: certus_quartz_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_axe
- ae2:certus_quartz_hoe
- ae2:certus_quartz_shovel
- ae2:certus_quartz_pickaxe
- ae2:certus_quartz_sword
- ae2:nether_quartz_axe
- ae2:nether_quartz_hoe
- ae2:nether_quartz_shovel
- ae2:nether_quartz_pickaxe
- ae2:nether_quartz_sword
---

# 石英工具

<Row>
  <ItemImage id="certus_quartz_axe" scale="4" />

  <ItemImage id="certus_quartz_hoe" scale="4" />

  <ItemImage id="certus_quartz_shovel" scale="4" />

  <ItemImage id="certus_quartz_pickaxe" scale="4" />

  <ItemImage id="certus_quartz_sword" scale="4" />
</Row>

<Row>
  <ItemImage id="nether_quartz_axe" scale="4" />

  <ItemImage id="nether_quartz_hoe" scale="4" />

  <ItemImage id="nether_quartz_shovel" scale="4" />

  <ItemImage id="nether_quartz_pickaxe" scale="4" />

  <ItemImage id="nether_quartz_sword" scale="4" />
</Row>

石英工具與鐵工具完全一致：兩者的攻擊傷害、耐久度、挖掘速度等均完全一致。有下界石英和[賽特斯石英](fluix_crystal.md)的變種。

## 配方

<Column>
  <Row>
    <RecipeFor id="certus_quartz_axe" />

    <RecipeFor id="certus_quartz_hoe" />

    <RecipeFor id="certus_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="certus_quartz_pickaxe" />

    <RecipeFor id="certus_quartz_sword" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_axe" />

    <RecipeFor id="nether_quartz_hoe" />

    <RecipeFor id="nether_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_pickaxe" />

    <RecipeFor id="nether_quartz_sword" />
  </Row>
</Column>

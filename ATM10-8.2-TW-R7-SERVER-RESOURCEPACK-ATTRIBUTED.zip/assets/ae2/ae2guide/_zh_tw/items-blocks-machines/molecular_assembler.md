---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 分子裝配室
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# 分子裝配室

<BlockImage id="molecular_assembler" scale="8" />

分子裝配室會接收輸入其中的物品並執行相鄰<ItemLink id="pattern_provider" />設定的操作，或執行其中<ItemLink id="crafting_pattern" />、<ItemLink id="smithing_table_pattern" />、<ItemLink id="stonecutting_pattern" />設定的操作，並將產物輸出到相鄰容器。

下述裝配室裝有一個“1x 橡木原木 = 4x 橡木木板”的樣板。向上方漏斗放入橡木原木，分子裝配室便會開始合成並將橡木木板彈出到下方漏斗。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 分子裝配室的主要用途

它們的主要用途是放在<ItemLink id="pattern_provider" />的相鄰位置。樣板供應器在此情況下有特殊行為，會將相關樣板和材料輸入相鄰裝配室。因為裝配室會將產物自動彈出到相鄰容器（也即彈出到樣板供應器的返回欄內），相鄰放置的裝配室和樣板供應器就是自動化合成樣板所需的一切了。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 升級

分子裝配室支援以下[升級](upgrade_cards.md)：

*   <ItemLink id="speed_card" />

## 配方

<RecipeFor id="molecular_assembler" />

## 註釋

Optifine會破壞“彈出至相鄰容器”功能，導致大多數需要裝配室的合成設施無法工作。
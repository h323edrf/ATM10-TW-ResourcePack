---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 熵變機械臂
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# 熵變機械臂

<ItemImage id="entropy_manipulator" scale="4" />

手持熵變機械臂右擊和Shift右擊可分別加熱或冷卻事物。它的功能不算多，只能蒸發或凍結水，將熔岩固化為黑曜石，將原木燒煉為木炭，將圓石燒煉為石頭。

如果無法對方塊做出特殊操作，則其與打火石表現相同。

可在<ItemLink id="charger" />中為其充能。

## 配方

<RecipeFor id="entropy_manipulator" />

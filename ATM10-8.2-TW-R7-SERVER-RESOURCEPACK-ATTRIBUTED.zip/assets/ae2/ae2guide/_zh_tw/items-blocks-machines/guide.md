---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 指南
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# 指南

<ItemImage id="guide" scale="8" />

### 這就是你正在讀的指南，適用於所有AE2的指導需求。

* 左側為側邊欄，其中有所有條目的目錄。
* 許多頁面都有互動示例圖。若示例圖旁邊有![加號](../assets/diagrams/plus.png)和![減號](../assets/diagrams/minus.png)（縮放）按鈕，即可選擇和移動視角。按住左鍵拖拽以旋轉，按住右鍵拖拽以平移。

## 配方

<RecipeFor id="guide" />

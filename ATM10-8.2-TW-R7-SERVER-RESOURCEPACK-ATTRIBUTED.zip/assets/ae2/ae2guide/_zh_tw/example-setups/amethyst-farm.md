---
navigation:
  parent: example-setups/example-setups-index.md
  title: 紫水晶農場
  icon: minecraft:amethyst_shard
---

# 刷取紫水晶

雖然<ItemLink id="growth_accelerator" />對紫水晶有效，但以<ItemLink id="annihilation_plane" />過濾[賽特斯石英芽](../items-blocks-machines/budding_certus.md)的慣用方法對紫晶芽無效。不像未長成的賽特斯石英芽能掉落<ItemLink id="certus_quartz_dust" />，未長成的紫晶芽什麼都不會掉落，而網路永遠能存下“空氣”，因此破壞面板會一直破壞它們。

繞過此問題的方法是將破壞面板附上精準採集。此情況下未長成的紫晶芽就*會*掉落物品（各階段的紫晶芽本身）了，並可過濾處理。

<ItemLink id="minecraft:amethyst_cluster" />需由<ItemLink id="formation_plane" />再次放置並由不帶精準採集的<ItemLink id="annihilation_plane" />再次破壞，即可得到<ItemLink id="minecraft:amethyst_shard" />。

注意，因為紫水晶簇有方向性，成型面板的對側應當有一個完整方塊面。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        （1）破壞面板#1：無可用GUI，附有精準採集。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        （2）成型面板：過濾紫水晶簇。
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        （3）破壞面板#2：無可用GUI，可附有時運。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        （4）儲存匯流排#1：過濾紫水晶碎片。
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        （5）儲存匯流排#2：過濾紫水晶碎片。優先順序高於主儲存。
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* 第一個<ItemLink id="annihilation_plane" />（1）沒有GUI且無法配置，但必須附有精準採集。
* <ItemLink id="formation_plane" />（2）設定為過濾<ItemLink id="minecraft:amethyst_cluster" />。
* 第二個<ItemLink id="annihilation_plane" />（3）沒有GUI且無法配置，可附有時運。
* 第一個<ItemLink id="storage_bus" />（4）設定為過濾<ItemLink id="minecraft:amethyst_shard" />。
* 第二個<ItemLink id="storage_bus" />（5）設定為過濾<ItemLink id="minecraft:amethyst_shard" />，且[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)高於主儲存。

## 工作原理

1. 第一個<ItemLink id="annihilation_plane" />會嘗試破壞其前方的事物，但由於子網路中唯一儲存位置便是過濾為紫水晶簇的<ItemLink id="formation_plane" />，其只會破壞<ItemLink id="minecraft:amethyst_cluster" />。只會在面板附有精準採集時起效，若未附有該魔咒則也會破壞什麼都不掉落的未長成晶芽。
2. <ItemLink id="formation_plane" />將紫水晶簇放置於其對側的方塊。
3. 第二個<ItemLink id="annihilation_plane" />破壞紫水晶簇而得<ItemLink id="minecraft:amethyst_shard" />。
4. 第一個<ItemLink id="storage_bus" />將紫水晶碎片存入木桶。由於第二個破壞面板有可能破壞的事物只會是長成的紫水晶簇，此匯流排實際不需設定過濾。
5. 第二個<ItemLink id="storage_bus" />使得主網路能訪問木桶內的所有紫水晶簇。其[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)應高於主網路，由此紫水晶碎片會優先存入木桶而非主儲存。

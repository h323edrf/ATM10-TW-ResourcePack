---
navigation:
  parent: example-setups/example-setups-index.md
  title: 鐵桶填充器
  icon: minecraft:water_bucket
---

# 鐵桶填充器

參閱[鐵桶清空器](bucket-emptier.md)。

需注意，此設施使用了<ItemLink id="pattern_provider" />，也即需與你的[自動合成](../ae2-mechanics/autocrafting.md)設施配合使用。

生活總有不順心時，有些時候你需要桶裝的流體而非流體本身。有些時候會有一種機器幫你完成這些任務，比如熱力膨脹（Thermal Expansion）裡的流體轉置機；但這種模組並不一定一直都有。好在原版也有一種稍微不那麼方便的處理方式，那就是<ItemLink id="minecraft:dispenser" />。

**需注意，這一設施通常並非必要，[樣板編碼終端](../items-blocks-machines/terminals.md#樣板編碼終端)中的流體替換選項允許你在合成配方中使用流體本身，而非桶裝流體。**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        （1）樣板供應器：設定為“有紅石訊號時”鎖定合成，裝有相應處理樣板。

        <Row>
        ![填充樣板](../assets/diagrams/water_fill_pattern_small.png)
        ![填充樣板](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        （2）介面：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        （3）儲存匯流排#1：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        （4）成型面板：透過反相卡設定為排除鐵桶。
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        （5）輸入匯流排：透過反相卡設定為排除鐵桶。
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        （6）儲存匯流排#2：預設配置。
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## 配置

* <ItemLink id="pattern_provider" />（1）設定為“有紅石訊號時”鎖定合成，裝有相應<ItemLink id="processing_pattern" />。

    ![充能器樣板](../assets/diagrams/water_fill_pattern.png)
    ![充能器樣板](../assets/diagrams/lava_fill_pattern.png)

* <ItemLink id="interface" />（2）處於預設配置。
* 第一個<ItemLink id="storage_bus" />（3）處於預設配置。
* <ItemLink id="formation_plane" />（4）透過反相卡設定為排除鐵桶。
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* <ItemLink id="import_bus" />（5）透過反相卡設定為排除鐵桶。
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* 第二個<ItemLink id="storage_bus" />（6）處於預設配置。

## 工作原理

1. <ItemLink id="pattern_provider" />將材料送入<ItemLink id="interface" />。
   （作為最佳化，實際上其會直接穿過儲存匯流排與成型面板輸出，就像它們是供應器自身的輸出面一樣。物品並不會真正進入介面。）
2. 經過[管道子網路](pipe-subnet.md#向多處提供材料)與<ItemLink id="formation_plane" />兩處所述的機制，鐵桶會抵達<ItemLink id="minecraft:dispenser" />，流體則由成型面板放置。
3. <ItemLink id="minecraft:comparator" />檢測發射器中的鐵桶，並由此同時啟用發射器和鎖定<ItemLink id="pattern_provider" />。
4. 發射器用鐵桶裝起流體，此時發射器內為裝有流體的桶。
5. <ItemLink id="import_bus" />將發射器中裝滿的桶抽出，透過<ItemLink id="storage_bus" />存入樣板供應器，並送回主網路。
6. 比較器發現發射器已空，從而解鎖供應器。

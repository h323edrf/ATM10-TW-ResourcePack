---
navigation:
  parent: example-setups/example-setups-index.md
  title: 專用本地儲存
  icon: drive
---

# 專用本地儲存

將[介面的特殊行為](../items-blocks-machines/interface.md#特殊互動)加以運用，就能讓[子網路](../ae2-mechanics/subnetworks.md)不可訪問主網路儲存，而其儲存內容又在主網路中可見，且只會佔用最多1個[頻道](../ae2-mechanics/channels.md)。

適用於某些農場的本地儲存，可避免主網路儲存物品過載。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        （1）物品輸入部分（此例中為介面）。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        （2）驅動器：裝有若干元件。元件應過濾農場輸出產物。可裝有均分卡和溢位銷燬卡。
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        （3）合成終端：此終端可檢視子網路驅動器的內容物，但無法檢視主網路儲存。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        （4）介面#2：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        （5）儲存匯流排：優先順序高於主儲存，可過濾農場輸出產物。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
        合成終端：此終端可同時檢視主網路儲存*和*子網路儲存。
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* 第一個<ItemLink id="interface" />（1）只會接受農場產物並送入子網路。
* <ItemLink id="drive" />（2）內裝有若干[元件](../items-blocks-machines/storage_cells.md)。元件應被[分割槽](../items-blocks-machines/cell_workbench.md)為農場產物。元件可裝有<ItemLink id="equal_distribution_card" />和<ItemLink id="void_card" />。
* 第二個<ItemLink id="interface" />（4）處於預設配置。
* <ItemLink id="storage_bus" />的[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)高於主儲存。可設定為過濾農場產物。

## 工作原理

* 子網路上的<ItemLink id="interface" />會向主網路上的<ItemLink id="storage_bus" />展示<ItemLink id="drive" />的內容物。也即儲存匯流排可直接向該驅動器中的元件輸入輸出。
* 儲存匯流排的[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)較高，由此物品會優先放入子網路而非主網路。
* 重要的是，假如子網路的元件被填滿了，多出的物品不會溢位至主網路。如果農場會因堵塞而失效，可裝入<ItemLink id="void_card" />以刪除多餘物品。
* 如果農場產出多種物品，<ItemLink id="equal_distribution_card" />可避免因其中一種產物填滿所有元件導致其餘產物被堵塞的情況出現。
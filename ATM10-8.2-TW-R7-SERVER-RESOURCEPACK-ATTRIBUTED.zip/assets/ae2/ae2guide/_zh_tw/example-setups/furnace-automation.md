---
navigation:
  parent: example-setups/example-setups-index.md
  title: 熔爐自動化
  icon: minecraft:furnace
---

# 熔爐自動化

需注意，此設施使用了<ItemLink id="pattern_provider" />，也即需與你的[自動合成](../ae2-mechanics/autocrafting.md)設施配合使用。如需獨立自動化熔爐，則應使用漏斗，箱子等。

自動化<ItemLink id="minecraft:furnace" />相較自動化[充能器](../example-setups/charger-automation.md)之類更為簡單的機器來說略顯複雜。熔爐需從兩個不同面輸入，並需從第三個面輸出。需燒煉的物品必須從頂面輸入，燃料必須從側面輸入，產物必須從底面輸出。

這可透過在頂面放置<ItemLink id="pattern_provider" />，在側面放置<ItemLink id="export_bus" />以不斷輸入燃料，在底面放置<ItemLink id="import_bus" />以返回產物至網路解決。然而，這麼做需要佔用3個[頻道](../ae2-mechanics/channels.md)。

如下是僅需佔用1個頻道的方法：

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        （1）樣板供應器：以賽特斯石英扳手改為方向型，裝有相應樣板。

        ![鐵樣板](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        （2）介面：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        （3）儲存匯流排#1：過濾煤炭。
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        （4）儲存匯流排#2：透過反相卡設定為排除煤炭。
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="pattern_provider" />（1）處於預設配置，裝有相應<ItemLink id="processing_pattern" />。已被<ItemLink id="certus_quartz_wrench" />改為方向型。

  ![鐵樣板](../assets/diagrams/furnace_pattern.png)

* <ItemLink id="interface" />（2）處於預設配置。
* 第一個<ItemLink id="storage_bus" />（3）設定為過濾煤炭或其他燃料。
* 第二個<ItemLink id="storage_bus" />（4）以<ItemLink id="inverter_card" />透過反相卡設定為排除所用燃料。

## 工作原理

1. <ItemLink id="pattern_provider" />將材料送入<ItemLink id="interface" />。
   （實際上其會直接向儲存匯流排輸出，這些儲存匯流排類似於供應器自身的輸出面。物品並不會真正進入介面。）
2. 介面設定為不儲存任何事物，因此其會嘗試將材料送入[網路儲存](../ae2-mechanics/import-export-storage.md)。
3. 綠色子網路上的儲存位置僅有<ItemLink id="storage_bus" />。過濾煤炭的匯流排能將煤炭透過熔爐側面送入燃料槽。過濾非煤炭的匯流排則將需燒煉的物品透過頂面送入材料槽。
4. 熔爐幹完本職工作。
5. 漏斗將產物從熔爐底面匯出並放入供應器的返回欄，從而將其返回至主網路。

---
navigation:
  parent: example-setups/example-setups-index.md
  title: 物品/流體“管道”子網路
  icon: storage_bus
---

# 物品/流體“管道”子網路

以下為透過AE2[裝置](../ae2-mechanics/devices.md)模擬物品和流體管道的簡單方式，適用於所有可用物品或流體管道的設計，自然也包括將合成產物送回<ItemLink id="pattern_provider" />的情況。

通常有兩種方法達成這種效果：

## 輸入匯流排 -> 儲存匯流排

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        （1）輸入匯流排：可過濾。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        （2）儲存匯流排：可過濾。此匯流排（以及其他要設為傳輸終點的儲存匯流排）必須為網路中唯一的儲存位置。
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        起點
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        終點
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

連線至起點容器的<ItemLink id="import_bus" />（1）會輸入物品和流體，並嘗試將其存入[網路儲存](../ae2-mechanics/import-export-storage.md)。而網路中唯一的儲存位置是<ItemLink id="storage_bus" />（2）（也說明了為什麼此設施需是子網路而非主網路），物品和流體會存入終點容器，等效於傳輸。能量透過<ItemLink id="quartz_fiber" />供給。輸入匯流排和儲存匯流排均可設定過濾，不過在無過濾時此設施會傳輸所有其能訪問的事物。此設施允許存在多個輸入匯流排和多個儲存匯流排。

## 儲存匯流排 -> 輸出匯流排

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        （1）儲存匯流排：可過濾。此匯流排（以及其他要設為傳輸起點的儲存匯流排）必須為網路中唯一的儲存位置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        （2）輸出匯流排：必須過濾。
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        起點
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        終點
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

連線至終點容器的<ItemLink id="export_bus" />會嘗試從[網路儲存](../ae2-mechanics/import-export-storage.md)中抽取被過濾的物品。而網路中唯一的儲存位置是<ItemLink id="storage_bus" />（也說明了為什麼此設施需是子網路而非主網路），物品和流體會從起點容器中被抽出，等效於傳輸。能量透過<ItemLink id="quartz_fiber" />供給。輸出匯流排只會在其設有過濾時工作，因此此設施只會在輸出匯流排有過濾時工作。此設施允許存在多個儲存匯流排和多個輸出匯流排。

## 無法運作的設計（輸入匯流排 -> 輸出匯流排）

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        （1）輸入匯流排：由於網路中沒有儲存空間，輸入匯流排的輸入目標不存在。
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        （2）輸出匯流排：由於網路中沒有儲存空間，輸出匯流排的輸出來源不存在。
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
        起點
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
        終點
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

只由輸入匯流排和輸出匯流排組成的設施不會運作。輸入匯流排會嘗試從起點容器中抽取物品和流體並存入網路儲存。輸出匯流排會嘗試從網路儲存中抽取物品和流體並輸出至終點容器。但是此網路**沒有儲存位置**，輸入匯流排無法輸入，輸出匯流排也無法輸出，設施不會工作。

## 在同一面上輸入輸出

假如有機器能在單個面上同時接收輸入和彈出輸出（比如<ItemLink id="charger" />），則可綜合2種管道子網路以在同一面上輸入材料和抽出產物：

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        （1）輸入匯流排：可過濾。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        （2）儲存匯流排：可過濾。此儲存匯流排（以及其他用於輸入輸出的儲存匯流排）必須為網路中唯一的儲存位置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        （3）需要輸入輸出的裝置：此處為充能器。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        （4）輸出匯流排：必須過濾。
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
        起點
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
        終點
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 介面

貌似除了輸入匯流排和輸出匯流排，還有其他[裝置](../ae2-mechanics/devices.md)能將物品存入或取出[網路儲存](../ae2-mechanics/import-export-storage.md)！此處提及的這種裝置就是<ItemLink id="interface" />。如果介面接收到物品而又未設定儲存該物品，則其會將該物品存入網路儲存，類似於“輸入匯流排 -> 儲存匯流排”管道。將介面設定為儲存物品，則其會從網路儲存中抽取，類似於“儲存匯流排 -> 輸出匯流排”管道。如果需要，介面還可設定為儲存某些物品而非其他物品，即可透過儲存匯流排遠端輸入輸出。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        介面
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        儲存匯流排
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
        儲存匯流排
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
        介面
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 一對多與多對一（以及多對多）

當然，<ItemLink id="import_bus" />、<ItemLink id="export_bus" />、<ItemLink id="storage_bus" />並非只能使用一個。

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 向多處提供材料

綜合上述設計，即可得出從單個<ItemLink id="pattern_provider" />面向多處運輸材料的方式，適用於機器陣列，或是單臺機器的多個面。

不採用“輸入 -> 儲存”管道以及“儲存 -> 輸出”管道，因為<ItemLink id="pattern_provider" />無法儲存材料，而是會將材料*輸出*至相鄰容器。因此我們需要某種能接受物品的相鄰容器。

而符合條件的裝置⋯⋯就是<ItemLink id="interface" />！並且供應器需為方向型或面板型，或介面為面板型，或兩個條件均滿足，以避免兩者形成網路連線。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        介面（必須為面板型，不能為方塊型）
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        儲存匯流排
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        樣板供應目的地（多臺機器，或單臺機器的多個面）
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>
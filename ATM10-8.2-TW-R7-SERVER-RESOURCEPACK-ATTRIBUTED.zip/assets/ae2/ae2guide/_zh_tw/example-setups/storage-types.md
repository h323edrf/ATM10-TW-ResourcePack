---
navigation:
  parent: example-setups/example-setups-index.md
  title: 多種儲存方式及網路的整潔性
  icon: drive
---

# 多種儲存方式及保持網路的整潔性

過濾、[分割槽](../items-blocks-machines/cell_workbench.md)、[儲存優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)，這些都能助你構建可供多種事物使用的多層級儲存。

大部分儲存可分為：
* 通用儲存，適用於數量大致為幾千的各類事物。實現主要使用小型[儲存元件](../items-blocks-machines/storage_cells.md)，比如4k和16k儲存元件。
* 大宗儲存，適用於數量超出幾千範圍的各類事物，例如圓石和鐵錠。實現主要使用256k儲存元件等大型儲存元件，也可使用MEGACells附屬中的元件。
* 位於農場的本地儲存，參見[專用本地儲存](specialized-local-storage.md)以及各類賽特斯石英農場（見[簡易](simple-certus-farm.md)、[半自動](semiauto-certus-farm.md)、以及[進階](advanced-certus-farm.md)）。

在物品進入主網路時，優先順序使得主網路首先會嘗試將其存入專用的大宗儲存或本地儲存。若是由於過濾和分割槽設定無法做到，則存入通用儲存。這也說明物品**不會主動**在儲存間轉移，但會在離開或進入網路時“遷移”。若要主動移動物品，可以使用<ItemLink id="io_port" />。

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/network_storage_types.snbt" />

    <BoxAnnotation color="#33dd33" min="11 0 1" max="12 1.3 2" thickness="0.05">
        大宗儲存。此處為面對抽屜等大容量儲存的帶過濾儲存匯流排。該儲存匯流排過濾煤炭。儲存匯流排的優先順序高，因此煤炭進入主網路時會首先進入該儲存匯流排，離開主網路時則會優先從*其他*儲存位置輸出，也即煤炭會“遷移”至該抽屜。

        需要注意：抽屜這類經過最佳化的大容器效能表現不錯，但巨型箱子等擁有大量槽位的、*未*經最佳化的大容器和儲存匯流排放在一起時會對效能有嚴重影響。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="11 0 3" max="12 1 4" thickness="0.05">
        大宗儲存。此處為高優先順序驅動器中的經分割槽的256k儲存元件。這些儲存元件分割槽為圓石和鐵，且裝有均分卡，因此鐵的位置不會被圓石填滿。驅動器的優先順序高，因此圓石和鐵進入主網路時會首先進入該驅動器，離開主網路時則會優先從*其他*儲存位置輸出，也即它們會“遷移”至此處。
    </BoxAnnotation>

    <BoxAnnotation color="#33dddd" min="11 0 5" max="12 1 6" thickness="0.05">
        通用儲存。此處為裝滿16k儲存元件的驅動器。這些儲存元件未經分割槽。驅動器的優先順序中等（此處為0），因此物品等進入網路時會優先進入專用的大宗和本地儲存，離開網路時則會優先從該儲存輸出，也即有對應專用儲存的事物會“遷移”出通用儲存。
    </BoxAnnotation>

    <BoxAnnotation color="#88ff88" min="11 0 8" max="12 1 9" thickness="0.05">
        此IO埠是整理網路的重要元件。由於儲存優先順序並不會使得物品*主動*轉移，所以應當定時“整理”通用儲存中的儲存元件，以此將物品移動到對應的專用儲存中去。這相當於對儲存進行“碎片重組”，以免同種物品被儲存在多個位置。
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 11" max="15 1 12" thickness="0.05">
        位於生物農場的本地儲存。此驅動器裝有分割槽為所需掉落物（如骨頭和箭）的儲存元件。驅動器本身未設定優先順序，這是因為主網路處訪問該子網路的儲存匯流排才是真正決定優先順序的裝置。其中的儲存元件均裝有均分卡和溢位銷燬卡。
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 1 10" max="15 2.3 11" thickness="0.05">
        位於生物農場的本地儲存。此處的儲存匯流排-介面設施允許主網路訪問此子網路的儲存。儲存匯流排具有較高的優先順序，且過濾為子網路中元件所儲存的事物。

        需要注意：由於該子網路中帶有垃圾處理設施，對應的儲存匯流排必須過濾，否則*所有進入網路的物品流體等*都會被銷燬！
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 9" max="15 1.3 10" thickness="0.05">
        位於生物農場的本地儲存。此處面對物質聚合器的儲存匯流排的優先順序低於驅動器。那些無法存入驅動器內元件的掉落物會溢位至此，並加以後續處理。這一部分能避免子網路被大量快壞的弓塞滿的問題，是十分重要的設施。
    </BoxAnnotation>

    <BoxAnnotation color="#dd33dd" min="8 1 11.7" max="9 2.3 13" thickness="0.05">
        位於西瓜農場的本地儲存。該設施的設計與各類賽特斯石英農場示例類似。位於子網路的儲存匯流排會將農作物存入木桶。位於主網路的高優先順序儲存匯流排過濾西瓜片，使得主網路能訪問收穫得來的農作物。
    </BoxAnnotation>

  <IsometricCamera yaw="270" pitch="30" />
</GameScene>
---
navigation:
  parent: example-setups/example-setups-index.md
  title: “主網路”示例
  icon: controller
---

# “主網路”示例

許多其他設施都會提及“主網路”。你可能也在疑惑如何將所有[裝置](../ae2-mechanics/devices.md)組成可執行的系統。示例見下：

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        一大堆樣板供應器和裝配室，提供大量合成、切石、鍛造樣板空間。
        棋盤格式的排布方式能讓供應器並行使用多個裝配室，同時保持設計緊湊。
        8個一組的設計避免了頻道尋路出現錯誤。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        你其實不需要那麼大的控制器；你在其他人基地裡看到的那些龐大的環狀和立方體狀的設計，主要還是為了好看。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        能源元件是好網路的標配，它能提升每遊戲刻的能量輸入，還能減少能量波動的影響。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        推薦使用其他模組的能量源，反應堆、太陽能板、發電機，這些都行。諧振倉也夠用，但AE2是為整合包設計的，最好使用基地的主能源。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="15 1 9" max="16 3 14" thickness="0.05">
        偽裝板能把事物藏在牆後。
    </BoxAnnotation>
    <BoxAnnotation color="#33dd33" min="15 3 12" max="16 10 14" thickness="0.05">
        偽裝板能把事物藏在牆後。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 7" max="14 10 9" thickness="0.05">
        其實不需要為通用儲存準備這麼多驅動器槽和儲存單元，能裝滿2到4個驅動器的4k或16k儲存單元就已足夠。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 10" max="14 11 11" thickness="0.05">
        過濾為特定物品的大型儲存單元最適合大批次儲存，需放置在單獨的高優先順序驅動器組中。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10 9 13" max="11.7 13 14" thickness="0.05">
        基於介面的自動維持物品量設施。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="6 10 12" max="9 12 15" thickness="0.05">
        充能器自動化設施的邏輯擴充套件，包含多個充能器。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 10 12" max="5 11 15" thickness="0.05">
        另一種自動化處理器的方式，這是由於1.20中的壓印器能夠自動彈出產物。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="3 10 10" max="4 12 11" thickness="0.05">
        另一種自動化處理器的方式，這是由於1.20中的壓印器能夠自動彈出產物。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.2 9.2 8.2" max="7.8 10 8.8" thickness="0.05">
        無線訪問點位於中央，是由其球狀範圍所致。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        通常來說，1到2個大容量合成CPU用於大型任務，再來些稍小的CPU在大容量CPU工作時處理次要任務。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="5 3 6" max="6 4 7" thickness="0.05">
        有些時候子網路需要超過8臺裝置（比如分發至超過8個位置），此時它們需要獨立的控制器。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        賽特斯石英農場。
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        投水自動化。
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>

---
navigation:
  parent: example-setups/example-setups-index.md
  title: 自動時運礦石機
  icon: minecraft:raw_iron
---

# 自動化時運挖掘礦石

<ItemLink id="annihilation_plane" />接受所有鎬魔咒，包括時運，因此其常見用途之一便是給幾個面板附上時運，並讓<ItemLink id="formation_plane" />和<ItemLink id="annihilation_plane" />迅速放置和破壞礦石。

注意，<ItemLink id="import_bus" />的執行速度會“緩慢增加”：此設施在啟動時較慢，並會在幾秒後達到最大速度。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        （1）輸入匯流排：裝有若干加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        （2）成型面板：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        （3）破壞面板：無可用GUI，但可附有時運。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        （4）儲存匯流排：預設配置。
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        輸入
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        輸出
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

*   <ItemLink id="import_bus" />（1）中裝有若干<ItemLink id="speed_card" />。陣列內成型面板越多則所需加速卡也越多，可使匯流排一次性拿取更多物品。
*   <ItemLink id="formation_plane" />（2）處於預設配置。
*   <ItemLink id="annihilation_plane" />（3）沒有GUI且無法配置，附有時運。
*   <ItemLink id="storage_bus" />（4）處於預設配置。

## 工作原理

1.  綠色子網路上的<ItemLink id="import_bus" />將方塊從第一個木桶中輸入[網路儲存](../ae2-mechanics/import-export-storage.md)。
2.  綠色子網路上的儲存位置僅有<ItemLink id="formation_plane" />，它們會放置方塊。
3.  橙色子網路上的<ItemLink id="annihilation_plane" />用於破壞方塊，需給它們附上時運。
4.  橙色子網路上的<ItemLink id="storage_bus" />將破壞產物存入第二個木桶。

---
navigation:
  parent: example-setups/example-setups-index.md
  title: 自調控造石機
  icon: minecraft:cobblestone
---

# 自調控造石機

自動化造石機很簡單，把<ItemLink id="annihilation_plane" />朝向一個標準原版手動造石機即可。然而這麼做會導致網路被圓石塞滿，因此需要引入調控。

鑑於破壞面板的工作方式（類似<ItemLink id="import_bus" />），不能直接把<ItemLink id="level_emitter" />面向裝有<ItemLink id="redstone_card" />的<ItemLink id="export_bus" />（因為無法在沒有中間儲存的情況下直接輸入輸出）。需要稍微繞點路。

<ItemLink id="toggle_bus" />可受紅石訊號控制而連線或斷開網路連線，但其觸發會導致網路重啟。對此有一個簡單的解決方案：在[子網路](../ae2-mechanics/subnetworks.md)上放置觸發匯流排。這麼做只會重啟子網路。

可以設計一個由<ItemLink id="annihilation_plane" />和<ItemLink id="storage_bus" />組成的獨立[子網路](../ae2-mechanics/subnetworks.md)以將物品輸入主網路的<ItemLink id="interface" />。觸發匯流排則與<ItemLink id="quartz_fiber" />連線或斷開，以此提供或切斷能量供給。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        （1）破壞面板：無可用GUI，可附有效率和耐久以減少能量消耗。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        （2）儲存匯流排：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        （3）觸發匯流排：注意要放在子網路上，而非主網路。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        （4）標準發信器：配置為所需數量的圓石，紅石模式為“當數量小於設定數值時發出紅石訊號”。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        （5）介面：預設配置。
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
        含水樓梯，防止水流至熔岩處而將其變為黑曜石。
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="annihilation_plane" />（1）無可用GUI，可附有效率和耐久以減少能量消耗。
* <ItemLink id="storage_bus" />（2）處於預設配置。
* <ItemLink id="toggle_bus" />（3）必須位於子網路且與石英纖維連線，而非主網路，否則主網路會在其觸發時重啟。
* <ItemLink id="level_emitter" />（4）設定為所需數量個所需物品，紅石模式為“當數量小於設定數值時發出紅石訊號”。
* <ItemLink id="interface" />（5）處於預設配置。

## 工作原理

1. 造石機產生圓石。
2. <ItemLink id="annihilation_plane" />破壞圓石。
3. <ItemLink id="storage_bus" />將圓石存入<ItemLink id="interface" />，並傳輸回主網路。
4. 當主網路中圓石的數量大於設定數量時，<ItemLink id="level_emitter" />停止發出紅石訊號，並關閉<ItemLink id="toggle_bus" />。
5. 子網路的能量供給被切斷，從而關閉了破壞面板。

---
navigation:
  parent: example-setups/example-setups-index.md
  title: 進階賽特斯石英農場
  icon: certus_quartz_crystal
  position: 120
---

# 進階賽特斯石英農場

此設施和[半自動賽特斯石英農場](semiauto-certus-farm.md)差別不多，唯一區別則在於此設施可完全整合入ME系統中。

此設施不需要大量快取，也無需手動替換母巖，它利用了[充能器自動化](charger-automation.md)和[投水自動化](throw-in-water-automation.md)以自動完成上述任務。

生長速度估計值見[賽特斯石英的生長](../ae2-mechanics/certus-growth.md)。

**這是個有遮擋關係的複雜建築，可以旋轉視角從各向觀察**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        （1）破壞面板#1：無可用GUI，但可附有時運。
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        （2）儲存匯流排#1：過濾賽特斯石英水晶。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    石英簇破壞器子網路
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        （3）破壞面板#2：無可用GUI，附有精準採集。
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        （4）儲存匯流排#2：過濾賽特斯石英塊。
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    賽特斯石英塊破壞器子網路
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        （5）成型面板：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        （6）輸入匯流排：過濾有瑕的賽特斯石英母巖。
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    母巖放置器子網路
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        （7）儲存匯流排#3：過濾賽特斯石英水晶。優先順序高於主網路。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        （8）介面：設定為在自身儲存1個有瑕的賽特斯石英母巖，裝有合成卡。
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        至主網路、充能器自動化設施，以及投水自動化設施
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## 設定

### 石英簇破壞器：

* 第一個<ItemLink id="annihilation_plane" />（1）沒有GUI且無法配置，可附有時運。
* 第一個<ItemLink id="storage_bus" />（2）設定為過濾<ItemLink id="certus_quartz_crystal" />。

### 賽特斯石英塊破壞器：

* 第二個<ItemLink id="annihilation_plane" />（3）沒有GUI且無法配置，但必須附有精準採集。
* 第二個<ItemLink id="storage_bus" />（4）設定為過濾<ItemLink id="quartz_block" />。

### 母巖放置器：

* <ItemLink id="formation_plane" />（5）處於預設配置。
* <ItemLink id="import_bus" />（6）設定為過濾<ItemLink id="flawed_budding_quartz" />。

### 主網路：

* 第三個<ItemLink id="storage_bus" />（7）設定為過濾<ItemLink id="certus_quartz_crystal" />，且其[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)高於主網路儲存。
* <ItemLink id="interface" />（8）設定為在自身儲存1個有瑕的賽特斯石英母巖，裝有<ItemLink id="crafting_card" />。

## 工作原理

### 石英簇破壞器：

石英簇破壞器子網路和[簡單賽特斯石英農場](simple-certus-farm.md)中的子網路功能非常類似。

1. <ItemLink id="annihilation_plane" />嘗試破壞其前方的事物，但由於子網路中儲存位置僅有過濾<ItemLink id="certus_quartz_crystal" />的<ItemLink id="storage_bus" />，其只會破壞<ItemLink id="quartz_cluster" />。
2. <ItemLink id="storage_bus" />將賽特斯石英水晶存入木桶。

### 賽特斯石英塊破壞器：

賽特斯石英塊破壞器的功能是在母巖枯竭而變為<ItemLink id="quartz_block" />時將其破壞。此設施和石英簇破壞器原理類似。

1. <ItemLink id="annihilation_plane" />嘗試破壞其前方的事物，但由於子網路中儲存位置僅有過濾<ItemLink id="quartz_block" />的<ItemLink id="storage_bus" />，其只會破壞<ItemLink id="quartz_block" />。此面板需附有精準採集，避免破壞母巖的行為本身導致的降級。
2. <ItemLink id="storage_bus" />將賽特斯石英塊存入<ItemLink id="interface" />，交由[投水自動化](throw-in-water-automation.md)設施用其製成新的<ItemLink id="flawed_budding_quartz" />。

### 母巖放置器：

母巖放置器的功能是在破壞器子網路破壞已枯竭的母巖時放置新的<ItemLink id="flawed_budding_quartz" />。

1. <ItemLink id="import_bus" />從<ItemLink id="interface" />中抽取母巖並存入[網路儲存](../ae2-mechanics/import-export-storage.md)。
2. 子網路中的儲存位置僅有<ItemLink id="formation_plane" />，其會放置母巖。

### 主網路：

* <ItemLink id="storage_bus" />使得主網路（以及[充能器自動化](charger-automation.md)設施）能夠訪問木桶中的賽特斯石英水晶。其[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)較高，因此賽特斯石英水晶會優先進入木桶而非主網路儲存。
* <ItemLink id="interface" />使得放置器子網路能夠訪問1個<ItemLink id="flawed_budding_quartz" />，並使得賽特斯石英塊破壞器子網路能將枯竭的母巖傳輸回主網路。<ItemLink id="crafting_card" />則允許介面向主網路的[自動合成](../ae2-mechanics/autocrafting.md)系統傳送製造母巖的請求。
---
navigation:
  parent: example-setups/example-setups-index.md
  title: 充能器自動化
  icon: charger
---

# 充能器自動化

需注意，此設施使用了<ItemLink id="pattern_provider" />，也即需與你的[自動合成](../ae2-mechanics/autocrafting.md)設施配合使用。如需獨立自動化<ItemLink id="charger" />，則應使用漏斗，箱子等。

自動化<ItemLink id="charger" />相對簡單。<ItemLink id="pattern_provider" />將材料送入充能器，再由[管道子網路](pipe-subnet.md)或其他物品管道將產物送回供應器即可。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        （1）樣板供應器：預設配置，裝有相應樣板。同時提供能量。

        ![充能器樣板](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        （2）輸入匯流排：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        （3）儲存匯流排：預設配置。
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="pattern_provider" />（1）處於預設配置並裝有相應<ItemLink id="processing_pattern" />。其也同時為<ItemLink id="charger" />提供[能量](../ae2-mechanics/energy.md)，類似[線纜](../items-blocks-machines/cables.md)。
  
    ![充能器樣板](../assets/diagrams/charger_pattern.png)

* <ItemLink id="import_bus" />（2）處於預設配置。
* <ItemLink id="storage_bus" />（3）處於預設配置。

## 工作原理

1. <ItemLink id="pattern_provider" />將材料送入<ItemLink id="charger" />。
2. 充能器完成充能。
3. 綠色子網路上的<ItemLink id="import_bus" />將充能產物抽出並嘗試存入[網路儲存](../ae2-mechanics/import-export-storage.md)。
4. 綠色子網路上的儲存位置僅有<ItemLink id="storage_bus" />，其會將產物送入樣板供應器並返回至主網路。

---
navigation:
  parent: example-setups/example-setups-index.md
  title: 基於標準發信器的自動維持物品量
  icon: level_emitter
---

# 基於標準發信器的自動維持物品量

有人可能會問：“如何在庫存中維持一定數量的物品，並在缺少時自動補足？”

解決方案之一便是使用<ItemLink id="export_bus" />、<ItemLink id="level_emitter" />、<ItemLink id="crafting_card" />以自動向網路的[自動合成](../ae2-mechanics/autocrafting.md)系統傳送請求。這種設施更適用於維持大量單種物品。

也可以令網路持續合成，省略標準發信器和紅石卡即可。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        （1）輸出匯流排：設定為過濾所需物品。裝有紅石卡和合成卡。紅石模式設定為“有紅石訊號時啟用”，合成行為設定為“不使用已儲存物品”。
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        （2）標準發信器：配置為所需數量個所需物品，設定為“當數量小於設定數值時發出紅石訊號”。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        （3）介面：預設配置。
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="export_bus" />（1）設定為過濾所需物品。裝有<ItemLink id="redstone_card" />和<ItemLink id="crafting_card" />。“紅石模式”設定為“有紅石訊號時啟用”，“合成行為”設定為“不使用已儲存物品”。
* <ItemLink id="level_emitter" />（2）配置為所需數量個所需物品，並設定為“當數量小於設定數值時發出紅石訊號”。
* <ItemLink id="interface" />（3）處於預設配置。

## 工作原理

1. 若[網路儲存](../ae2-mechanics/import-export-storage.md)中所需物品的數量少於<ItemLink id="level_emitter" />中設定的值，則發信器會發出紅石訊號。
2. 在收到紅石訊號時，<ItemLink id="export_bus" />（裝有<ItemLink id="crafting_card" />並設定為不使用已儲存物品）會向網路的[自動合成](../ae2-mechanics/autocrafting.md)系統傳送合成該物品的請求，並輸出產物。
3. 在收到物品時，<ItemLink id="interface" />（未設定儲存任何事物）會將其送入網路儲存。
---
navigation:
  parent: example-setups/example-setups-index.md
  title: 簡單賽特斯石英農場
  icon: certus_quartz_crystal
  position: 110
---

# 簡單賽特斯石英農場

正如[賽特斯石英的生長](../ae2-mechanics/certus-growth.md)所提，<ItemLink id="certus_quartz_crystal" />的自動化採集需要<ItemLink id="annihilation_plane" />和<ItemLink id="storage_bus" />。<ItemLink id="growth_accelerator" />可用於大幅加速賽特斯石英芽的生長，之後由破壞面板破壞長成的<ItemLink id="quartz_cluster" />。不同的石英芽和石英簇能透過方便到故意的特性⸺未長成的賽特斯石英芽會掉落<ItemLink id="certus_quartz_dust" />而非什麼都不掉落⸺加以區分。

此農場可在<ItemLink id="flawless_budding_quartz" />上全自動執行，使用有瑕、開裂、損壞的賽特斯石英母巖則需要手動更換母巖。或者可用[半自動賽特斯石英農場](semiauto-certus-farm.md)和[進階賽特斯石英農場](advanced-certus-farm.md)中所提方法自動化。

生長速度估計值見[賽特斯石英的生長](../ae2-mechanics/certus-growth.md)。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        （1）破壞面板：無可用GUI，但可附有時運。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        （2）儲存匯流排#1：過濾賽特斯石英水晶。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        （3）儲存匯流排#2：過濾賽特斯石英水晶。優先順序高於主網路儲存。
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* 第一個<ItemLink id="annihilation_plane" />（1）沒有GUI且無法配置，但可附有時運。
* 第一個<ItemLink id="storage_bus" />（2）設定為過濾<ItemLink id="certus_quartz_crystal" />。
* 第二個<ItemLink id="storage_bus" />（3）設定為過濾<ItemLink id="certus_quartz_crystal" />，且[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)高於主網路儲存。

## 工作原理

1. <ItemLink id="annihilation_plane" />嘗試破壞其前方的事物，但由於子網路中儲存位置僅有過濾<ItemLink id="certus_quartz_crystal" />的<ItemLink id="storage_bus" />，其只會破壞<ItemLink id="quartz_cluster" />。
2. 第一個<ItemLink id="storage_bus" />將賽特斯石英水晶存入木桶。
3. 第二個<ItemLink id="storage_bus" />使得主網路能夠訪問木桶中賽特斯石英水晶。其[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)較高，因此賽特斯石英水晶會優先存入木桶而非主網路儲存。

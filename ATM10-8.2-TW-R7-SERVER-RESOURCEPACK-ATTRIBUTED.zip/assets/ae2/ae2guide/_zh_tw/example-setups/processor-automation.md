---
navigation:
  parent: example-setups/example-setups-index.md
  title: 處理器自動化
  icon: logic_processor
---

# 自動化生產處理器

自動化[處理器](../items-blocks-machines/processors.md)有多種方式，如下是其一。

此通用設計也可用任意種類的物流管道、導管、管道或其他不同稱呼的同類事物完成，僅要求這些管道能設定過濾。

![流程圖](../assets/diagrams/processor_flow_diagram.png)

如下則是僅使用AE2的實現細節，其中使用了[“管道”子網路](pipe-subnet.md)。

需注意，此設施使用了<ItemLink id="pattern_provider" />，也即需與你的[自動合成](../ae2-mechanics/autocrafting.md)設施配合使用。如需獨立自動化處理器，則應將樣板供應器換為木桶，並將材料直接放入上方的木桶中。

此設計也能在之前的AE2版本中使用，因為就算<ItemLink id="inscriber" />對面敏感，管道子網路仍能對正確的面輸入或輸出。

## 樣板編碼的教訓

通常情況下，所需的[樣板](../items-blocks-machines/patterns.md)和**JEI中所見的**，或是按下+按鈕時輸出的配方**對不上**。在本節的情況中，JEI會輸出2個樣板，其一是製造電路板，其二是最終的組裝步驟，且第一個樣板會包含一個[壓印模板](../items-blocks-machines/presses.md)。很明顯不是我們需要的，它不符合設施的功能。我們需要的是1個樣板，輸入原材料然後輸出壓印好的處理器。而壓印模板已經在壓印器中，樣板不應當包含它。

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        （1）樣板供應器：預設配置，裝有相關處理樣板。

        <Row>
            ![邏輯樣板](../assets/diagrams/logic_pattern_small.png)
            ![計算樣板](../assets/diagrams/calculation_pattern_small.png)
            ![工程樣板](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        （2）儲存匯流排#1：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        （3）輸出匯流排#1：過濾矽，裝有2張加速卡。
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        （4）輸出匯流排#2：過濾金錠，裝有2張加速卡。
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        （5）輸出匯流排#3：過濾賽特斯石英水晶，裝有2張加速卡。
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        （6）輸出匯流排#4：過濾鑽石，裝有2張加速卡。
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        （7）輸出匯流排#5：過濾紅石粉，裝有2張加速卡。
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        （8）壓印器#1：預設配置。裝有矽壓印模板和4張加速卡。
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        （9）壓印器#2：預設配置。裝有邏輯壓印模板和4張加速卡。
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        （10）壓印器#3：預設配置。裝有計算壓印模板和4張加速卡。
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        （11）壓印器#4：預設配置。裝有工程壓印模板和4張加速卡。
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        （12）壓印器#5：預設配置。裝有4張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        （13）輸入匯流排#1：預設配置，裝有2張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        （14）輸入匯流排#2：預設配置，裝有2張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        （15）輸入匯流排#3：預設配置，裝有2張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        （16）輸入匯流排#4：預設配置，裝有2張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        （17）儲存匯流排#2：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        （18）儲存匯流排#3：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        （19）輸入匯流排#5：預設配置，裝有2張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        （20）儲存匯流排#4：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        石英纖維能為全部3臺壓印器供能，壓印器與線纜功能類似，能夠傳輸能量。
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## 配置

* <ItemLink id="pattern_provider" />（1）處於預設配置，裝有相應<ItemLink id="processing_pattern" />。
  注意，此類樣板需直接從原材料加工為完整的處理器，且**不應**包含[壓印模板](../items-blocks-machines/presses.md)。

  ![邏輯樣板](../assets/diagrams/logic_pattern.png)
  ![計算樣板](../assets/diagrams/calculation_pattern.png)
  ![工程樣板](../assets/diagrams/engineering_pattern.png)

* <ItemLink id="storage_bus" />（2、17、18、20）處於預設配置。
* <ItemLink id="export_bus" />（3-7）設定為過濾相應材料。均裝有2張<ItemLink id="speed_card" />。
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* <ItemLink id="import_bus" />（13-16、19）處於預設配置。均裝有2張<ItemLink id="speed_card" />。
* <ItemLink id="inscriber" />處於預設配置。裝有相應[壓印模板](../items-blocks-machines/presses.md)和4張<ItemLink id="speed_card" />。
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## 工作原理

1. <ItemLink id="pattern_provider" />將材料存入木桶。
2. 第一個[管道子網路](pipe-subnet.md)（橙色）從木桶中抽取矽、紅石粉，以及相應壓印器的材料（金錠、賽特斯石英水晶、鑽石）並存入相應<ItemLink id="inscriber" />。
3. 前四個<ItemLink id="inscriber" />製造<ItemLink id="printed_silicon" />、<ItemLink id="printed_logic_processor" />、<ItemLink id="printed_calculation_processor" />、<ItemLink id="printed_engineering_processor" />。
4. 第二個和第三個[管道子網路](pipe-subnet.md)（綠色）將電路板和矽板從前四個<ItemLink id="inscriber" />中取出並放入第五個也是最終工序<ItemLink id="inscriber" />。
5. 第五個<ItemLink id="inscriber" />組裝[處理器](../items-blocks-machines/processors.md)。
6. 第四個[管道子網路](pipe-subnet.md)（紫色）將處理器送入樣板供應器，並返回至主網路。
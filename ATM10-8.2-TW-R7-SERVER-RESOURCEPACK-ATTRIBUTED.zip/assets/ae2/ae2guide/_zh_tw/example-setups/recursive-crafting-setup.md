---
navigation:
  parent: example-setups/example-setups-index.md
  title: 遞迴合成
  icon: minecraft:netherite_upgrade_smithing_template
---

# 遞迴合成設施

如[自動合成](../ae2-mechanics/autocrafting.md)中所說，自動合成規劃演算法無法處理首要輸出同時是輸入的配方。例如，它無法處理複製<ItemLink id="minecraft:netherite_upgrade_smithing_template" />的配方。

解決方案之一便是將<ItemLink id="level_emitter" />用作[樣板](../items-blocks-machines/patterns.md)。

此後，便可以運用該標準發信器，啟動一個持續合成的小設施即可。本節我們主要以複製<ItemLink id="minecraft:netherite_upgrade_smithing_template" />的設施為例。

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        （1）介面：設定為儲存所需的額外材料：鑽石和下界巖。
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        （2）標準發信器：配置為“下界合金升級鍛造模板”，設定為“發出紅石訊號以合成物品”。
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        （3）輸入匯流排#1：過濾介面所儲存的物品。裝有紅石卡。紅石模式設定為“有紅石訊號時啟用”。
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        （4）儲存匯流排#1：優先順序高於另一個儲存匯流排。非常重要。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        （5）分子裝配室：裝有複製鍛造模板的樣板。

        ![樣板](../assets/diagrams/smithing_template_pattern_small.png)

        搭建時需向其中手動放入一個鍛造模板。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        （6）輸入匯流排#2：預設配置。
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        （7）儲存匯流排#2：過濾“下界合金升級鍛造模板”。優先順序低於另一個儲存匯流排。
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="interface" />（1）設定為儲存所需的額外材料：鑽石和下界巖。
* <ItemLink id="level_emitter" />（2）配置為“下界合金升級鍛造模板”，設定為“發出紅石訊號以合成物品”。
* 第一個<ItemLink id="import_bus" />（3）設定為過濾介面所儲存的物品。裝有紅石卡。紅石模式設定為“有紅石訊號時啟用”。
* 第一個<ItemLink id="storage_bus" />（4）的[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)需*高於*第二個儲存匯流排。
* <ItemLink id="molecular_assembler" />（5）裝有複製鍛造模板的樣板，以及一個手動放入的鍛造模板。

  ![樣板](../assets/diagrams/smithing_template_pattern.png)

* 第二個<ItemLink id="import_bus" />（6）處於預設配置。
* 第二個<ItemLink id="storage_bus" />（7）設定為過濾“下界合金升級鍛造模板”。其[優先順序](../ae2-mechanics/import-export-storage.md#儲存優先順序)*低於*第一個儲存匯流排。

## 工作原理

1. 由於其裝有<ItemLink id="crafting_card" />且設定為“發出紅石訊號以合成物品”，<ItemLink id="level_emitter" />相當於一個[樣板](../items-blocks-machines/patterns.md)。“下界合金升級鍛造模板”會出現在[終端](../items-blocks-machines/terminals.md)中作為可[自動合成](../ae2-mechanics/autocrafting.md)物品。
2. 收到來自玩家或系統的合成請求時，標準發信器會開啟。
3. 第一個<ItemLink id="import_bus" />被標準發信器啟用，並從<ItemLink id="interface" />中抽出材料。
4. 網路中能儲存這些材料的<ItemLink id="storage_bus" />僅有裝配室上的。
5. <ItemLink id="molecular_assembler" />收到材料（其中已有1個鍛造模板），開始合成，產出2個鍛造模板。
6. 第二個<ItemLink id="import_bus" /> 抽出1個鍛造模板。
7. 第一個儲存匯流排的優先順序更高，因此鍛造模板會返回裝配室。
8. 第二個<ItemLink id="import_bus" /> 抽出1個鍛造模板。
9. 裝配室無法再接受鍛造模板，因此第二個鍛造模板會進入低優先順序儲存匯流排，並送入介面。
10. <ItemLink id="interface" />（未設定儲存鍛造模板）會將其送回網路。
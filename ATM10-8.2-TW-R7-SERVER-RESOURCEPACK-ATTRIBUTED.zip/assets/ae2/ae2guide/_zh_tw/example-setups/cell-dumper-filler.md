---
navigation:
  parent: example-setups/example-setups-index.md
  title: 元件清空器與裝填器
  icon: io_port
---

# 元件清空器與裝填器

有人可能會問：“怎麼迅速將元件清空至箱子或者抽屜陣列或者揹包，以及怎麼從這些地方填滿元件？”

答案便是使用<ItemLink id="io_port" />和限制其清空或裝填位置的子網路。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        （1）IO埠：可使用GUI中間的箭頭按鈕將其設定為“從元件匯入網路”或“傳輸資料到儲存元件中”。裝有3張加速卡。
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        （2）儲存匯流排：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        在這裡放置用於裝填或清空的事物。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        石英纖維：僅在能量供給來自另一網路時必需。
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        至能量源，例如另一網路和能源接收器。
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="io_port" />（1）可使用GUI中間的箭頭按鈕將其設定為“從元件匯入網路”或“傳輸資料到儲存元件中”。裝有3張加速卡以達到最大速度。
* <ItemLink id="storage_bus" />（2）處於預設配置。

## 工作原理

### “傳輸至網路”模式

1. <ItemLink id="io_port" />嘗試將其中[儲存元件](../items-blocks-machines/storage_cells.md)所存事物清空至[網路儲存](../ae2-mechanics/import-export-storage.md)。
2. 子網路中唯一儲存位置是<ItemLink id="storage_bus" />，可將物品，流體等事物存入放在其上的容器。
* <ItemLink id="energy_cell" />則提供了足夠大的[能量快取](../ae2-mechanics/energy.md)，以避免每遊戲刻傳輸率過高導致能量耗盡。

### “傳輸至元件”模式

1. <ItemLink id="io_port" />嘗試將[網路儲存](../ae2-mechanics/import-export-storage.md)所存事物裝填至其中[儲存元件](../items-blocks-machines/storage_cells.md)。
2. 子網路中唯一儲存位置是<ItemLink id="storage_bus" />, 可從放在其上的容器中抽出物品，流體等事物。
* <ItemLink id="energy_cell" />則提供了足夠大的[能量快取](../ae2-mechanics/energy.md)，以避免每遊戲刻傳輸率過高導致能量耗盡。
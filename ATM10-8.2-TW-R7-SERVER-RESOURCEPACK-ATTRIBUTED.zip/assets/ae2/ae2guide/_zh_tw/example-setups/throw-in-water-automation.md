---
navigation:
  parent: example-setups/example-setups-index.md
  title: 投水自動化
  icon: fluix_crystal
---

# 自動化投水配方

需注意，此設施使用了<ItemLink id="pattern_provider" />，也即需與你的[自動合成](../ae2-mechanics/autocrafting.md)設施配合使用。

某些配方可能要求將物品投入水中（不過同種設施也可用於處理其他物品投入某處的要求）。可用<ItemLink id="formation_plane" />、<ItemLink id="annihilation_plane" />，以及輔助基礎設施（也即2個經調整的[管道子網路](pipe-subnet.md)）自動化這類配方。

此設施應與[充能器自動化](charger-automation.md)配合使用以生產<ItemLink id="charged_certus_quartz_crystal" />。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        （1）樣板供應器：預設配置，裝有相應處理樣板。

        ![福魯伊克斯樣板](../assets/diagrams/fluix_pattern_small.png) ![有瑕母巖樣板](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        （2）介面：預設配置。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        （3）成型面板：設定為以物品形式掉落。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        （4）破壞面板：無可用GUI。
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        （5）儲存匯流排：過濾樣板輸出。
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        至主網路或充能器自動化設施
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## 配置與樣板

* <ItemLink id="pattern_provider" />（1）處於預設配置，裝有相關<ItemLink id="processing_pattern" />。
  * 對於<ItemLink id="fluix_crystal" />，JEI/REI的預設配方就可以了：

    ![福魯伊克斯樣板](../assets/diagrams/fluix_pattern.png)

  * 對於<ItemLink id="flawed_budding_quartz" />，直接用<ItemLink id="quartz_block" />製造更佳，否則輸入輸出的物品可能重疊，不利於配置過濾：

    ![有瑕母巖樣板](../assets/diagrams/flawed_budding_pattern.png)

* <ItemLink id="interface" />（2）處於預設配置。
* <ItemLink id="formation_plane" />（3）設定為以物品形式掉落。
* <ItemLink id="annihilation_plane" />（4）沒有GUI且無法配置。
* <ItemLink id="storage_bus" />（5）設定為過濾樣板產物。

## 工作原理

1.  <ItemLink id="pattern_provider" />將材料送入相鄰的<ItemLink id="interface" />（位於綠色子網路）。
2.  介面（預設設定為不儲存任何物品）嘗試將其中事物送入[網路儲存](../ae2-mechanics/import-export-storage.md)。
3.  綠色子網路上的儲存位置僅有<ItemLink id="formation_plane" />，其會將接收到的物品投入水中。
4.  橙色子網路上的<ItemLink id="annihilation_plane" />會嘗試撿起剛投入的物品，但由於樣板供應器上的<ItemLink id="storage_bus" />（也即橙色子網路唯一的儲存位置）設定為過濾合成產物，該面板不會撿起配方材料。
5.  物品在世界中發生變化。
6.  由於儲存匯流排可以儲存產物，破壞面板此時能撿起其前方的物品。
7.  儲存匯流排將產物存入樣板供應器，並返回至主網路。

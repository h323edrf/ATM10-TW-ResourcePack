---
navigation:
  parent: example-setups/example-setups-index.md
  title: 基於介面的自動維持物品量
  icon: interface
---

# 基於介面的自動維持物品量

有人可能會問：“如何在庫存中維持一定數量的物品，並在缺少時自動補足？”

解決方案之一便是使用裝有<ItemLink id="crafting_card" />的<ItemLink id="interface" />以自動向網路的[自動合成](../ae2-mechanics/autocrafting.md)系統傳送請求。這種設施更適用於維持少量多種物品。

此演示設施經過截短以便於縮減寬度，使用4個<ItemLink id="interface" />和4個<ItemLink id="storage_bus" />應當最為高效，可完全佔用普通[線纜](../items-blocks-machines/cables.md)的所有8個[頻道](../ae2-mechanics/channels.md)。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        （1）介面：設定為在自身處儲存所需物品。裝有合成卡。
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        （2）儲存匯流排：“輸入/輸出模式”設定為“僅取出”。
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        至主網路
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 配置

* <ItemLink id="interface" />（1）設定為在自身處儲存所需物品，將物品直接放入或從JEI中拖拽入上排槽位，然後點選槽位上方扳手圖示以設定數量。裝有<ItemLink id="crafting_card" />。
* <ItemLink id="storage_bus" />（2）的“輸入/輸出模式”設定為“僅取出”。

## 工作原理

1. 若<ItemLink id="interface" />無法從[網路儲存](../ae2-mechanics/import-export-storage.md)中獲得足量所配置的物品（且其裝有<ItemLink id="crafting_card" />），則其會向網路的[自動合成](../ae2-mechanics/autocrafting.md)系統傳送合成該物品的請求。
2. <ItemLink id="storage_bus" />允許網路訪問介面的內容物。
---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 賽特斯石英的生長
  icon: quartz_cluster
---

# 賽特斯石英的生長

## 基本就是從開始與入門那裡複製來的

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

賽特斯石英芽會從[賽特斯石英母巖](../items-blocks-machines/budding_certus.md)中生長出來，與紫水晶類似。如果破壞未完全生長的石英芽，則會掉落一個<ItemLink id="certus_quartz_dust" />，不受時運影響。如果破壞長成的石英簇，則會掉落四個<ItemLink id="certus_quartz_crystal" />，且會受時運影響而增加掉落量。

共有4種等級的賽特斯石英母巖：無瑕、有瑕、開裂、損壞。可在[隕石](meteorites.md)裡找到它們。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

每次石英芽生長時，母巖都有可能降一級，並最終變為普通的賽特斯石英塊。將賽特斯石英母巖或者賽特斯石英塊以及若干個<ItemLink id="charged_certus_quartz_crystal" />一起投入水中，就能進行修復併產生新的母巖。

<RecipeFor id="damaged_budding_quartz" />

無瑕的賽特斯石英母巖不會降級，因而能無限產生賽特斯石英。但是它們無法合成，也無法被鎬完好地挖下搬運，就算有精準採集也不行。（不過它們*可以*被[空間儲存](spatial-io.md)移動。）

賽特斯石英母巖自身的生長非常緩慢。幸運的是，在母巖旁放置<ItemLink id="growth_accelerator" />能大幅加速這一過程。你的第一要務便是製造一些此方塊。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

不過，單個面只能在催生晶體和採集晶體間二選一。因而，晶體催生器每覆蓋母巖一面，可供晶芽生長的位置就會減少，並最終抵消催生器提升的效率。實際檢驗資料如下：

![不同面配置的每分鐘物品產量](../assets/diagrams/certus_farm_speed_chart_1.png)

![常用面配置](../assets/diagrams/certus_farm_speed_chart_2.png)

假如沒有足夠石英制造<ItemLink id="energy_acceptor" />或是<ItemLink id="vibration_chamber" />，可以製造一個<ItemLink id="crank" />並安到催生器上。

自動採集賽特斯石英的設計[見此](../example-setups/simple-certus-farm.md)。
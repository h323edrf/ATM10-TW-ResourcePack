---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 線纜子部件
icon: fluix_glass_cable
---

# 線纜子部件

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

AE2中的某些[裝置](devices.md)和元件可與線纜放置在同一格內⸺對設計緊湊設施大有裨益。手持<ItemLink id="certus_quartz_wrench" />或<ItemLink id="network_tool" />潛行右擊可破壞子部件（或線纜）而不影響同一格內其他事物。

---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 頻道
  icon: controller
---

# 頻道

應用能源 2的[ME網路](me-network-connections.md)需要頻道才可支援使用網路儲存功能或其他網路服務的[裝置](devices.md)。可把頻道看作連線所有裝置的USB線纜。單臺電腦只有有限數量的USB埠，由此只能支援有限數量的裝置與其連線。大部分機器、方塊形態的裝置、標準線纜最多隻能傳輸8個頻道。上述裝置與線纜都可看作一束“8頻道導線”。[緻密線纜](../items-blocks-machines/cables.md#緻密線纜)可支援最多32個頻道。其他能傳輸32個頻道的裝置有<ItemLink id="me_p2p_tunnel" />和[量子網橋](../items-blocks-machines/quantum_bridge.md)。裝置佔用頻道可類比為從USB“導線”束中抽出一條使用，也即該“導線”線上束下游不再可用。

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
    線纜中所有8個頻道都已被佔用，因此驅動器未獲得頻道。
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
    線纜中所有8個頻道都已被佔用，因此驅動器未獲得頻道。
  </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

檢影片道佔用和尋路情況的好方法便是使用[智慧線纜](../items-blocks-machines/cables.md)，它們會直接顯示這些資訊。

頻道每傳輸一個節點消耗1/128 AE/t。也即，向一個帶有8臺裝置和96個節點的網路加入<ItemLink id="controller" />實際能減少能量消耗，因為頻道的分配方式改變了。

需要注意，**頻道和線纜顏色沒有關係**，線纜顏色只能阻止線纜連線。

## 頻道尋路

在使用<ItemLink id="controller" />時，頻道的尋路分為3步。第一步，沿經過相鄰機器的最短路徑抵達最近的[普通線纜](../items-blocks-machines/cables.md)（玻璃、包層、智慧）。第二步，沿經過該普通線纜的最短路徑抵達最近的[緻密線纜](../items-blocks-machines/cables.md)（緻密、緻密包層）。第三步，沿經過該緻密線纜的最短路徑抵達<ItemLink id="controller" />。如果最短路徑已被完全佔用，某些[裝置](devices.md)可能無法正常獲取頻道，可用染色線纜、線纜錨、P2P通道等確保頻道的尋路符合預期。

例如，在下述示例中某些驅動器因線纜容量不足而無法獲取頻道，頻道會嘗試沿最短路徑行進，從而導致某些線纜過載而其他線纜留空。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
    試圖在此處傳輸多於8個頻道，因此某些頻道路徑被截斷。
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

這一問題可由限制頻道路徑解決。網路的形態應當是樹形（或灌木型）。應當避免出現環形和不明確路徑。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## 自組織網路

不帶<ItemLink id="controller" />的網路是自組織網路，最多能支援8臺佔用頻道的裝置。如果佔用頻道的裝置超過8臺，則網路會失效，可移除裝置或加入<ItemLink id="controller" />以解決。

和帶有控制器的網路不同的是，自組織網路中的[智慧線纜](../items-blocks-machines/cables.md)會顯示整個網路的頻道佔用數，而非途徑該段線纜的頻道數。

自組織網路中的每臺裝置會佔用整個網路中的1個頻道，和<ItemLink id="controller" />沿最短路徑分配頻道的行為非常不同。

## 設計

正如前文[頻道尋路](channels.md#頻道尋路)中所提，推薦將網路設計為樹形結構：從控制器處引出緻密線纜，緻密線纜處引出普通線纜，在普通線纜上最多連線8臺[裝置](devices.md)。

如下是一個反面示例：

沿頻道路徑來看，

1. 自控制器出發後，首先遇到的驅動器和普通線纜表現相同，因此將頻道上限鎖在了8個。
不過此處沒有使用智慧線纜，無法檢視具體使用了多少頻道。剩餘8個頻道。
2. 驅動器佔用1個頻道。
剩餘7個頻道。
3. 終端佔用2個頻道。
剩餘5個頻道。
4. 右側的介面占用1個頻道。
剩餘4個頻道。
5. 樣板供應器佔用1個頻道。
剩餘3個頻道。
6. 右側的輸入匯流排佔用1個頻道。
剩餘2個頻道。
7. 用於供應裝配室的樣板供應器組只能拿到2個頻道，其餘2個則缺少頻道。

總體看來，問題主要出在鎖死頻道數上限和未考慮頻道分配方式上。

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1個頻道
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  無頻道
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  無頻道
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

再給出一個正面示例：

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
      需注意樣板供應器為8個一組。
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
      兩條頻道佔用滿的普通線纜連線處需用緻密線纜。
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
      線纜顏色的不同可避免相鄰的線纜相互連線。
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## 頻道模式

Minecraft 1.18版本的AE2 10.0.0引入了改變AE2頻道行為的新選項。在設定檔通用部分有新選項（`channels`）可供控制，管理員也可使用遊戲內命令直接在遊戲中更改模式。更改命令為`/ae2 channelmode <模式>`，顯示當前模式命令為`/ae2 channelmode`。如果是在遊戲中進行的模式更改，則所有網路都會重置並立即改用新模式。

相當於重新引入了Minecraft 1.12中的選項，並加以改進；對於想要遊戲體驗稍微輕鬆些，但又不希望完全移除頻道機制的玩家而言，算是更好的選擇。

設定檔和命令中可用模式列表如下。

| 設定       | 描述                                                                                                                           |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------ |
| `default`  | 此指南描述的線纜與自組織網路標準頻道容量                                                                                       |
| `x2`       | 所有頻道容量變為雙倍（普通線纜16個，緻密線纜64個，自組織網路16個）                                                             |
| `x3`       | 所有頻道容量變為三倍（普通線纜24個，緻密線纜96個，自組織網路24個）                                                             |
| `x4`       | 所有頻道容量變為四倍（普通線纜32個，緻密線纜128個，自組織網路32個）                                                            |
| `infinite` | 移除所有頻道限制。控制器仍能*大幅*減少能量消耗。此時，智慧線纜只有完全關閉（不傳輸頻道）和完全開啟（傳輸若干頻道）這兩個狀態。 |
---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 量子橋
  icon: quantum_ring
---

# 量子網橋

見[量子網橋](../items-blocks-machines/quantum_bridge.md)。
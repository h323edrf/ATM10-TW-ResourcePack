---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 網路連線
  icon: fluix_glass_cable
---

# 網路連線

## “網路”是什麼意思？

“網路”是有頻道連線的一組[裝置](devices.md)（<ItemLink id="charger" />、<ItemLink id="interface" />、<ItemLink id="drive" />等）。這些裝置之間透過[線纜](../items-blocks-machines/cables.md)或方塊形態的機器和[裝置](devices.md)傳輸[頻道](channels.md)。單個線纜理論上也算是一個網路。

## 裝置位置簡述

對於有特殊網路功能的[裝置](devices.md)（例如向[網路儲存](import-export-storage.md)輸入輸出的<ItemLink id="interface" />，讀取網路儲存資訊的<ItemLink id="level_emitter" />，作為網路儲存的<ItemLink id="drive" />等）來說，裝置本身的物理位置不重要。

再提一遍，**裝置的物理位置不重要**。重要之處在於裝置連上了網路（以及連上了哪個網路）。

## 網路連線

可透過<ItemLink id="network_tool" />輕鬆檢測網路中連線的事物。它會顯示網路中的每個元件，如果看到不應該出現或者沒看到本應該出現的東西，那就是碰上問題了。

例如，如下是2個獨立的網路。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        網路1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        網路2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

如下也是2個獨立的網路，因為<ItemLink id="quartz_fiber" />只傳輸[能量](energy.md)而不提供網路連線。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        網路1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        網路2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

而如下則只有1個網路（不是2個）。[量子橋](../items-blocks-machines/quantum_bridge.md)類似無線的[緻密線纜](../items-blocks-machines/cables.md#緻密線纜)，因此其兩端處於同一網路。

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        只有1個網路
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

如下也只有1個網路，因為[線纜](../items-blocks-machines/cables.md)顏色與網路連線無關而只會阻止不同色線纜連線。所有顏色的線纜都會與福魯伊克斯色（或“未上色”）的線纜連線。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        只有1個網路
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 子網路中的連線

[子網路](subnetworks.md)透過控制網路連線（主要是**禁止**連線）來限制[裝置](devices.md)對其他裝置的訪問權。

子網路本質上就是一個獨立的網路。

以[自動時運礦石機](../example-setups/ore-fortuner.md)為例。此設施內有3個獨立網路，且均用於完成特定任務。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        網路1，相當於一個管道子網路，限制了輸入匯流排的訪問範圍，使其只能透過成型面板“儲存”礦石方塊。
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        網路2，相當於另一個管道子網路，限制了破壞面板的訪問範圍，使其只會將時運所得的礦石小塊存入木桶，而非存入子網路。這也說明它不會佔用主網路中的頻道。
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        網路3，包含所有儲存和物品的主網路。此處僅作能源，並且*未*與前兩個子網路相連線。
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## P2P通道中的連線

有一種[P2P通道](../items-blocks-machines/p2p_tunnels.md)傳遞的不是物品、流體、紅石訊號，而是[頻道](channels.md)，有些人也因此不能理解它們。P2P通道所處於的網路和其所傳遞的網路之間沒有任何聯絡。當然這兩個網路*可以*是同一個，但一般不會這麼做。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        網路1，所傳遞的網路（通常是主網路）
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        網路2，P2P通道所處的網路（通常*不*是主網路）
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        網路1，所傳遞的網路（通常是主網路）
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 相對不直觀的連線

這種情況下只有1個網路，因為方塊形態的<ItemLink id="pattern_provider" />和線纜功能類似，<ItemLink id="inscriber" />也是一樣。正因此，網路連線能跨供應器和壓印器傳輸。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        只有1個網路
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

為避免這種情況出現（在與[子網路](subnetworks.md)相關的自動化設施中相當有用），可手持<ItemLink id="certus_quartz_wrench" />右擊供應器以將其變為方向型，它便不會在選中面傳輸頻道。

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        網路1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        網路2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        需注意線纜並未連線
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

其他不提供方向型網路連線的大多是[子部件](cable-subparts.md)[裝置](devices.md)，例如<ItemLink id="import_bus" />、<ItemLink id="storage_bus" />、<ItemLink id="cable_interface" />。

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
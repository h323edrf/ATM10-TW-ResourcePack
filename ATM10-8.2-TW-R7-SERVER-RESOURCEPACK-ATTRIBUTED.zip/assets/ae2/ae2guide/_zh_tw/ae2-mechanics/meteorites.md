---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 隕石
  icon: sky_stone_block
---

# 隕石

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

隕石是AE2的起點。它們能提供某些關鍵材料：各類[賽特斯石英母巖](../items-blocks-machines/budding_certus.md)，以及中央的<ItemLink id="mysterious_cube" />。

[開始與入門](../getting-started.md)詳述了找到隕石後要做的事。

## 尋找隕石

隕石通常會在地形上留下巨大的坑洞，所以你可能已經找到幾個了。如果還沒有遇到過，<ItemLink id="meteorite_compass" />會指向最近的神秘方塊。

![隕石撞擊坑](../assets/assemblies/meteorite-crater.png)
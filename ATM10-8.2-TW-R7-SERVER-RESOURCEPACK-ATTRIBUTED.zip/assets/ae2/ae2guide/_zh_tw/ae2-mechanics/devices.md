---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 裝置
  icon: interface
---

# 裝置

“裝置”一詞指AE2網路中執行與網路自身相關功能的元件。它們基本都需要佔用頻道，[標準發信器](../items-blocks-machines/level_emitter.md)除外。

以下是一些例子：

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />

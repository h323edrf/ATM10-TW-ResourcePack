---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 能量
  icon: energy_cell
---

# 能量

網路需要能量才能運作。網路中有一個能量庫，[裝置](devices.md)能直接從中獲取能量，<ItemLink id="vibration_chamber" />、<ItemLink id="energy_acceptor" />（和<ItemLink id="controller" />）則能向其中輸入能量。手持<ItemLink id="network_tool" />右擊網路任意一處或右擊網路的控制器即可檢視能量統計。這種以網路為範圍的儲存和分佈意味著能量傳輸速度沒有上限：裝置可以消耗任意多的能量，能源接收器能以近乎無限的速度接收能量，唯一的限制是能量儲存的容量。

## 接收能量

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />

  <BlockImage id="crystal_resonance_generator" scale="4" />
</Row>

AE2內部並不使用Forge Energy（Forge端）或是TechReborn Energy（Fabric端），而是將它們轉換為自帶的單位⸺AE。這種轉換是單向的。能量轉換可經由<ItemLink id="energy_acceptor" />和<ItemLink id="controller" />進行，不過控制器各面用於提供[頻道](channels.md)更佳。也可用<ItemLink id="vibration_chamber" />和<ItemLink id="crystal_resonance_generator" />生產能量，但是AE2還是與有更強產能能力的科技模組協同工作效果更好。

或者說，在鋪設基地能源基礎設施時，更推薦將AE2網路看做一整個多方塊結構。

Forge Energy與Techreborn Energy的轉換比為：

*   2 FE = 1 AE（Forge）
*   1 E  = 2 AE（Fabric）

## 能量儲存

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

由於一些顯而易見的原因，網路無法在單遊戲刻內消耗或接收超過其能量容量的能量。如果一個網路只能儲存800AE，則在每遊戲刻內，其各[裝置](devices.md)無法使用超過800AE的能量（即便能量已滿），能源接收器也無法接收超過800AE的能量（即便能量為空）。

這也解釋了網路的一些奇怪行為。例如，有人搭建了一個只有能源接收器、驅動器、終端，和某些裝置的小型網路，然後往裡放進一整個物品欄的圓石。在單個遊戲刻內同時放入所有圓石所需要的能量超過了網路能量容量，因此只能存入一部分圓石，網路也會耗盡能量並重啟。

**可以加入能源元件以解決上述問題。**

網路中每個線纜、裝置、部件均自帶25AE的能量快取。

<ItemLink id="controller" />有少量能量快取：8,000 AE。

<ItemLink id="energy_cell" />可儲存200kAE，能輕鬆應對普通網路的能量尖峰；通常，每個網路中放一個就夠了。

<ItemLink id="dense_energy_cell" />可儲存1.6MAE，適用於脫離能量供應執行網路的情況和處理大型[空間儲存](spatial-io.md)的巨量瞬時能量消耗。

<ItemLink id="creative_energy_cell" />是用於測試的創造模式物品，能提供無！限！能！量！

---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 空間IO
  icon: spatial_storage_cell_2
---

# 空間IO

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        會被移動的區域
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

空間IO是剪下與貼上世界中某一區域的方式。可用其移動<ItemLink id="flawless_budding_quartz" />，或是在基地中造出可更改內設的多功能房間，甚至還能搬動末地傳送門！

其工作方式是將所定義的區域與封閉空間維度內同等尺寸區域進行*交換*，將空間塔陣列中的所有事物送入封閉空間，並將封閉空間中的事物送入空間塔陣列。

如果你有維度間旅行方式的話（空間IO*可*用於製造傳送裝置，但會相當複雜，不算好用，也超出了指南的討論範圍），就可將空間IO用作尺寸可調的壓縮空間或是口袋維度。

# 多方塊設施

空間IO需要將其元件以特定方式排列才能正常工作和定義需剪下貼上的區域。

所有元件需處於同一[網路](me-network-connections.md)才可正常工作，且同一網路中只能存在一個空間IO設施。因此推薦使用[子網路](subnetworks.md)。

## 空間IO埠

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

<ItemLink id="spatial_io_port" />控制空間IO的運作。它能顯示多方塊設施的資料，也是放置[空間元件](../items-blocks-machines/spatial_cells.md)的地方。

其能顯示：
- 網路中已儲存的[能量](energy.md)和能量容量上限
- 執行操作所需的能量；可能會很大且會瞬時消耗，需確保有足夠的[能源元件](../items-blocks-machines/energy_cells.md)
- 空間塔陣列的效率
- 所定義區域的尺寸

執行空間IO操作需要在其中放入空間儲存元件並給予空間IO埠紅石脈衝。之後便會*交換*空間塔內和封閉空間內的區域。也即如果將某些方塊存入封閉空間，*然後在空間塔內放入另外一些方塊*，再把元件放入輸入槽，然後再次觸發空間IO埠，此時第二組方塊會消失，而第一組則會重新出現。

**需萬分注意，所定義區域中的任何實體，包括你，都會一起被搬走。如果沒有出來的方式，就相當於被禁錮在封閉空間維度，困在一個毫無特點的漆黑盒子裡。**&zwnj;用這個去整蠱朋友吧！

## 空間塔

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

<ItemLink id="spatial_pylon" />是空間IO設施的主要部分，定義了會被影響的區域的尺寸。

所有空間塔的外接長方體在所有方向中收縮1格所得區域即為所定義區域。

需遵循如下規則：
- 外接長方體至少為3x3x3（也即定義1x1x1的區域）
- 所有空間塔需在外接長方體內部
- 所有空間塔需處於同一網路
- 所有空間塔需至少2格長

例如，如果要定義3x3x3的區域，則根據規則2，所有空間塔應放在需定義區域周圍5x5x5的長方體殼層內。這是唯一要求⸺只要滿足此要求，可以任意放置空間塔。

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        會被移動的區域
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

更合理的設施見下：

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        會被移動的區域
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## 效率

空間塔陣列的效率由外殼填充量決定。用簡單的設施定義大體積相當低效，還可能消耗*數以億計*的AE。

## 元件維度

[空間元件](../items-blocks-machines/spatial_cells.md)在使用後會與某固定的尺寸設定（如3x4x2）和封閉空間維度內某部分割槽域繫結。&zwnj;**空間元件使用後便無法重置，無法重新格式化，無法重設尺寸。**&zwnj;如果需要更改所定義區域尺寸，應新制作元件。

這些尺寸和元件名稱中指明的尺寸不同，16³空間元件指的是能儲存*最大*16x16x16的區域。

需注意此區域是方向敏感且不可旋轉的。儘管2x2x3區域和3x2x2區域大小相等，兩者仍視作不相同。

如果元件的區域設定與空間塔定義的區域不符（見空間IO埠段落），則埠不會運作。
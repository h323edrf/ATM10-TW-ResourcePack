---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 自動合成
  icon: pattern_provider
---

# 自動合成

### 來個大的

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

自動合成是AE2的基礎功能之一。不需再像某些*庸人*一樣疲於手工合成正確數量的子材料，你可以讓ME系統為你合成。或是自動合成並輸出到其他地方。還可透過智慧的<a title="譯註：湧現（Emergence），指多個個體間的相互作用遵循簡單的規則，而它們所組成的系統擁有了個體不具備的特性，這種特性僅存在於系統的層面。">湧現</a>行為在庫存中自動維持一定數量的物品。它對流體也有效；假如安裝有某些相容更多材料型別的附屬，如通用機械（Mekanism）的化學品，則也對那些型別有效。確實非常不錯。

這個話題相當複雜，所以閒話少說，馬上開始學習吧。

自動合成設施由3部分組成：
- 傳送合成請求的事物
- 合成CPU
- <ItemLink id="pattern_provider" />

具體過程如下：

1.  某物發出一份合成請求。可以是你在終端中點選某些可自動合成的事物，也可以是裝有合成卡的輸出匯流排或介面請求其設定輸出或儲存的物品。

*   （&zwnj;**重要：**&zwnj;使用繫結在“選取方塊”（通常是滑鼠中鍵）的按鍵以請求合成庫存中已有的事物，可能與物品欄整理模組衝突）

2.  ME系統計算請求所需的材料和前置合成步驟，並將材料儲存在所選合成CPU中。

3.  裝有相關[樣板](../items-blocks-machines/patterns.md)的<ItemLink id="pattern_provider" />將樣板中需求的材料輸出至任意相鄰容器。
    如果是工作臺配方（“合成配方”），輸出目標是<ItemLink id="molecular_assembler" />。
    如果不是工作臺配方（“處理配方”），輸出目標是其他方塊、機器，或是複雜的紅石控制設施。

4.  所得產物透過某種方式送回系統，可以透過輸入匯流排、介面、樣板供應器等。
    **注意，必須發生一次“物品輸入系統”事件，不能只將產物輸入接有<ItemLink id="storage_bus" />的箱子。**

5.  如果該合成過程是請求內另一合成過程的前置，則產物會存入該CPU供後續使用。

## 遞迴配方

<ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="4" />

自動合成演算法*無法*處理的事情之一是遞迴配方。例如，將紅石投入植物魔法（Botania）魔力池所致的、類似“1x 紅石粉 = 2x 紅石粉”的複製配方。又例如原版的鍛造模板。不過，確實[有方法處理這些配方](../example-setups/recursive-crafting-setup.md)。

# 樣板

<ItemImage id="crafting_pattern" scale="4" />

樣板可在<ItemLink id="pattern_encoding_terminal" />中以空白樣板製作而得。

有若干種不同的樣板，分別為不同處理方式設計：

*   <ItemLink id="crafting_pattern" />能編碼工作臺的配方。可將此類樣板直接放入<ItemLink id="molecular_assembler" />以令其在收到材料時自動合成，但它們的主要用途是放在與分子裝配室相鄰的<ItemLink id="pattern_provider" />中。樣板供應器在此情況下有特殊行為，會將相關樣板和材料輸入相鄰裝配室。因為裝配室會將產物自動彈出到相鄰容器，相鄰放置的裝配室和樣板供應器就是自動化合成樣板所需的一切了。

***

*   <ItemLink id="smithing_table_pattern" />與合成樣板非常相似，但編碼的是鍛造臺配方。它們也可透過樣板供應器和分子裝配室自動化，工作流程也完全一致。實際上，合成、鍛造臺、切石機樣板所需的設施均完全一致。

***

*   <ItemLink id="stonecutting_pattern" />與合成樣板非常相似，但編碼的是切石機配方。它們也可透過樣板供應器和分子裝配室自動化，工作流程也完全一致。實際上，合成、鍛造臺、切石機樣板所需的設施均完全一致。

***

*   <ItemLink id="processing_pattern" />則是自動合成的靈活性所在。它們是最通用的樣板型別，簡單來說，“如果樣板供應器將這些材料輸出到相鄰容器，則ME系統會在未來某時間點收到這些物品”。它們是配合幾乎所有其他模組機器（或者說熔爐類的機器）自動合成的方式。原因在於它們非常通用，且完全不關心輸出材料和輸入產物間發生了什麼。你大可做些古怪透頂的事，比如將材料輸入一整條複雜工廠產線進行分揀，再從無限生產的農場中運出其他材料，列印出一整篇《蜜蜂總動員》的劇本；只要ME系統能拿到樣板指明的產物，它就完全不會關心這些。實際上，它甚至不會關心材料和產物之間有沒有聯絡。你可以告訴系統“1x 櫻花木板 = 1x 下界之星”，然後讓凋靈農場每接收到一個櫻花木板時殺一隻凋靈即可，完全不會出任何問題。

多個擁有相同樣板的<ItemLink id="pattern_provider" />會並行工作；並且，還可以設定諸如“8x 圓石 = 8x 石頭”的配方，而非“1x 圓石 = 1x 石頭”：樣板供應器每次執行都會向燒煉設施輸入8個圓石而非每次1個。

## 最為通用的“樣板”

還有一種比處理樣板更為“通用”的“樣板”種類。裝有合成卡的<ItemLink id="level_emitter" />可設定為發出紅石訊號以合成物品。這種“樣板”不會定義也不會關心合成材料。換言之，“如果在此標準發信器發出紅石訊號，則ME系統會在未來某時間點收到這些物品”。其通常用於啟用或禁用不需要輸入材料的無限農場，或是啟用處理遞迴配方（標準自動合成無法處理）的系統，例如“1x 圓石 = 2x 圓石”，如果有一臺能複製圓石的機器的話。

# 合成CPU

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

合成CPU管理合成請求與合成任務。它們會在執行多步驟合成任務時將中間產物存於自身，並影響合成任務的大小上限，某種程度上也會影響這些任務的完成速度。它們是多方塊結構，必須是長方體，且必須包含至少1個合成儲存器。

合成CPU的構成如下：

*   （必需）[合成儲存器](../items-blocks-machines/crafting_cpu_multiblock.md)，支援所有標準元件大小（1k、4k、16k、64k、256k）；它們會將與合成相關的材料和中間材料存於自身，因此處理所需材料更多的合成任務需要更大的或更多個合成儲存器
*   （可選）<ItemLink id="crafting_accelerator" />，它們能讓系統從單個樣板供應器更迅速地傳送材料批次；比如說，可以讓樣板供應器同時將材料送至相鄰的六個裝配室，而非一次一個
*   （可選）<ItemLink id="crafting_monitor" />，它們會顯示CPU當前正在處理的任務；可用<ItemLink id="color_applicator" />染色
*   （可選）<ItemLink id="crafting_unit" />，它們僅用於填上空隙，以使得CPU的形狀為長方體

每個合成CPU能處理1個合成請求或任務，因此如果需要同時合成運算處理器和256個平滑石頭，就需要有2個CPU多方塊結構。

它們可設定為僅接受玩家請求、僅接受自動化系統（輸出匯流排與介面）請求，或兩者均接受。

# 樣板供應器

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

<ItemLink id="pattern_provider" />是自動合成系統與世界互動的基礎方式。它們會將[樣板](../items-blocks-machines/patterns.md)指明的材料輸出至相鄰容器，並且也可向其輸入物品以輸入網路。通常可將機器的產物傳輸給附近的樣板供應器（一般就是輸出材料的那個）以節省頻道，而非讓<ItemLink id="import_bus" />提取產物。

需要注意，它們會直接從合成CPU中的[合成儲存器](../items-blocks-machines/crafting_cpu_multiblock.md#合成儲存器)中輸出物品；因此，模板供應器本身並不儲存物品，也就不能直接從此抽取物品：需要將物品輸出至另一個容器（比如木桶），再從那裡抽取才行。

此外，供應器會同時輸出整份材料，不會輸出半份。這一特性非常有用。

樣板供應器和介面有一特殊互動效果⸺[子網路](subnetworks.md)：如果介面未經修改（請求槽內無內容），則供應器會跳過介面，直接輸出到該子網路的[儲存模組](import-export-storage.md)，而非輸出到介面的儲存槽；更重要的是，只要對應的儲存模組沒有足夠的空間，下一批物品就不會輸出。

允許存在多個擁有相同樣板的樣板供應器，它們會並行工作。

樣板供應器會嘗試在其所有面輪詢材料批次，從而並行使用所有相鄰的機器。

## 變種

樣板供應器有3種變種：普通、方向、面板。形態會影響各面輸出材料，接收物品，提供網路連線的能力。

*   普通型樣板供應器會向各面輸出材料，會從各面接收物品，且和大多數AE2機器一樣向各面提供網路連線，類似線纜。

*   方向型樣板供應器可透過對普通樣板供應器使用<ItemLink id="certus_quartz_wrench" />產生。它們只會向選中面輸出材料，會從各面接收物品，並且僅不向選中面提供網路連線。這使得它們能向AE2機器輸出物品而不連線網路，在構建子網路上非常有用。

*   面板型樣板供應器是[線纜子部件](cable-subparts.md)，因此可在同一線纜上放置多個該種供應器，便於設計緊湊設施。它們和方向型供應器選中面功能類似：輸出樣板材料，接收物品，且不提供網路連線。

樣板供應器的普通和麵板形態可在合成方格中轉換。

## 設定

樣板供應器有多種模式：

*   **阻擋模式**能在機器中已有材料時阻止供應器輸出新批次
*   **鎖定合成**能在多種紅石訊號狀況下鎖定供應器，也可在前一批材料的合成產物未返回該供應器前將其鎖定
*   供應器可在<ItemLink id="pattern_access_terminal" />上顯示或隱藏

## 優先順序

可點選GUI右上角扳手以設定優先順序。有多個[樣板](../items-blocks-machines/patterns.md)對應同一物品時，在高優先順序供應器中的樣板會先於低優先順序供應器中樣板使用，除非網路無法向高優先順序樣板供給所需材料。

# 分子裝配室

<BlockImage id="molecular_assembler" scale="4" />

<ItemLink id="molecular_assembler" />會接收輸入其中的物品並執行相鄰<ItemLink id="pattern_provider" />設定的操作，或執行其中<ItemLink id="crafting_pattern" />、<ItemLink id="smithing_table_pattern" />、<ItemLink id="stonecutting_pattern" />設定的操作，並將產物輸出到相鄰容器。

它們的主要用途是放在<ItemLink id="pattern_provider" />的相鄰位置。樣板供應器在此情況下有特殊行為，會將相關樣板和材料輸入相鄰裝配室。因為裝配室會將產物自動彈出到相鄰容器（也即彈出到樣板供應器的返回欄內），相鄰放置的裝配室和樣板供應器就是自動化合成樣板所需的一切了。

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>
---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 輸入、輸出、儲存
---

# 輸入、輸出、儲存

**你的ME系統與世界**

AE2中的一個重要概念便是網路儲存，也即網路內容所儲存的地方，通常會是[儲存元件](../items-blocks-machines/storage_cells.md)或連線於<ItemLink id="storage_bus" />的容器。大部分AE2[裝置](devices.md)都會以某種方式與之互動。

例如：

*   <ItemLink id="import_bus" />向網路儲存輸入事物
*   <ItemLink id="export_bus" />從網路儲存輸出事物
*   <ItemLink id="interface" />可向網路儲存輸入或從網路儲存輸出
*   [終端](../items-blocks-machines/terminals.md)在向其中放入、拿取，或填充合成方格時輸入或輸出物品
*   <ItemLink id="storage_bus" />並不會對網路儲存輸入或輸出，而是會對所連線的容器執行這些操作，相當於將這些容器視作網路儲存（也即是其他裝置從*這些匯流排*輸入或輸出）

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        輸入匯流排從其面對的容器中提取物品並輸入網路儲存
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        從物品欄向終端放入物品視作輸入網路儲存
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        介面會將其內部未設定儲存的槽位中的物品，以及超出槽位設定儲存量的物品輸入網路儲存，可透過它們將事物輸入網路
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        樣板供應器會將返回欄內物品輸入網路儲存，可透過它們將事物輸入網路
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        驅動器裝有的元件視作網路儲存
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        儲存匯流排將其連線的容器視作網路儲存
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        輸出匯流排將網路儲存中的物品輸出到其面對的容器
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        從終端中拿取事物視作從網路儲存輸出
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        介面會將在內部設定有儲存的槽位中的物品從網路儲存輸出，可透過它們從網路中輸出事物
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

需在設計自動化和物流設施時著重考慮從網路儲存中輸出和向網路儲存輸入事物的行為/事件。

## 儲存優先順序

可點選GUI右上角扳手以設定優先順序。輸入網路的物品會優先進入最高優先順序的儲存位置，如果有兩個優先順序相同的儲存位置，則會優先選擇已經存有該物品的那個。所有白名單元件在同優先順序情況下視作已經存有該物品。從儲存中輸出的物品會優先從最低優先順序的位置輸出。這一優先順序系統使得在輸入輸出物品的過程中，高優先順序的儲存位置會被填滿，而低優先順序的會被搬空。
---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: 子網路
---

# 子網路

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
        物品管道子網路
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
        流體管道子網路
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
        帶過濾的破壞面板
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
        成型面板子網路
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
        使用埠與儲存匯流排互動作為主網路可訪問的本地子儲存網路
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
        又一個物品管道子網路，可將充能的物品返還至樣板供應器
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

“子網路”是個定義不算嚴格的術語，可認為是任何輔助主網路或完成小任務的網路。這些網路通常很小，所以不需要控制器。子網路通常有2個用途：

* 限制各[裝置](devices.md)所能訪問的儲存位置（你肯定不希望“管道”子網路上的輸入匯流排能訪問主網路儲存，也不希望其將物品直接放入儲存元件而非目標容器）
* 節省主網路的頻道；例如，若將樣板供應器和接著若干帶儲存匯流排的機器的介面相鄰放置，只會佔用1個頻道；如果每臺機器都放一個樣板供應器，則會佔用多個頻道

構建子網路中極為重要的一點便是追蹤[網路連線](me-network-connections.md)。人們通常會把很多介面、匯流排之類的東西堆在一起，然後想著這些裝置能組成子網路，但實際上它們仍透過各種方塊型裝置與主網路保持連線。

不同色的線纜與子網路的建立沒有關係，這麼做僅是為避免線纜連線。

子網路可以是

* 替代垃圾桶和虛空升級的AE2網路設施，用於決定如何以最優方案處理垃圾。它會根據物品庫存和需求，將物品智慧分入堆肥桶陣列或者其他模組的回收器。
* 抽象層。將複雜合成過程的所有細節約束在子網路中。從主網路視角看來，一整座工廠就如同一臺機器。
* 並行層。將一臺執行速度慢的機器換成10臺這種機器。從主網路視角看來兩者完全沒有區別，這麼做也沒有佔用更多頻道。
* 可在容器間傳輸物品或流體的輸入匯流排和儲存匯流排，類似物品或流體管道。
* 破壞面板和儲存匯流排，其中破壞面板僅能將破壞下的事物送入儲存匯流排；可以透過這種方式為破壞面板設定過濾。
* 介面和成型面板，其中輸入介面的事物會送入成型面板，從而被放置或投擲。
* 自動採集賽特斯石英的設施，受主網路的<ItemLink id="level_emitter" />調節控制。
* 主網路可訪問的專用儲存系統，由儲存匯流排與介面構造；可以儲存大量農場輸出，同時避免主儲存過載。
* 等等。

<ItemLink id="quartz_fiber" />在搭建子網路中非常有用。它能在網路間傳輸能量而不提供連線，如此就可向子網路傳輸能量，而不用到處擺能源接收器和供能線纜了。

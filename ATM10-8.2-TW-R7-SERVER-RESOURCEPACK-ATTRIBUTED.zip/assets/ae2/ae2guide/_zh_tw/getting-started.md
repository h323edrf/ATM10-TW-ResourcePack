---
navigation:
  title: 開始與入門（1.20+）
  position: 10
---

<div class="notification is-info">
  以下資訊僅適用於Minecraft 1.20或更新版本的應用能源 2。
</div>

# 開始與入門

## 獲取起始材料

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

應用能源 2開始於尋找[隕石](ae2-mechanics/meteorites.md)。隕石比較常見，且通常會在地形上留下巨大的坑洞，所以你可能已經在旅程中撞見過了。如果還沒有遇到過，可以合成一個<ItemLink id="meteorite_compass" />，它會指向最近的<ItemLink id="mysterious_cube" />。

發現隕石後便要向其中心挖掘。在那裡能找到賽特斯石英簇、賽特斯石英芽、各種型別的[賽特斯石英母巖](items-blocks-machines/budding_certus.md)、一個神秘方塊。

挖下找到的所有賽特斯石英簇和賽特斯石英塊。也可以採集賽特斯石英母巖，但在沒有精準採集時掉落的母巖會降一級。

不要破壞任何無瑕的賽特斯石英母巖，在有精準採集的情況下它們也會降級為有瑕的賽特斯石英母巖，並且不可能將其修復回去。

還要挖下中間的神秘方塊，以獲得所有4種壓印模板。

## 培養賽特斯石英

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

賽特斯石英芽會從[賽特斯石英母巖](items-blocks-machines/budding_certus.md)中生長出來，與紫水晶類似。如果破壞未完全生長的石英芽，則會掉落一個<ItemLink id="certus_quartz_dust" />，不受時運影響。如果破壞長成的石英簇，則會掉落四個<ItemLink id="certus_quartz_crystal" />，且會受時運影響而增加掉落量。

共有4種等級的賽特斯石英母巖：無瑕、有瑕、開裂、損壞。

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

每次石英芽生長時，母巖都有可能降一級，並最終變為普通的賽特斯石英塊。將賽特斯石英母巖或者賽特斯石英塊以及若干個<ItemLink id="charged_certus_quartz_crystal" />一起投入水中，就能進行修復併產生新的母巖。

<RecipeFor id="damaged_budding_quartz" />

無瑕的賽特斯石英母巖不會降級，因而能無限產生賽特斯石英。但是它們無法合成，也無法被鎬完好地挖下搬運，就算有精準採集也不行。（不過它們*可以*被[空間儲存](ae2-mechanics/spatial-io.md)移動。）

賽特斯石英母巖自身的生長非常緩慢。幸運的是，在母巖旁放置<ItemLink id="growth_accelerator" />能大幅加速這一過程。你的第一要務便是製造一些此方塊。

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

假如沒有足夠石英制造<ItemLink id="energy_acceptor" />或是<ItemLink id="vibration_chamber" />，可以製造一個<ItemLink id="crank" />並安到催生器上。

自動採集賽特斯石英的設計[見此](example-setups/simple-certus-farm.md)。

## 福魯伊克斯簡述

另一種所需材料是福魯伊克斯，你應該已經在製造晶體催生器的過程中見過它了。將充能賽特斯石英水晶、紅石、下界石英投入水中就能製成福魯伊克斯。這一流程的自動化則“[留給讀者作為習題](example-setups/processor-automation.md)”。

<ItemLink id="charger" />則是生產<ItemLink id="charged_certus_quartz_crystal" />的必備之物。若未製造還請儘快。

## 壓印一些處理器

在隕石處搜刮到的戰利品中，有破壞神秘方塊而得的四種壓印模板。這些可用在<ItemLink id="inscriber" />中以製造三種處理器。

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

壓印器對面敏感，與原版熔爐類似。從頂面或底面輸入物品會相應放入頂部或底部的槽位，從側面或背面輸入則會插入中間的槽位。產物可從側面或背面抽取。

如果需以漏斗進行自動化（也許也是為了防止線纜亂成毛線團），可用<ItemLink id="certus_quartz_wrench" />旋轉壓印器。

生產各種若干個處理器以開始下一步⸺搭建一個非常基礎的ME系統。處理器的自動化“留給讀者作為習題”。

## 物質能量科技：ME網路與儲存

### ME儲存是什麼？

念法是Emm-Eee，意義是物質能量。

物質能量是應用能源 2的主要元件，算是瘋狂科學家版的多方塊箱子，還能徹底改變你的儲存境況。ME和Minecraft的其他儲存系統極為不同，可能需要跳出思維定式才能習慣。但在入門之後，無論是在極小的空間內大批次儲存，還是安裝多個管理終端，這些都只是可能性的冰山一角。

### 需要知道什麼才能入門？

首先，ME會將物品儲存在其他物品之內，這類物品稱作[儲存元件](items-blocks-machines/storage_cells.md)，共有5級，儲存量依次增加。儲存元件必須放置於<ItemLink id="chest" />或<ItemLink id="drive" />中才可使用。

<ItemLink id="chest" />會在放入元件後立刻顯示其儲存內容，可向其中放入或從中取出物品，和<ItemLink id="minecraft:chest" />類似。兩者的區別在於，物品實際儲存於儲存元件，而非<ItemLink id="chest" />本身。

<ItemLink id="chest" />相對不穩定且有侷限，AE2的真正運用還要看[ME網路](ae2-mechanics/me-network-connections.md)。

## 你的第一個ME系統

現在，應用能源 2的基礎材料和機器都已準備妥當，可以著手搭建你的第一個ME（物質能量）系統了。這個系統非常基礎，沒有自動合成，沒有物流，只有簡單好用的可搜尋儲存。

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   材料列表：
    * 1x <ItemLink id="drive" />
    * 1x <ItemLink id="terminal" />或<ItemLink id="crafting_terminal" />
    * 1x <ItemLink id="energy_acceptor" />
    * 若干[線纜](items-blocks-machines/cables.md)，玻璃、包層、智慧均可，緻密不可
    * 若干[儲存元件](items-blocks-machines/storage_cells.md)，推薦使用4k以在容量和型別間保持均衡（4k和1k混合使用更方便[分割槽](items-blocks-machines/cell_workbench.md)，但這些知識較為複雜，暫不詳述）
---
1.  放下驅動器。
2.  能源接收器（以及若干其他AE2[裝置](ae2-mechanics/devices.md)）有2種形態，方塊形態和麵板形態。兩種形態可在合成方格中轉換。如果你的能源接收器是方塊，應緊貼驅動器放置。如果是一個方形面板，應在驅動器上放置線纜，並線上纜上放置接收器。
3.  給能源接收器供能，用你最喜歡的產能模組中的線纜/管道/導管即可。
4.  在驅動器上方（或眼部高度）放置線纜，並在其上放置終端或合成終端。
5.  將儲存元件放入驅動器。
6.  開用。
7.  隨意調調終端的設定。
8.  沐浴在你超強能力的光輝中。
9.  意識到在宏觀層面上，這個網路有點太小了。

### 擴充套件你的網路

你現在有了基礎儲存，也有了訪問儲存內容的方法，起步很好，但你可能還會想要自動化某些流程。

絕佳示例之一便是在熔爐頂面放置<ItemLink id="export_bus" />以輸入礦石，再在熔爐底面放置<ItemLink id="import_bus" />以提取燒煉過的礦石。

<ItemLink id="export_bus" />能從網路中輸出物品至相貼合的容器中，而<ItemLink id="import_bus" />則能從相貼合的容器中提出物品輸入網路。

### 超越極限

此時你可能已經快放下8個[裝置](ae2-mechanics/devices.md)了，而一旦放下第9個裝置，就要開始管理[頻道](ae2-mechanics/channels.md)了。許多裝置（並非全部）需要佔用一個頻道才能工作。

預設情況下，一個網路能支援8個頻道，突破這個限制後就需要向網路中加入<ItemLink id="controller" />。它能大幅擴充套件你的網路。[智慧線纜](items-blocks-machines/cables.md)則能讓你看見頻道在網路中如何分佈。在開始學習頻道行為時請廣泛使用，或者有大量紅石和熒石也可廣泛使用。

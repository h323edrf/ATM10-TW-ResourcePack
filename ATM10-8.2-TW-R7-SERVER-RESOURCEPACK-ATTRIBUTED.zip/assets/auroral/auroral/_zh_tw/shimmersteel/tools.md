---
item_ids:
  - auroral:shimmersteel_pickaxe
  - auroral:shimmersteel_axe
  - auroral:shimmersteel_shovel
  - auroral:shimmersteel_sword
  - auroral:shimmersteel_hoe
  - auroral:shimmer_soil
navigation:
  title: 輝光鋼工具
  icon: auroral:shimmersteel_pickaxe
  parent: index.md
  position: 43
---

# <Color id="gold">輝光鋼工具</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_pickaxe" scale="2" />

  屬性略勝於鐵，附魔性高，每件工具還各有一項獨門本事。極光期間只要拿在手上，五件都會自行修復。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">鎬</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">對寶石自帶時運</Color>
</Row>

* 挖鑽石、綠寶石、青金石等寶石類礦石時自動按**時運 III** 結算。
* 其餘方塊照常按自身的時運機率結算。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">斧</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_axe" />
  ### <Color id="aqua">強制氧化</Color>
</Row>

* 右鍵任意銅方塊，立刻把它推進到下一個氧化階段。
* 也能像普通斧一樣去皮、刮銅、除蠟。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">鍬</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_shovel" />
  ### <Color id="aqua">自帶精準採集</Color>
</Row>

* 挖任何方塊都按帶精準採集結算。
* 收集雪、草方塊之類的東西非常合適。
* 仍然可以剷出土徑、撲滅營火。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">劍</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_sword" />
  ### <Color id="aqua">緩速、處決、雪痕</Color>
</Row>

* **緩慢 I** —— 每次命中都會給目標掛上。
* **處決** —— 對生命值低於 15% 的敵人造成大量額外傷害。
* **雪痕** —— 被處決的敵人倒下處會留下一層雪。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">鋤</Color>
</Column>

<Row>
  <ItemImage id="shimmersteel_hoe" />
  ### <Color id="aqua">精準採集與輝光壤開墾</Color>
</Row>

* **自帶精準採集** —— 收割作物、挖掘方塊都按帶精準採集結算。
* **開墾輝光壤** —— 右鍵雪塊、細雪、泥土、草方塊或雪，把它變成<ItemLink id="shimmer_soil" />。
* **耕地升級** —— 右鍵普通耕地即可升級（溼度保留）。
* 在冰封生物群系裡開荒時不必帶土，非常省事。

<Row>
  <ItemImage id="shimmer_soil" />
  ### <Color id="aqua">輝光壤</Color>
</Row>

這種魔法耕地會加快作物生長：

* 夜間**快 3 倍**
* 極光期間**快 5 倍**
* 散發微光（亮度等級 2）
* 4 格內有水**或**<ItemLink id="shimmering_ice" />即可保溼
* 上面種著作物時不會退化成泥土
* 和普通耕地一樣，原版與模組的作物種子都能種

與閃耀之冰配在一起，就能做出永遠不用澆水、還自帶光照的地下農場。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">自行修復</Color>
</Column>

極光期間，五件輝光鋼工具只要拿在手上就會自行修復。

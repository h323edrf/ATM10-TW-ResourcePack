---
item_ids:
  - auroral:shimmersteel_bow
navigation:
  title: 輝光鋼弓
  icon: auroral:shimmersteel_bow
  parent: index.md
  position: 44
---

# <Color id="gold">輝光鋼弓</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_bow" scale="2" />

  一把把尋常雪球變成毀滅性星擊的遠端武器——明亮、致盲，而且在寒冷生物群系裡彈藥無窮。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<Recipe id="auroral:shimmersteel_bow_smithing" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">星擊</Color>
</Column>

輝光鋼弓以**雪球**為彈藥。每射出一發，雪球都會化作一發星擊。

<Row>
  <ItemImage id="shimmersteel_bow" />
  ### <Color id="aqua">特性</Color>
</Row>

* **傷害** —— 基礎傷害高於箭矢
* **閃光彈** —— 命中點附近的敵人會短暫失明並失去方向
* **光痕** —— 飛行途中留下可見的粒子軌跡
* **不可回收** —— 星擊射出後無法拾回

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 寒冷生物群系裡雪球取之不盡，基本不用擔心彈藥。
* 面對成群的敵人時，閃光彈的控場效果極好。
* 和所有輝光鋼裝備一樣，它在極光期間會自行修復。

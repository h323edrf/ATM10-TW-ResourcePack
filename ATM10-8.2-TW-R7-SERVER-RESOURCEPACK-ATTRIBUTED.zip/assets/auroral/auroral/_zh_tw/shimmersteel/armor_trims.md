---
navigation:
  title: 盔甲紋飾
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 46
---

# <Color id="gold">輝光鋼盔甲紋飾</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  把輝光鋼錠當作盔甲紋飾材料，能給任何盔甲添上一道冰藍色的點綴，像極光本身一樣。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">附上紋飾</Color>
</Column>

1. 先拿到一張**鍛造模板**（原版結構裡的任意盔甲紋飾圖案）。
2. 把模板、盔甲和一塊<ItemLink id="shimmersteel_ingot" />放進鍛造臺。
3. 做出來的盔甲會帶上一道在藍與銀之間流轉的冰藍紋飾。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">外觀</Color>
</Column>

輝光鋼紋飾有一層獨特的寒冰漸變：

* 暗部是深藍
* 中間調是冷冽的鋼藍
* 高光是明亮的冰白

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">相容性</Color>
</Column>

輝光鋼紋飾適用於：

* 全部原版盔甲——皮革、鎖鏈、鐵、金、鑽石、下界合金
* 大多數支援原版紋飾系統的模組盔甲
* 全部原版紋飾圖案——海岸、沙丘、瞭望、款待、崛起、肋骨、哨兵、塑造、靜謐、豬鼻、尖塔、潮汐、惱鬼、守護、嚮導、荒野

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 配鑽石與鐵盔甲尤其好看，整體是一套統一的寒冷風格。
* 與輝光織護甲搭配，就是一整套冰原冒險者的造型。
* 輝光鋼附魔性高，帶了紋飾的盔甲照樣很好附魔。

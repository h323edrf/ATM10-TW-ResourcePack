---
item_ids:
  - auroral:cold_brewing_stand
navigation:
  title: 寒冷釀造臺
  icon: auroral:cold_brewing_stand
  parent: index.md
  position: 42
---

# <Color id="gold">寒冷釀造臺</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="cold_brewing_stand" scale="2" />

  原版釀造臺的替代品，全程不必去下界。普通釀造臺能釀的它都能釀，只是燒的是雪球而不是烈焰粉。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="cold_brewing_stand" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">運作方式</Color>
</Column>

寒冷釀造臺的行為與原版釀造臺完全一致，只有一處關鍵差別：燃料是**雪球**。

它適合：

* 空島或和平模式的玩法
* 還沒去過下界的玩家
* 雪球取之不盡的寒冷生物群系基地

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">用冰凍花瓣代替地獄疣</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">釀出基礎藥水</Color>
</Row>

<ItemLink id="frozen_petals" />能把水瓶釀成**粗製的藥水**，與地獄疣的效果完全相同。整棵釀造樹就此開啟，全程不必踏進下界一步。

步驟：

1. 往臺子裡放雪球（最多 20 個）。
2. 把水瓶放進下方的槽位。
3. 把冰凍花瓣放進原料槽。
4. 等釀造完成，就得到了粗製的藥水。

之後用常規原料繼續釀造其餘的藥水即可。

---
item_ids:
  - auroral:shimmersteel_ingot
  - auroral:unrefined_shimmersteel
navigation:
  title: 輝光鋼錠
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 40
---

# <Color id="gold">輝光鋼錠</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  本模組的核心魔法金屬。灌注了極光之力，屬性略勝於鐵，也是模組中每一件升級工具、武器與配件的入口。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">第一步 —— 粗製輝光鋼</Color>
</Column>

<Row>
  <ItemImage id="unrefined_shimmersteel" />
  ### <Color id="aqua">鐵 + 極光碎片</Color>
</Row>

用鐵錠與<ItemLink id="aurora_shard" />合成粗製輝光鋼。

<RecipeFor id="unrefined_shimmersteel" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">第二步 —— 冰川盆地灌注</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">灌注</Color>
</Row>

在盛滿液態光環的<ItemLink id="glacial_basin" />裡灌注粗製輝光鋼。

1. 在寒冷生物群系的露天處放一座冰川盆地。
2. 等一場極光把盆地灌滿（光環 3/3）。
3. 手持粗製輝光鋼右鍵點選盆地。
4. 盆地會消耗**全部**液態光環，產出一塊輝光鋼錠。

**要點：**盆地必須完全灌滿才能完成這次灌注。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **附魔性高** —— 很容易附上魔咒
* **極光親和** —— 極光期間，輝光鋼工具與護甲會自行修復
* **數值** —— 略勝於鐵，不及鑽石

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">用途</Color>
</Column>

輝光鋼錠在鍛造臺上把鐵製裝備升級。升級需要一張**輝光鋼升級鍛造模板**。

* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [輝光鋼工具](tools.md) —— 鎬、斧、鍬、鋤、劍
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [輝光鋼弓](bow.md) —— 把雪球射成星擊

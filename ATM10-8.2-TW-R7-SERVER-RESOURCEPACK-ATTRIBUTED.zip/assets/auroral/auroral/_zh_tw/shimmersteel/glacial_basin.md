---
item_ids:
  - auroral:glacial_basin
navigation:
  title: 冰川盆地
  icon: auroral:glacial_basin
  parent: index.md
  position: 41
---

# <Color id="gold">冰川盆地</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  你的主要工作站。在極光期間收集液態光環，再用它把原料轉化成對應的魔法產物。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">運作方式</Color>
</Column>

1. 把盆地**放**在露天處。
2. **等**極光開始。
3. **看著**盆地被髮光的液態光環灌滿（最多 3 級）。
4. 手持原料**右鍵**，把它轉化掉。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">轉化對照</Color>
</Column>

| 放入 | 產出 | 光環消耗 |
|-------|--------|-----------|
| <ItemLink id="unrefined_shimmersteel" /> | <ItemLink id="shimmersteel_ingot" /> | 3（需灌滿） |
| <ItemLink id="woven_leather" /> | <ItemLink id="shimmerweave_fabric" /> | 1 |
| <ItemLink id="frozen_petals" /> | <ItemLink id="aurora_shard" /> | 1 |
| 冰 | <ItemLink id="shimmering_ice" /> | 1 |

灌注輝光鋼錠要求盆地**完全灌滿**，並一次消耗掉全部 3 級液態光環。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 多擺幾座盆地，一場極光就能多收一些光環。
* 盆地上方必須能直接看到天空。
* 極光會持續一整夜，灌滿的時間很充裕。

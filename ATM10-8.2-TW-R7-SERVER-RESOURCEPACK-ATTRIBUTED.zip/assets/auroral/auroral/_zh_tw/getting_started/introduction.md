---
navigation:
  title: 簡介
  icon: auroral:frozen_petals
  parent: index.md
  position: 10
---

# <Color id="gold">極光簡介</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  本模組把寒冷生物群系從荒蕪之地變成後期發展的樞紐。駕馭北極光，打造魔法物品、強化工具與強力護甲。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光</Color>
</Column>

一種在寒冷生物群系的夜晚隨機發生的天象。極光出現時，天空中會鋪滿綠色與粉色的流光。魔法就發生在這段時間裡。

極光持續期間：

* 可以用<ItemLink id="glacial_basin" />收集**液態光環**
* **輝光鋼裝備**會自動修復自身
* 天上可能會生成**極光鸚鵡螺**
* 雪方塊上會長出**極光花苞**

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">寒冷生物群系</Color>
</Column>

本模組的內容是為寒冷生物群系設計的：

* 積雪平原
* 冰刺之地
* 凍洋
* 冰封山峰
* 雪林
* 積雪針葉林

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">發展路線</Color>
</Column>

1. 在寒冷生物群系裡等一場極光。
2. 從自然生成的極光花苞上收穫<ItemLink id="frozen_petals" />。
3. 製作<ItemLink id="glacial_basin" />與<ItemLink id="cold_brewing_stand" />。
4. 在極光期間收集液態光環，把鐵灌注成<ItemLink id="shimmersteel_ingot" />。
5. 打造強化的工具、武器與護甲。

---
navigation:
  title: 最初幾步
  icon: auroral:glacial_basin
  parent: index.md
  position: 11
---

# <Color id="gold">最初幾步</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  你的第一場極光、第一座盆地、第一塊輝光鋼錠。五步走完整套迴圈。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">採集冰凍花瓣</Color>
</Column>

<ItemLink id="frozen_petals" />是解鎖本模組其餘內容的鑰匙。來源：

* 從極光期間在雪上自然生成的<ItemLink id="aurora_bloom" />上收穫。
* 極光期間由極光鸚鵡螺掉落。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">製作冰川盆地</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">冰川盆地</Color>
</Row>

冰川盆地是你的主要工作站。在極光期間把它放在露天處，它就會盛滿液態光環。

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">你的第一塊輝光鋼</Color>
</Column>

等冰川盆地收集到液態光環之後：

1. 手持鐵錠右鍵點選盆地。
2. 鐵會轉化為<ItemLink id="shimmersteel_ingot" />。
3. 用輝光鋼打造強化的工具與武器。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">寒冷釀造臺</Color>
</Column>

<Row>
  <ItemImage id="cold_brewing_stand" />
  ### <Color id="aqua">寒冷釀造臺</Color>
</Row>

一條不必去下界的釀造路線。它燒的是雪球，不是烈焰粉。

<RecipeFor id="cold_brewing_stand" />

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">沒有地獄疣也能釀粗製的藥水</Color>
</Row>

冰凍花瓣能把水瓶釀成粗製的藥水，與地獄疣的效果完全相同。整棵釀造樹就此開啟，全程不必踏進下界一步。

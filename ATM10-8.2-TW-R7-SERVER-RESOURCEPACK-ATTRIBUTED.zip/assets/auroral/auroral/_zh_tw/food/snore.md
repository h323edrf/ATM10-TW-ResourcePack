---
item_ids:
  - auroral:snore
navigation:
  title: 雪夾心
  icon: auroral:snore
  parent: food/index.md
  position: 5
---

# <Color id="gold">雪夾心</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snore" scale="2" />

  兩塊曲奇夾一個裹糖烤雪球，壓成一個小小的甜點三明治。出乎意料地頂飽，而且鸚鵡螺不會記仇。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="snore" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **頂飽的一餐** —— 恢復的飢餓值與飽和度與熟牛肉相當
* **潮湧能量** —— 30 秒：水下呼吸、水中挖掘更快、水裡看得清楚
* **安眠點心** —— 重置幻翼的失眠計時，效果等同睡過一覺
* **最多疊到 16**

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 下水作業之前吃正合適。一個雪夾心就有 30 秒潮湧能量，不必去折騰海洋之心。
* 長途趕路時帶一個，不用鋪床也能擋住幻翼。
* 與直接吃<ItemLink id="roasted_snowball" />不同，吃雪夾心**不會**惹惱鸚鵡螺——那層糖衣把這事圓過去了。

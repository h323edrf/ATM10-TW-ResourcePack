---
navigation:
  title: "食物與飲品"
  icon: auroral:hot_cocoa
  parent: index.md
  position: 70
---

# <Color id="gold">食物與飲品</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  用<ItemLink id="cold_brewing_stand" />釀製、以霜雪浸染的原料做成的寒地常備品。每一樣都能給你爭取一點時間、一點暖意，或是一點對抗嚴寒的餘地。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">配方</Color>
</Column>

* <ItemImage id="hot_cocoa" scale="0.75"/> [熱可可](hot_cocoa.md) —— 暖身的飲品，短時間抗凍
* <ItemImage id="frosted_cookies" scale="0.75"/> [霜凍曲奇](frosted_cookies.md) —— 帶著魔法微光的甜點
* <ItemImage id="roasted_snowball" scale="0.75"/> [烤雪球](roasted_snowball.md) —— 烤過的雪球，鸚鵡螺對此深惡痛絕
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [裹糖烤雪球](sugared_roasted_snowball.md) —— 鸚鵡螺肯接受的那份賠禮
* <ItemImage id="snore" scale="0.75"/> [雪夾心](snore.md) —— 兩塊曲奇夾一個裹糖雪球，給予潮湧能量

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">來自園圃</Color>
</Column>

* <ItemImage id="glow_leek" scale="0.75"/> [發光韭蔥](../flora/glow_leeks.md) —— 種在閃耀之冰上的生物發光蔬菜
* <ItemImage id="candied_glow_leek" scale="0.75"/> [糖漬發光韭蔥](../flora/glow_leeks.md) —— 加了糖，而且不會留下發光的後遺症

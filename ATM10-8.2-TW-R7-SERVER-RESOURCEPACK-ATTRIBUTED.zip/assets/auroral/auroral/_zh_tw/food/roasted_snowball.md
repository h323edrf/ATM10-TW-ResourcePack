---
item_ids:
  - auroral:roasted_snowball
navigation:
  title: 烤雪球
  icon: auroral:roasted_snowball
  parent: food/index.md
  position: 3
---

# <Color id="gold">烤雪球</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="roasted_snowball" scale="2" />

  一顆烤到微微焦黃的雪球，頂上還嫋嫋冒著熱氣。看著像全世界最小的棉花糖，吃起來也差不多就那麼點分量。鸚鵡螺不會原諒這件事。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<Recipe id="auroral:roasted_snowball_from_campfire" />

在熔爐裡燒煉雪球也可以。

<Recipe id="auroral:roasted_snowball_from_smelting" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **略能果腹** —— 只恢復半格飢餓值
* **隨時可吃** —— 飢餓值滿時也啃得下去
* **冒犯** —— 吃一個，你在極光眼裡就成了不知好歹的人

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">警告</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">鸚鵡螺記著這筆賬</Color>
</Row>

吃下烤雪球會深深冒犯極光鸚鵡螺。做出這件事之後，極光期間野生鸚鵡螺**就不會再在你附近生成**。天空安靜下來，那陣鈴音也散了。

你會看到這句提示：*「威嚴的鸚鵡螺不會再翱翔於你的天空」*——它們是認真的。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">賠罪</Color>
</Column>

<Row>
  <ItemImage id="sugared_roasted_snowball" />
  ### <Color id="aqua">一份甜的道歉</Color>
</Row>

做一個<ItemLink id="sugared_roasted_snowball" />吃下去。鸚鵡螺很寬容——一個甜甜的表示，它們就會重新光顧你的天空。

如果你只想嚐嚐味道又不想擔後果，那就把它做進<ItemLink id="snore" />裡吃。曲奇會把這事圓過去。

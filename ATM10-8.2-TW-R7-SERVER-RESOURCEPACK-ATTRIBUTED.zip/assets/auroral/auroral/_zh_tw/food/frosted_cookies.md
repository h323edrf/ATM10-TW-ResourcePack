---
item_ids:
  - auroral:frosted_cookies
navigation:
  title: 霜凍曲奇
  icon: auroral:frosted_cookies
  parent: food/index.md
  position: 2
---

# <Color id="gold">霜凍曲奇</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frosted_cookies" scale="2" />

  撒了魔法冰凍花瓣的甜點，像極光下的新雪一樣閃著光。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="frosted_cookies" />

（一次做出 4 塊霜凍曲奇）

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **快速點心** —— 恢復少量飢餓值
* **微光粒子** —— 吃的時候會冒出閃亮的極光粒子
* **可堆疊** —— 最多疊到 64

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 趕路時用來快速補飢餓值很合適。
* 配方划算——一片冰凍花瓣能做 4 塊曲奇。
* 寒夜裡配<ItemLink id="hot_cocoa" />，正是一對。

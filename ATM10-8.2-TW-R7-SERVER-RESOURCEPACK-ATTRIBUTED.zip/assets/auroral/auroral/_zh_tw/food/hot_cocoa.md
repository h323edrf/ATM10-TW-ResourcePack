---
item_ids:
  - auroral:hot_cocoa
navigation:
  title: 熱可可
  icon: auroral:hot_cocoa
  parent: food/index.md
  position: 1
---

# <Color id="gold">熱可可</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hot_cocoa" scale="2" />

  一杯冒著熱氣的可可，既擋得住嚴寒，又順帶把你修補一下。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="hot_cocoa" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">效果</Color>
</Column>

* **免疫凍傷** —— 3 分鐘內完全不受凍傷效果影響
* **生命恢復 I** —— 30 秒
* **恢復飢餓值** —— 中等

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 去寒冷生物群系探索時隨身多帶幾杯。
* 合成時用掉的奶桶，在喝完後會作為空桶還給你。
* 配上<ItemLink id="frosted_cookies" />，正好歇一口氣。

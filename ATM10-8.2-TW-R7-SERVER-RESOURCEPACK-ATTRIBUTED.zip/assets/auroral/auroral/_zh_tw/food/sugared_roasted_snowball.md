---
item_ids:
  - auroral:sugared_roasted_snowball
navigation:
  title: 裹糖烤雪球
  icon: auroral:sugared_roasted_snowball
  parent: food/index.md
  position: 4
---

# <Color id="gold">裹糖烤雪球</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="sugared_roasted_snowball" scale="2" />

  在糖裡滾到發亮的烤雪球。那層亮光不是魔法——那是一份能吃的道歉。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="sugared_roasted_snowball" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **略能果腹** —— 和原味烤雪球一樣，就那麼一小口
* **隨時可吃** —— 飢餓值滿時也能吃
* **道歉味** —— 吃一個就與極光鸚鵡螺重歸於好

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">這份道歉</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">鸚鵡螺的原諒</Color>
</Row>

如果你吃過<ItemLink id="roasted_snowball" />，鸚鵡螺已經嫌惡地飛走了。吃下一個裹糖烤雪球就是告訴它們你知錯了，下一場極光它們便會回來。

你會看到*「威嚴的鸚鵡螺再度起飛！」*，說明你的名聲已經恢復。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 在吃第一個烤雪球之前就先做一個備著，否則你可能會後悔。
* 那層亮光讓它一眼就能與原味的那個區分開。
* 鸚鵡螺本來就沒記你的仇時吃它沒有效果，不過味道照樣是甜的。

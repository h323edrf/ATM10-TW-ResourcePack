---
item_ids:
  - auroral:aurora_bloom
  - auroral:aurora_bloom_decorative
  - auroral:frozen_petals
navigation:
  title: 極光花苞
  icon: auroral:frozen_petals
  parent: index.md
  position: 30
---

# <Color id="gold">極光花苞</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_bloom" scale="2" />

  極光期間在雪上自行冒出的魔法花朵。它是<ItemLink id="frozen_petals" />的來源，也是本模組絕大部分內容的入口。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">尋找極光花苞</Color>
</Column>

極光期間，極光花苞會在寒冷生物群系的地表自然生成。它要經過**四個階段**才完全成熟。極光結束時還留在原地的花苞，會在日出時枯萎。

可供生成與存活的表面：

* 雪（要求下方那格本身也是合格的積雪表面，這樣雪化了以後花苞才不會孤零零地留在泥土或石頭上）
* 雪塊
* 細雪（見下）
* 冰、浮冰與藍冰（凍洋的表面可以）
* <ItemLink id="shimmering_ice" />

<Row>
  <ItemImage id="aurora_bloom" />
  ### <Color id="aqua">陷在雪裡的花苞</Color>
</Row>

花苞種在**雪**上或長在**細雪**裡時，會記住那種雪的型別。花苞被打掉或枯萎後，原來的雪會照原樣回到那一格——是雪就還是雪，是細雪就還是細雪。被埋住的花苞會在上方冒出細細一縷雪花粒子，所以就算上面又積了雪也仍然找得到。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">收穫</Color>
</Column>

打掉完全成熟（第 3 階段）的極光花苞會掉落：

* <ItemLink id="frozen_petals" />（帶時運時為 1～4 個）
* **活的極光花苞**本身，可以再種回去
* 在此之上還有 **15% 的機率**多掉一株活花苞

打掉未成熟的花苞什麼都不給——耐心才有回報。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">儲存花苞（精準採集）</Color>
</Column>

用帶**精準採集**的工具打掉完全成熟的極光花苞，得到的不是冰凍花瓣，而是**裝飾用極光花苞**。這個裝飾變種：

* 日出時不會枯萎——它會一直留著
* 外觀固定停在第 3 階段
* 可以放進**花盆**裡展示
* 打掉時掉落自身，所以可以隨處複製

這是把極光花苞留到極光之外的唯一辦法。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">冰凍花瓣的用途</Color>
</Column>

* **粗製的藥水** —— 在任意釀造臺裡像地獄疣一樣把水瓶釀成粗製的藥水
* <ItemLink id="cold_brewing_stand" /> —— 與輝光鋼錠合成
* <ItemLink id="glow_leek_seeds" /> —— 與小麥種子合成
* <ItemLink id="frosted_cookies" /> —— 帶著魔法微光的甜點
* <ItemLink id="aurora_shard" /> —— 在光環等級 1 的冰川盆地裡灌注

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">末影化</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">用末影珍珠右鍵</Color>
</Row>

手持**末影珍珠**右鍵點選極光花苞，它會變成同一生長階段的<ItemLink id="ender_bloom" />，珍珠在此過程中被消耗。完整的生長週期見[末影花苞](ender_bloom.md)。

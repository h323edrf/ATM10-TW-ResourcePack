---
item_ids:
  - auroral:ender_bloom
  - auroral:aurora_ender_shard
navigation:
  title: 末影花苞
  icon: auroral:aurora_ender_shard
  parent: index.md
  position: 33
---

# <Color id="gold">末影花苞</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ender_bloom" scale="2" />

  極光花苞被末影氣息浸染後的表親——紫色、不安分，還是一條可再生的末影珍珠來源。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">製作</Color>
</Column>

末影花苞不會自行生成。要得到一株：

1. 在極光事件期間找到或種出一株<ItemLink id="aurora_bloom" />。
2. 手持**末影珍珠**右鍵點選這株花苞。
3. 花苞會變成同一生長階段的末影花苞，珍珠被消耗。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">長期存在</Color>
</Column>

與極光花苞不同，末影花苞**永遠留著**。它不會在日出時枯萎，極光結束後也照樣在。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">生長條件</Color>
</Column>

末影花苞只有種在下列方塊上才會推進生長階段：

* <ItemLink id="shimmer_soil" />
* **末地石**

種在其他能支撐它的方塊上時，它可以無限期存活，但會一直停在種下時的那個階段。除非種在上面兩種方塊之一，否則骨粉也沒有效果。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">收穫</Color>
</Column>

在**任意**階段打掉末影花苞，都會掉落一個末影花苞物品（重新種下時總是從第 0 階段開始）。

在第 3 階段打掉時，**還會**額外掉落：

* 一個<ItemLink id="aurora_ender_shard" />
* **5% 的機率**再多掉一株末影花苞

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光末影碎片</Color>
</Column>

<Row>
  <ItemImage id="aurora_ender_shard" />
  ### <Color id="aqua">可再生的末影珍珠</Color>
</Row>

兩個極光末影碎片可以合成回一顆末影珍珠。一座成熟的末影花苞農場就是一條可再生的末影珍珠來源。

<Recipe id="auroral:ender_pearl_from_shards" />

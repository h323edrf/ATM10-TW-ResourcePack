---
item_ids:
  - auroral:glow_leek
  - auroral:glow_leek_seeds
  - auroral:candied_glow_leek
navigation:
  title: 發光韭蔥
  icon: auroral:glow_leek
  parent: index.md
  position: 31
---

# <Color id="gold">發光韭蔥</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glow_leek" scale="2" />

  在嚴寒中長得正好的發光蔬菜。吃下去會獲得夜視與發光。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">種子</Color>
</Column>

<Row>
  <ItemImage id="glow_leek_seeds" />
  ### <Color id="aqua">發光韭蔥種子</Color>
</Row>

用<ItemLink id="frozen_petals" />與**小麥種子**合成。

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">種植</Color>
</Column>

發光韭蔥只能種在<ItemLink id="shimmering_ice" />上。它不需要光照，夜裡也照常生長。

完全成熟後打掉植株會掉落：

* **發光韭蔥**（蔬菜本身）
* **發光韭蔥種子**（用於補種）

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">食用</Color>
</Column>

吃下發光韭蔥會獲得：

* **夜視** —— 在黑暗中看得清楚
* **發光** —— 你也會被別人看見

<Row>
  <ItemImage id="candied_glow_leek" />
  ### <Color id="aqua">糖漬發光韭蔥</Color>
</Row>

加了糖，而且不會留下發光的後遺症，只給夜視。

<RecipeFor id="candied_glow_leek" />

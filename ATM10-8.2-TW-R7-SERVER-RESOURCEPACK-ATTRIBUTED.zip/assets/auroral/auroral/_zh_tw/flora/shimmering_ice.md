---
item_ids:
  - auroral:shimmering_ice
navigation:
  title: 閃耀之冰
  icon: auroral:shimmering_ice
  parent: index.md
  position: 32
---

# <Color id="gold">閃耀之冰</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmering_ice" scale="2" />

  灌注了極光的冰：微微發光、永不融化，還會為周圍的地面保溼。寒冷生物群系農場的地基。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">獲取</Color>
</Column>

* 在<ItemLink id="glacial_basin" />裡用液態光環灌注普通的冰
* 在被極光照拂過的冰封生物群系裡自然生成（稀有）

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">永不融化</Color>
</Row>

完全不受熱與光影響。用來做裝飾性建築，或者鋪一條需要長久留存的路，都很合適。

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">發光</Color>
</Row>

散發亮度等級 8 的柔光——既足以阻止生物生成，又不破壞氣氛。

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">保溼</Color>
</Row>

像水一樣，為**半徑 4 格**內的原版耕地與<ItemLink id="shimmer_soil" />保溼。再配上那點柔光，它非常適合用來做沒有水渠的地下農場。

<Row>
  <ItemImage id="glow_leek" />
  ### <Color id="aqua">發光韭蔥的基質</Color>
</Row>

<ItemLink id="glow_leek_seeds" />只能種在閃耀之冰上——種出這種生物發光作物，靠的正是它的魔法特性。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">與輝光壤搭配</Color>
</Column>

把閃耀之冰與<ItemLink id="shimmer_soil" />（用輝光鋼鋤製作）配在一起，就是冰封生物群系裡的終極農場：

* 閃耀之冰同時提供保溼**與**照明
* 輝光壤加快作物生長——**夜間 3 倍，極光期間 5 倍**
* 完全不需要水，哪裡都能用

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">用途一覽</Color>
</Column>

* 不用水就能給輝光壤農場保溼
* 種發光韭蔥（唯一可用的基質）
* 鋪永不融化的冰路
* 做帶柔和光照的裝飾性建築
* 做自帶照明的地下農場

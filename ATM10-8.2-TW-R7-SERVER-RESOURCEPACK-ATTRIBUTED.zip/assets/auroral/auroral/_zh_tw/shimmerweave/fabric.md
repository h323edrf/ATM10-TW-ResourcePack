---
item_ids:
  - auroral:shimmerweave_fabric
  - auroral:woven_leather
navigation:
  title: 輝光織物
  icon: auroral:shimmerweave_fabric
  parent: index.md
  position: 50
---

# <Color id="gold">輝光織物</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_fabric" scale="2" />

  灌注了極光之力的布料——輕盈、耐用，是每一件輝光織護甲的基礎。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">冰川盆地灌注</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">皮革或羊毛 → 織物</Color>
</Row>

在盛滿液態光環的<ItemLink id="glacial_basin" />裡灌注皮革或任意顏色的羊毛。

1. 在露天處放一座冰川盆地。
2. 等一場極光把它灌滿。
3. 手持皮革或羊毛右鍵點選盆地。
4. 得到輝光織物。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">編織皮革</Color>
</Column>

<Row>
  <ItemImage id="woven_leather" />
  ### <Color id="aqua">用皮革合成</Color>
</Row>

有些配方要用編織皮革，它由普通皮革合成。

<RecipeFor id="woven_leather" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **輕盈** —— 輝光織做的護甲幾乎不增加負擔
* **極光親和** —— 極光期間護甲會自行修復
* **導魔性** —— 讓每一件護甲的特殊能力得以發揮

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">用途</Color>
</Column>

輝光織物在鍛造臺上把鐵製護甲升級。升級需要一張**輝光鋼升級鍛造模板**。

* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [輝光織護目鏡](goggles.md) —— 讓隱藏的敵人現形
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [輝光織外套](tunic.md) —— 防火
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [輝光織護腿](leggings.md) —— 雪上加速
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [輝光織冰靴](skates.md) —— 冰面上的行家

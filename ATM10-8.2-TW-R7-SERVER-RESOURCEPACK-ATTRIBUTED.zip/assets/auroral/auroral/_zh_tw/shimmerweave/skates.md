---
item_ids:
  - auroral:shimmerweave_skates
navigation:
  title: 輝光織冰靴
  icon: auroral:shimmerweave_skates
  parent: index.md
  position: 54
---

# <Color id="gold">輝光織冰靴</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_skates" scale="2" />

  輝光織護甲裡最全能的一件。冰、雪、水乃至岩漿都由它擺佈，把險惡地形變成通途。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_skates" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">冰雪加速</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">地面加成</Color>
</Row>

* 站在冰或雪塊上時獲得速度加成。
* 在浮冰與藍冰上速度更快。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">滑冰慣性</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">像船一樣滑行</Color>
</Row>

* 在冰上像船一樣積攢動量。
* 持續移動即可加速，鬆開按鍵就順勢滑行。
* 藍冰是最順滑的滑行面。
* 就算不按任何移動鍵，慣性也會帶著你走。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">冰霜行者強化</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">水與岩漿一併讓路</Color>
</Row>

* 走在水面上會結出薄冰。
* 接觸岩漿時把它**變成黑曜石**。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">免疫摔落</Color>
</Column>

* 落在冰或黑曜石上時不受摔落傷害。
* 從高處一路滑下來時正好。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">搭配</Color>
</Column>

* <ItemLink id="shimmerweave_leggings" /> —— 在雪與靈魂沙上再加一份速度。
* **輝光鋼鍬** —— 靠精準採集快速鋪出雪路。
* 岩漿變黑曜石這一條，讓穿越下界安全了很多。

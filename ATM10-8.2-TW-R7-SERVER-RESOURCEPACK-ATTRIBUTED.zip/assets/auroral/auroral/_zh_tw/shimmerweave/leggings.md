---
item_ids:
  - auroral:shimmerweave_leggings
navigation:
  title: 輝光織護腿
  icon: auroral:shimmerweave_leggings
  parent: index.md
  position: 53
---

# <Color id="gold">輝光織護腿</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_leggings" scale="2" />

  一條主打機動性的護腿——踏雪快，踩靈魂沙也快。下界與積雪平原都會給你讓路。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_leggings" />

在鍛造臺上用輝光鋼升級模板與<ItemLink id="shimmerweave_fabric" />升級鐵護腿即可得到。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">雪上加速</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">積雪不再拖慢腳步</Color>
</Row>

* 走在雪塊上時獲得速度加成。
* 不再被雪拖慢。
* 橫穿積雪生物群系時非常好用。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">靈魂疾行</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_leggings" />
  ### <Color id="aqua">靈魂沙上的行家</Color>
</Row>

* 在靈魂沙與靈魂土上自帶靈魂疾行效果。
* 與那個魔咒不同，它**不會**損耗護腿的耐久。
* 穿越下界的靈魂沙峽谷時不必減速。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 與<ItemLink id="shimmerweave_skates" />搭配，機動性拉滿。
* 這份靈魂疾行效果可與原版的靈魂疾行魔咒疊加。
* 主世界的積雪生物群系與下界的靈魂沙峽谷都很受用。

---
item_ids:
  - auroral:shimmerweave_goggles
navigation:
  title: 輝光織護目鏡
  icon: auroral:shimmerweave_goggles
  parent: index.md
  position: 51
---

# <Color id="gold">輝光織護目鏡</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_goggles" scale="2" />

  一副附了魔的眼鏡，能讓黑暗中潛伏的威脅現形。敵對生物會隔著牆發光。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_goggles" />

在鍛造臺上用輝光鋼升級模板與<ItemLink id="shimmerweave_fabric" />升級鐵頭盔即可得到。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">敵意偵測</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_goggles" />
  ### <Color id="aqua">發光光環</Color>
</Row>

* **發光** —— 32 格內所有敵對生物都會發光，隔著牆也看得見。
* 探洞與夜戰都很好用。
* 全黑環境下照常生效。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 配上夜視藥水或<ItemLink id="glow_leek" />，視野就齊全了。
* 想安全探索漆黑的洞穴，這件是必需品。
* 32 格的半徑足以覆蓋大多數戰鬥場面。

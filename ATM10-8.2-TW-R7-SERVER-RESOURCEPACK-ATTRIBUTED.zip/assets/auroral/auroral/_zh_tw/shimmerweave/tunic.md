---
item_ids:
  - auroral:shimmerweave_tunic
navigation:
  title: 輝光織外套
  icon: auroral:shimmerweave_tunic
  parent: index.md
  position: 52
---

# <Color id="gold">輝光織外套</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_tunic" scale="2" />

  一件以火制火的魔法胸甲。著火時自動滅火，而且完全不吃火焰傷害。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_tunic" />

在鍛造臺上用輝光鋼升級模板與<ItemLink id="shimmerweave_fabric" />升級鐵胸甲即可得到。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">自動滅火</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_tunic" />
  ### <Color id="aqua">即時防火</Color>
</Row>

* 穿戴者著火時會自動被撲滅。
* 裝備期間不受火焰傷害。
* 對一切火源有效——岩漿、火焰方塊、烈焰人的攻擊。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">寒涼光環</Color>
</Column>

灌注了極光的織物會驅散熱量，因此這件外套在以下場合極為好用：

* 探索下界
* 與烈焰人作戰
* 在岩漿附近施工

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 安全穿行下界的必備品。
* 與<ItemLink id="shimmerweave_skates" />搭配尤佳，後者接觸岩漿時會把它變成黑曜石。
* 防火是被動生效的，不需要任何操作。

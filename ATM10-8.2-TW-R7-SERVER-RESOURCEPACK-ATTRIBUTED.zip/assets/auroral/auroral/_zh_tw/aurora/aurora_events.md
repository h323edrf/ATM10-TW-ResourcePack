---
item_ids:
  - auroral:aurora_shard
navigation:
  title: 極光事件
  icon: auroral:aurora_shard
  parent: index.md
  position: 20
---

# <Color id="gold">極光事件</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_shard" scale="2" />

  本模組的核心天象。極光一現，寒冷生物群系就活了過來。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光何時出現</Color>
</Column>

在寒冷生物群系裡，每個夜晚有 **33% 的機率**開始一場極光。極光持續期間：

* 天空中鋪滿綠色與粉色的流光。
* 夜晚不會完全變黑。
* 本模組的各項魔法效果全部開啟。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">效果</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">液態光環</Color>
</Row>

露天放置的<ItemLink id="glacial_basin" />會緩慢盛滿液態光環——灌注輝光鋼所需的魔法物質。

<Row>
  <ItemImage id="shimmersteel_pickaxe" />
  ### <Color id="aqua">裝備自修</Color>
</Row>

極光期間，裝備著的輝光鋼工具與輝光織護甲會自行修復。

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">生物生成</Color>
</Row>

極光事件期間，極光鸚鵡螺會飄到玩家附近。

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">植物生長</Color>
</Row>

雪方塊上會長出<ItemLink id="aurora_bloom" />，可以收穫冰凍花瓣。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光催化</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">爐心木原木</Color>
</Row>

在寒冷生物群系裡，玩家 32 格內每有一根點燃的<ItemLink id="hearthwood_log" />，入夜時的極光機率就**增加 15%**。最多三根疊加，共 **+45%**，在預設設定下把每夜的機率推到約 **78%**。

催化只是大幅提升，不是必定觸發。想讓極光幾乎必現，就在睡覺的地方多放幾根點燃的原木，並確保入夜時你人在寒冷生物群系裡。

<RecipeFor id="hearthwood_log" />

點燃的爐心木原木還能免疫凍傷、驅趕幻翼，並改善村民交易。

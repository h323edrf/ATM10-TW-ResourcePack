---
item_ids:
  - auroral:auroral_nautilus_spawn_egg
  - auroral:auroral_snowlette_spawn_egg
navigation:
  title: 極光生物
  icon: auroral:auroral_nautilus_spawn_egg
  parent: index.md
  position: 21
---

# <Color id="gold">極光中的生物</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="auroral_nautilus_spawn_egg" scale="2" />

  由天光引來的生靈。有的能馴服，有的能騎乘，有的只是陪著你。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光鸚鵡螺</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">野生習性</Color>
</Row>

一種溫和的浮空生物，只在極光期間出現，拖著微微發光的螺殼在空中飄蕩。

* 只在極光進行時生成
* 沿圓形軌跡緩緩飄浮
* 性情溫和，不會主動攻擊
* 有三種體型
* 極光結束 30 秒後從容消散

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">吸引鸚鵡螺</Color>
</Row>

野生鸚鵡螺很好奇，會朝手持<ItemLink id="aurora_shard" />的玩家飄過來。

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">馴服</Color>
</Row>

給野生鸚鵡螺喂極光碎片。每塊碎片有 **33% 的機率**馴服成功。馴服之後：

* 它會繞著你緩慢環行。
* 極光結束時不再消失。
* 出現心形粒子表示已建立羈絆。

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">下令</Color>
</Row>

* **潛行 + 右鍵** —— 在**跟隨**（繞你環行）與**留守**（原地懸停）之間切換。

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">騎乘</Color>
</Row>

馴服的鸚鵡螺不用鞍就能騎。

1. 右鍵騎上（僅限主人，且鸚鵡螺不能處於留守狀態）。
2. 用移動鍵和視線方向控制飛行。
3. 按住**空格**蓄力，鬆開後獲得加速，蓄滿時最高可達 **3 倍**速度。

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">掉落物</Color>
</Row>

鸚鵡螺消散或被殺死時，可能掉落：

* 1～2 個極光碎片（僅限被玩家擊殺）
* 鸚鵡螺殼（15% 機率，僅限被玩家擊殺）

<Row>
  <ItemImage id="roasted_snowball" />
  ### <Color id="aqua">冒犯鸚鵡螺</Color>
</Row>

吃下<ItemLink id="roasted_snowball" />會冒犯極光。揹著這份冒犯期間，極光中的野生鸚鵡螺**不會在你附近生成**，只剩已馴服的那些。想要賠罪，就做一個<ItemLink id="sugared_roasted_snowball" />吃下去，天空會重新眷顧你。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光小雪人</Color>
</Column>

<Row>
  <ItemImage id="auroral_snowlette_spawn_egg" />
  ### <Color id="aqua">口袋大小的雪傀儡</Color>
</Row>

用<ItemLink id="aurora_shard" />右鍵點選雪傀儡，就能得到這個小小的友善夥伴。

* 像寵物一樣跟著玩家
* 大約只有普通雪傀儡的四分之一大
* 朝它扔雪球可以為它回血
* 會散出柔和的極光星屑

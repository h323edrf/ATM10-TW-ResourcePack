---
navigation:
  title: 極光
  icon: auroral:frozen_petals
  position: 0
---

# <Color id="gold">極光</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  一套以天穹之力、秘法冶金與極地生存為核心的冬季擴充套件。駕馭北極光的力量，打造輝光鋼裝備、輝光織護甲，以及只在極光下才會綻放的珍稀花朵。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

> *「天空給予，堅冰銘記。」*

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">從這裡開始</Color>
</Column>

* <ItemImage id="frozen_petals" scale="0.75"/> [簡介](getting_started/introduction.md) —— 本模組新增了什麼，以及這套迴圈是怎麼串起來的
* <ItemImage id="glacial_basin" scale="0.75"/> [最初幾步](getting_started/first_steps.md) —— 你的第一場極光、第一座盆地、第一塊錠

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">極光</Color>
</Column>

* <ItemImage id="aurora_shard" scale="0.75"/> [極光事件](aurora/aurora_events.md) —— 極光何時出現，又會帶來什麼
* <ItemImage id="auroral_nautilus_spawn_egg" scale="0.75"/> [極光生物](aurora/creatures.md) —— 被極光引來的鸚鵡螺與小雪人

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">目錄</Color>
</Column>

<ItemImage id="minecraft:air" scale="0.5"/>
<Row>
<Column>

### <Color id="aqua">植物</Color>

* <ItemImage id="frozen_petals" scale="0.75"/> [極光花苞](flora/aurora_blooms.md)
* <ItemImage id="glow_leek" scale="0.75"/> [發光韭蔥](flora/glow_leeks.md)
* <ItemImage id="shimmering_ice" scale="0.75"/> [閃耀之冰](flora/shimmering_ice.md)
* <ItemImage id="aurora_ender_shard" scale="0.75"/> [末影花苞](flora/ender_bloom.md)

### <Color id="aqua">輝光鋼</Color>

* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [輝光鋼錠](shimmersteel/ingots.md)
* <ItemImage id="glacial_basin" scale="0.75"/> [冰川盆地](shimmersteel/glacial_basin.md)
* <ItemImage id="cold_brewing_stand" scale="0.75"/> [寒冷釀造臺](shimmersteel/cold_brewing_stand.md)
* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [輝光鋼工具](shimmersteel/tools.md)
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [輝光鋼弓](shimmersteel/bow.md)
* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [盔甲紋飾](shimmersteel/armor_trims.md)

### <Color id="aqua">輝光織</Color>

* <ItemImage id="shimmerweave_fabric" scale="0.75"/> [輝光織物](shimmerweave/fabric.md)
* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [護目鏡](shimmerweave/goggles.md)
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [外套](shimmerweave/tunic.md)
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [護腿](shimmerweave/leggings.md)
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [冰靴](shimmerweave/skates.md)

</Column>
<Column>

### <Color id="aqua">裝飾</Color>

* <ItemImage id="snow_angel" scale="0.75"/> [雪天使](decorations/snow_angel.md)
* <ItemImage id="hearthwood_log" scale="0.75"/> [爐心木原木](decorations/hearthwood_log.md)
* <ItemImage id="aurora_lantern" scale="0.75"/> [極光燈籠](decorations/aurora_lantern.md)

### <Color id="aqua">食物與飲品</Color>

* <ItemImage id="hot_cocoa" scale="0.75"/> [熱可可](food/hot_cocoa.md)
* <ItemImage id="frosted_cookies" scale="0.75"/> [霜凍曲奇](food/frosted_cookies.md)
* <ItemImage id="roasted_snowball" scale="0.75"/> [烤雪球](food/roasted_snowball.md)
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [裹糖烤雪球](food/sugared_roasted_snowball.md)
* <ItemImage id="snore" scale="0.75"/> [雪夾心](food/snore.md)

</Column>
</Row>

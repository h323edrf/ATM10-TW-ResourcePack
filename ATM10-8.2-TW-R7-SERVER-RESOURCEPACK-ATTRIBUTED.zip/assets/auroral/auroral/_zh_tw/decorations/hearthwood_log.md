---
navigation:
  title: 爐心木原木
  icon: auroral:hearthwood_log
  parent: index.md
  position: 62
item_ids:
  - auroral:hearthwood_log
---

# <Color id="gold">爐心木原木</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hearthwood_log" scale="2" />

  一種燃著魔法火焰的原木。點燃後的爐心木能擋住凍傷、驅趕幻翼，還能把這一夜往極光那邊推一把。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">獲取</Color>
</Column>

爐心木原木在寒冷生物群系裡自然生長，也會出現在：

* 積雪針葉林村莊
* 冰封結構
* 雪屋地下室（偶爾）

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">點燃</Color>
</Column>

用**打火石**右鍵點燃原木。點著之後它會亮起溫暖的魔法光輝，並開始發揮各項被動效果。燒盡的原木可以照同樣的方式重新點燃。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">效果</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">長燃</Color>
</Row>

點燃的爐心木原木可以燃燒**7 個遊戲日**的區塊載入時間（168,000 刻，約合連續遊玩 2 小時 20 分）。計時只在區塊處於活動狀態時才走，所以放在很少去的區塊裡的原木，實際能撐得久得多。燃燒時長可在伺服器端配置裡調整。

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">免疫凍傷</Color>
</Row>

點燃的原木**半徑 16 格**內的玩家免疫凍傷。圍一圈原木，基地就能安然度過最難熬的嚴冬。

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">幻翼結界</Color>
</Row>

任何幻翼只要闖進點燃原木的 16 格內就會當場著火。幻翼也不會盯上正被凍傷免疫護著的玩家，所以圍一圈點燃的爐心木，夜空就清淨了。

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">極光催化</Color>
</Row>

在寒冷生物群系裡，玩家 **32 格**內每有一根點燃的原木，入夜時的極光機率就**增加 15%**。最多三根疊加，共 **+45%**，在預設設定下把每夜的極光機率推到約 78%。第三根以外的原木不再疊加。

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">村民安適</Color>
</Row>

點燃的原木附近的村民會更自在，可能給出更好的交易。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">小貼士</Color>
</Column>

* 在寒冷生物群系的基地周圍擺一圈原木，凍傷防護就是常駐的了。
* 那點暖光順帶還能當環境照明。
* 三根點燃的原木正好是極光加成的甜點，第四根不再有額外效果。

---
item_ids:
  - auroral:snow_angel
navigation:
  title: 雪天使
  icon: auroral:snow_angel
  parent: index.md
  position: 60
---

# <Color id="gold">雪天使</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snow_angel" scale="2" />

  在新雪上留下的一個玩鬧痕跡。預設會消失——用一片冰凍花瓣把它定住，就能永遠留著。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">做一個雪天使</Color>
</Column>

**兩手都空著**時，在任意積雪表面**潛行 + 右鍵**。你的角色會在雪裡壓出一個印子，留下一個裝飾用的雪天使圖案。

雪天使被標記為*可替換*方塊——你可以直接往它所在的位置放方塊，不必先把它打掉，和高草叢或雪一樣。

可用的表面：

* 雪
* 雪塊
* 細雪

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">自行消失</Color>
</Column>

雪天使天生是短暫的。就像新雪上的腳印一樣，放著不管的話 **5 分鐘**後就會消失。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">儲存</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">用冰凍花瓣右鍵</Color>
</Row>

手持<ItemLink id="frozen_petals" />右鍵點選雪天使。花瓣的魔力會把它結晶固定，不再消失。定住的雪天使會一直留到被打掉為止。

冰凍花瓣來自極光期間收穫完全成熟的<ItemLink id="aurora_bloom" />。

---
item_ids:
  - auroral:aurora_lantern
navigation:
  title: 極光燈籠
  icon: auroral:aurora_lantern
  parent: index.md
  position: 61
---

# <Color id="gold">極光燈籠</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_lantern" scale="2" />

  一件裝飾性光源，把北極光那份縹緲的光輝收在其中——拿在手上時還能驅散魔法黑暗。
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="aurora_lantern" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">特性</Color>
</Column>

* **亮度等級 15** —— 最高亮度
* **變色** —— 在極光的幾種色調間緩緩流轉（綠、藍、粉）
* **可放置** —— 地面、牆上、吊在天花板下都行
* **防水** —— 在水下也不會熄滅

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">免疫黑暗</Color>
</Column>

<Row>
  <ItemImage id="aurora_lantern" />
  ### <Color id="aqua">拿在手上</Color>
</Row>

握在主手或副手時，極光燈籠讓你免疫黑暗效果。它那縹緲的光輝能驅散魔法黑暗，探索深暗之域或對付監守者時極為好用。

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">用途</Color>
</Column>

* 給寒冷生物群系的建築照明
* 營造一種魔法氛圍
* 在雪原上標出路徑
* 裝點輝光織主題的區域

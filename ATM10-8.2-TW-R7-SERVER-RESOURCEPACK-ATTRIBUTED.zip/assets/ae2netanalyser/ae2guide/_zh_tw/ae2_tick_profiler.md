---
navigation:
  parent: ae2:items-blocks-machines/items-blocks-machines-index.md
  icon: ae2netanalyser:tick_analyser
  title: ME刻速率分析儀
categories:
- tools
item_ids:
- ae2netanalyser:tick_analyser
---

# 分析 ME Tick 速率

<ItemImage id="ae2netanalyser:tick_analyser" scale="4"></ItemImage>

有時當你的 ME 網路非常龐大時，遊戲可能會變得卡頓，但要從網路中排查
卡頓源卻相當困難。現在，你可以藉助 ME刻速率分析儀 輕鬆找出哪裡卡頓了。

## 是什麼讓你的遊戲變卡？

一些 AE 裝置會在遊戲刻期間執行工作。ME刻速率分析儀 可以測量它們完成
工作所需的時間（μs/tick），並將數值在世界中視覺化，從而幫助你找出誰耗時最長。

**你需要 OP 許可權才能在多人伺服器中使用它，以防止濫用。**

![overview](./pic/tick_rate.png)

顏色代表方塊的卡頓程度。越紅，就越卡。

這個數字代表該方塊的刻速率。如果 TPS(ticks per second) 低於 20，你的遊戲就會開始卡頓。
換句話說，遊戲刻速率應始終低於 50000 μs/tick。

一般來說，大多數方塊的刻速都應低於 100 μs/tick，否則它們可能會導致卡頓。

## 自定義顯示

你可以在配置 GUI 中控制不同刻速在世界中的顯示。

![gui](./pic/gui2.png)

綠色圓點表示顯示對應刻速率範圍內的方塊。點選圓點即可啟用/禁用
顯示。
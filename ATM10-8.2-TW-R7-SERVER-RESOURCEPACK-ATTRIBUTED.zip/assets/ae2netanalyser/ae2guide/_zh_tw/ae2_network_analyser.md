---
navigation:
  parent: ae2:items-blocks-machines/items-blocks-machines-index.md
  icon: ae2netanalyser:network_analyser
  title: ME網路分析儀
categories:
- tools
item_ids:
- ae2netanalyser:network_analyser
---

# 分析 ME 網路

<ItemImage id="ae2netanalyser:network_analyser" scale="4"></ItemImage>

你是否曾苦於找不出 ME 網路中哪臺裝置離線了？或者只是想看看你的網路
執行狀況如何？這就是 ME網路分析儀！

## 我的 ME 網路到底發生了什麼？

點選任意連線到 ME 網路的方塊、線纜或裝置，你就能看到每個裝置的狀態以及它們彼此之間是如何連線的。


![overview](./pic/showoff.png)

不同的顏色和形狀代表不同狀態。
- 藍色立方體：普通 ME 裝置，它們有足夠頻道，並且可傳輸 8 個頻道。
- 黃色立方體：緻密 ME 裝置，它們有足夠頻道，並且可傳輸 32 個頻道。
- 紅色立方體：離線的 ME 裝置，它們沒有足夠頻道。
- 藍色連線：該連線最多可承載 8 個頻道。
- 黃色連線：該連線最多可承載 32 個頻道。
- 粉色連線：這是一個 ME P2P 連線。
- 數字：該連線當前承載的頻道數量。

請注意，最大頻道數實際上取決於你的 ME 頻道模式。當
無限頻道模式開啟時，分析器不會顯示頻道編號。

## 自定義顯示

你可以在配置 GUI 中更改分析模式和顏色。

![gui](./pic/gui.png)

ME網路分析器有 5 種模式。
- 完整：顯示所有網路狀態。
- 節點：只顯示節點狀態。
- 連線：只顯示連線狀態。
- 無數字：不顯示頻道編號。
- P2P：只顯示 ME P2P 連線。

你還可以更改節點或連線的顏色。

![gui2](./pic/color.png)